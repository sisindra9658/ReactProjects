const express = require("express");
const app = express();
const multer = require("multer");
const bodyParser = require("body-parser");
const nodemailer = require('nodemailer'); 
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");
const PDFDocument = require('pdfkit');
const fs = require('fs');
const router = require("./routes/router");
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt');

// const corsOptions = {
//   origin: 'https://hospi.chitgenius.com',
//   optionsSuccessStatus: 200
// };

const corsOptions = {
  origin: 'http://localhost:3000',
  optionsSuccessStatus: 200
};

app.use(cors(corsOptions));


const Pool = mysql.createPool({
    host: "103.92.235.85",
    user: "yatayati_hteam",
    password: "VinayHD@1922",
    database: "yatayati_hospi-basic",
});
app.use(router);

app.use(express.json());
app.use(cookieParser());
const jwtSecretKey = 'yatayatismdnvlsvnvlefmv';


app.use(bodyParser.urlencoded({ extended: true }));
 const dotenv = require("dotenv").config();
app.get("/api/get-image/:doctor_id", (req, res) => {
    const { doctor_id } = req.params;
    const sqlSelectImage =
      "SELECT filename FROM admin_doctors WHERE doctor_id = ?";
    Pool.query(sqlSelectImage, [doctor_id], (err, result) => {
      if (err) {
        console.error("Error fetching image from database:", err);
        res.status(500).json({ status: 500, message: "Internal Server Error" });
      } else {
        const filename = result[0] ? result[0].filename : null;
 
        if (filename) {
          const imagePath = path.join(__dirname, "uploads", filename);
          res.sendFile(imagePath);
        } else {
          res.status(404).json({ status: 404, message: "Image not found" });
        }
      }
    });
  });
 
 
app.get("/api/get", (req, res) => {
    const sqlGet = "SELECT * FROM admin_doctors";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
app.post("/api/post", (req, res) => {
  const {
      registration_id,
      doctor_name,
      mobile,
      specialization,
      experience,
      email,
      filename,
      gender,
      birth_date,
      age,
      city,
      address,
      blood_group,
      shift_start_time,
      shift_end_time,
      remarks,
      OP_start_time,
      OP_end_time,
      managing_admin,
      consultation_fee,
      qualification,
      Language
     
  } = req.body;
 
 
 
  if (!doctor_name) {
      return res.status(400).send("Full name cannot be null");
  }
 
  const sqlInsert =
      "INSERT INTO admin_doctors (registration_id, doctor_name, mobile, specialization, experience, email, gender, birth_date, age, city, address, blood_group, shift_start_time, shift_end_time, OP_start_time, OP_end_time, remarks, filename, managing_admin, consultation_fee, qualification, Language) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
 
  Pool.query(
      sqlInsert,
      [
          registration_id,
          doctor_name,
          mobile,
          specialization,
          experience,
          email,
          gender,
          birth_date,
          age,
          city,
          address,
          blood_group,
          shift_start_time,
          shift_end_time,
          OP_start_time,
          OP_end_time,
          remarks,
          filename,
      managing_admin,
      consultation_fee,
      qualification,
      Language
      ],
      (error, result) => {
          if (error) {
              console.log(error);
              res.status(500).send("Error inserting doctor record");
          } else {
              res.send(result);
          }
      }
  );
});
 
 
app.put("/api/update/:doctor_id", (req, res) => {
  const { doctor_id } = req.params;
  const {
    registration_id,
    doctor_name,
    mobile,
    specialization,
    experience,
    email,
    gender,
    birth_date,
    age,
    city,
    address,
    blood_group,
    shift_start_time,
    shift_end_time,
    OP_start_time,
    OP_end_time,
    remarks,
    managing_admin,
    consultation_fee,
    qualification,
    Language
   
  } = req.body;
 
  const sqlUpdate = `
      UPDATE admin_doctors
      SET
      registration_id = ?,
      doctor_name = ?,
          mobile = ?,
          specialization = ?,
          experience = ?,
          email = ?,
          gender = ?,
          birth_date = ?,
          age = ?,
          city = ?,
          address = ?,
          blood_group = ?,
          shift_start_time = ?,
          shift_end_time = ?,
          OP_start_time = ?,
          OP_end_time = ?,
          remarks = ?,
          managing_admin = ?,
          consultation_fee = ?,
          qualification = ?,
          Language = ?
         
      WHERE doctor_id = ?
  `;
 
  Pool.query(
    sqlUpdate,
    [
        registration_id,
      doctor_name,
      mobile,
      specialization,
      experience,
      email,
      gender,
      birth_date,
      age,
      city,
      address,
      blood_group,
      shift_start_time,
      shift_end_time,
      OP_start_time,
      OP_end_time,
      remarks,
      managing_admin,
      consultation_fee,
      qualification,
      Language,
     
      doctor_id,
    ],
    (error, result) => {
      if (error) {
        console.log(error);
        res.status(500).send("Error updating doctor record");
      } else {
        res.send(result);
      }
    }
  );
});
 
 
// app.put("/api/update/:admin_doctor_id", (req, res) => {
//     const { admin_doctor_id } = req.params;
//     const {
//         full_name,
//         mobile,
//         specialization,
//         experience,
//         email,
//         gender,
//         birth_date,
//         age,
//         city,
//         address,
//         blood_group,
//         shift_start_time,
//         shift_end_time,
//         remarks,
//         filename
//     } = req.body;
 
//     const sqlUpdate = `
//         UPDATE admin_doctors
//         SET
//             full_name = ?,
//             mobile = ?,
//             specialization = ?,
//             experience = ?,
//             email = ?,
//             gender = ?,
//             birth_date = ?,
//             age = ?,
//             city = ?,
//             address = ?,
//             blood_group = ?,
//             shift_start_time = ?,
//             shift_end_time = ?,
//             remarks = ?,
//             filename = ?
//         WHERE admin_doctor_id = ?
//     `;
 
//     Pool.query(
//         sqlUpdate,
//         [
//             full_name,
//             mobile,
//             specialization,
//             experience,
//             email,
//             gender,
//             birth_date,
//             age,
//             city,
//             address,
//             blood_group,
//             shift_start_time,
//             shift_end_time,
//             remarks,
//             filename,
//             admin_doctor_id,
//         ],
//         (error, result) => {
//             if (error) {
//                 console.log(error);
//                 res.status(500).send("Error updating doctor record");
//             } else {
//                 res.send(result);
//             }
//         }
//     );
// });
 
app.delete("/api/remove/:doctor_id", (req, res) => {
    const { doctor_id } = req.params;
    const sqlRemove = "DELETE FROM admin_doctors WHERE doctor_id= ?";
    Pool.query(sqlRemove, doctor_id, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
 
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
 
 
 
const imgconfig = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, "./uploads");
    },
    filename: (req, file, callback) => {
        callback(
            null,
            `${file.originalname}`
        );
    },
});
const isImage = (req, file, callback) => {
    if (file.mimetype.startsWith("image")) {
        callback(null, true);
    } else {
        callback(null, false);
    }
};
 
const upload = multer({
    storage: imgconfig,
    fileFilter: isImage,
});
 
 
app.post("/upload-image", upload.single("filename"), (req, res) => {
  const { filename } = req.file;
    console.log(filename);
  if (!filename) {
    res.status(422).json({ status: 422, message: "Image file not provided." });
    return;
  }
 
  try {
    const sqlInsert = "INSERT INTO uploads (filename) VALUES (?)";
    Pool.query(sqlInsert, [filename], (err, result) => {
      if (err) {
        console.error("Error inserting image into database:", err);
        res.status(500).json({ status: 500, message: "Internal Server Error" });
      } else {
        console.log("Image added to database");
        res.status(201).json({ status: 201, data: { filename } });
      }
    });
  } catch (error) {
    console.error("Error saving image to database:", error);
    res.status(500).json({ status: 500, message: "Internal Server Error" });
  }
});
// app.post("/doctor-image", upload.single("filename"), (req, res) => {
//     const { filename } = req.file;
     
//     if (!filename) {
//       res.status(422).json({ status: 422, message: "Image file not provided." });
//       return;
//     }
//    return;
   
//   });
 
app.get("/get-images", (req, res) => {
    try {
        const sqlSelect = "SELECT * FROM admin_doctors";
        Pool.query(sqlSelect, (err, result) => {
            if (err) {
                console.error("Error fetching images from database:", err);
                res
                    .status(500)
                    .json({ status: 500, message: "Internal Server Error" });
            } else {
                console.log("Images fetched from database");
                res.status(200).json({ status: 200, data: result });
            }
        });
    } catch (error) {
        console.error("Error fetching images from database:", error);
        res.status(500).json({ status: 500, message: "Internal Server Error" });
    }
});
 
 
 
app.get("/api/get/doctor-schedule", (req, res) => {
    const sqlGet = "SELECT * FROM admin_doctors";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
app.post("/api/post-doctor-schedule", (req, res) => {
    const {
       
        monday,
        tuesday,
        wednesday,
        thursday,
        friday,
        saturday,
        sunday
    } = req.body;
 
    const sqlInsert =
        "INSERT INTO admin_doctors ( monday, tuesday, wednesday, thursday, friday, saturday, sunday) VALUES ( ?, ?, ?, ?, ?, ?, ?)";
 
    Pool.query(
        sqlInsert,
        [
           
            monday,
            tuesday,
            wednesday,
            thursday,
            friday,
            saturday,
            sunday
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting doctor schedule record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
 
app.put("/api/put-doctor-schedule/:doctor_id", (req, res) => {
    const { doctor_id } = req.params;
    const {    
       
        monday,
        tuesday,
        wednesday,
        thursday,
        friday,
        saturday,
        sunday
    } = req.body;
 
    const sqlUpdate = `
        UPDATE admin_doctors
        SET
           
        monday = ?,
        tuesday = ?,
         wednesday = ?,
         thursday = ?,
         friday = ?,
         saturday = ?,
         sunday = ?
       
        WHERE doctor_id = ?;
    `;
 
    Pool.query(
        sqlUpdate,
        [
            monday,
            tuesday,
            wednesday,
            thursday,
            friday,
            saturday,
            sunday,
 
         doctor_id
                 
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating patientdetails record");
            } else {
                res.send(result);
            }
        }
    );
});
 

app.get("/api/get1", (req, res) => {
    const sqlGet = "SELECT * FROM patients";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
app.delete("/api/remove1/:patient_id", (req, res) => {
  const { patient_id } = req.params;
  const sqlRemove = "DELETE FROM patients WHERE patient_id = ?";
 
  console.log("Deleting patient with ID:", patient_id);
 
  Pool.query(sqlRemove, [patient_id], (error, result) => {
      if (error) {
          console.error(error);
          res.status(500).send("Error deleting patient record");
      } else {
          console.log("Delete operation result:", result);
          res.send(result);
      }
  });
});
 
app.post("/api/postpatient", (req, res) => {
    const {
     
        full_name,
        mobile,
        email,
        gender,
        date_of_birth,
        age,
        city,
        address,
        blood_group,
        remarks,
        managing_admin,
       
    } = req.body;
   
   
   
   
    if (!full_name) {
        return res.status(400).send("Full name cannot be null");
    }
   
    const sqlInsert =
        "INSERT INTO patients ( full_name, mobile, email, gender, date_of_birth, age, city, address, blood_group, remarks, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
   
    Pool.query(
        sqlInsert,
        [
            full_name,
            mobile,
            email,
            gender,
            date_of_birth,
            age,
            city,
            address,
            blood_group,
            remarks,
            managing_admin,
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting doctor record");
            } else {
                res.send(result);
            }
        }
    );
  });
 
  app.put("/api/updatepatient/:patient_id", (req, res) => {
    const { patient_id } = req.params;
    const {
           
           full_name,
            mobile,
            email,
            gender,
            date_of_birth,
            age,
            city,
            address,
            blood_group,
            remarks,
            managing_admin,
    } = req.body;
 
    const sqlUpdate = `
        UPDATE patients
        SET
            full_name = ?,
            mobile = ?,
            email = ?,
            gender = ?,
            date_of_birth = ?,
            age = ?,
            city = ?,
            address = ?,
            blood_group = ?,
            remarks = ?,
            managing_admin = ?
        WHERE patient_id = ?
    `;
 
    Pool.query(
        sqlUpdate,
        [
           
            full_name,
            mobile,
            email,
            gender,
            date_of_birth,
            age,
            city,
            address,
            blood_group,
            remarks,
            managing_admin,
            patient_id
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating doctor record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
app.delete("/api/remove2/:employeeid", (req, res) => {
    const { employeeid } = req.params;
    const sqlRemove = "DELETE FROM nurse WHERE employeeid= ?";
    Pool.query(sqlRemove, employeeid, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
 
app.get("/api/get/nurse", (req, res) => {
    const sqlGet = "SELECT * FROM nurse";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
app.post("/api/postnurse", (req, res) => {
    const {
     
        fullname,
    shift,
    contactnumber,
    emailaddress,
    bloodgroup,
    experience,
    address,
    qualification,    
    activestatus,
    managing_admin,
   
       
    } = req.body;
   
   
   
   
    if (!fullname) {
        return res.status(400).send("Full name cannot be null");
    }
   
    const sqlInsert =
        "INSERT INTO nurse (  fullname, shift, contactnumber, emailaddress,  bloodgroup, experience, address, qualification, activestatus, managing_admin) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
   
    Pool.query(
        sqlInsert,
        [
           
            fullname,
            shift,
            contactnumber,
            emailaddress,
            bloodgroup,
            experience,
            address,
            qualification,    
            activestatus,
            managing_admin,
           
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting nurse record");
            } else {
                res.send(result);
            }
        }
    );
  });
 
  app.put("/api/updatenurse/:employeeid", (req, res) => {
    const { employeeid } = req.params;
    const {
           
        fullname,
        shift,
        contactnumber,
        emailaddress,
        bloodgroup,
        experience,
        address,
        qualification,    
        activestatus,
        managing_admin,
    } = req.body;
 
    const sqlUpdate = `
        UPDATE nurse
        SET
            fullname = ?,
            shift = ?,
            contactnumber = ?,
            emailaddress = ?,
            bloodgroup = ?,
            experience= ?,
            address = ?,
           qualification =?,
            activestatus = ?,
            managing_admin = ?
        WHERE employeeid = ?
    `;
 
    Pool.query(
        sqlUpdate,
        [
           
            fullname,
    shift,
    contactnumber,
    emailaddress,
    bloodgroup,
    experience,
    address,
    qualification,    
    activestatus,
    managing_admin,
            employeeid
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating nurse record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
 
app.get("/api/get/pharmacist", (req, res) => {
    const sqlGet = "SELECT * FROM pharmacist";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
app.delete("/api/remove5/:pharmacist_id", (req, res) => {
    const { pharmacist_id } = req.params;
    const sqlRemove = "DELETE FROM pharmacist WHERE pharmacist_id= ?";
    Pool.query(sqlRemove, pharmacist_id, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
 
app.post("/api/postpharmacist", (req, res) => {
    const {
     
        full_name,
    email,
    gender,
    address,
    city,
    contact_number,
    license_number,
    experience_years,
    qualification,  
    active_status,
    managing_admin,
   
       
    } = req.body;
   
   
   
   
    if (!full_name) {
        return res.status(400).send("Full name cannot be null");
    }
   
    const sqlInsert =
        "INSERT INTO pharmacist (  full_name, email, gender, address,  city, contact_number, license_number,   experience_years, qualification, active_status, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
   
    Pool.query(
        sqlInsert,
        [
           
            full_name,
            email,
            gender,
            address,
            city,
            contact_number,
            license_number,
            experience_years,
            qualification,  
            active_status,
            managing_admin,
           
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting pharmacist record");
            } else {
                res.send(result);
            }
        }
    );
  });
 
  app.put("/api/updatepharmacist/:pharmacist_id", (req, res) => {
    const { pharmacist_id } = req.params;
    const {
           
       
        full_name,
        email,
        gender,
        address,
        city,
        contact_number,
        license_number,
        experience_years,
        qualification,  
        active_status,
        managing_admin,
    } = req.body;
 
    const sqlUpdate = `
        UPDATE pharmacist
        SET
           
        full_name = ?,
        email= ?,
        gender= ?,
        address= ?,
        city= ?,
        contact_number= ?,
        license_number= ?,
        experience_years= ?,
        qualification= ?,  
        active_status= ?,
        managing_admin= ?
        WHERE pharmacist_id = ?;
    `;
 
    Pool.query(
        sqlUpdate,
        [
            full_name,
            email,
            gender,
            address,
            city,
            contact_number,
            license_number,
            experience_years,
            qualification,  
            active_status,
            managing_admin,
            pharmacist_id
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating pharmacist record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
app.get("/api/get/receptionist", (req, res) => {
    const sqlGet = "SELECT * FROM receptionist";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
app.delete("/api/remove3/:employeeid", (req, res) => {
    const { employeeid } = req.params;
    const sqlRemove = "DELETE FROM receptionist WHERE employeeid= ?";
    Pool.query(sqlRemove, employeeid, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
 
 
 
 
app.post('/api/postreceptionist', (req, res) => {
    const {
      fullname,
      shift,
      languagesspoken,
      email,
      address,
      contact,
      bloodgroup,
      activestatus,
      managing_admin
    } = req.body;
 
    // Perform validation checks if needed
 
    const sqlInsert =
      'INSERT INTO receptionist (fullname, shift, languagesspoken, email, address, contact, bloodgroup, activestatus, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
 
    Pool.query(
      sqlInsert,
      [
        fullname,
        shift,
        languagesspoken,
        email,
        address,
        contact,
        bloodgroup,
        activestatus,
        managing_admin
      ],
      (error, result) => {
        if (error) {
          console.error('Error inserting receptionist record:', error);
          res.status(500).send('Error inserting receptionist record');
        } else {
          console.log('Receptionist record inserted successfully');
          res.send(result);
        }
      }
    );
  });
  app.put("/api/updatereceptionist/:employeeid", (req, res) => {
    const { employeeid } = req.params;
    const {
           
       
        fullname,
        shift,
        languagesspoken,
        email,
        address,
        contact,
        bloodgroup,
        activestatus,
        managing_admin
    } = req.body;
 
    const sqlUpdate = `
        UPDATE receptionist
        SET
           
        fullname = ?,
        shift= ?,
        languagesspoken= ?,
        email= ?,
        address= ?,
        contact = ?,
        bloodgroup= ?,
        activestatus= ?,
        managing_admin= ?
       
        WHERE employeeid = ?;
    `;
 
    Pool.query(
        sqlUpdate,
        [
            fullname,
        shift,
        languagesspoken,
        email,
        address,
        contact,
        bloodgroup,
        activestatus,
        managing_admin,
        employeeid
           
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating Receptionist record");
            } else {
                res.send(result);
            }
        }
    );
});
 
app.get("/api/get/laboratorist", (req, res) => {
    const sqlGet = "SELECT * FROM laboratorist";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
app.delete("/api/remove4/:employeeid", (req, res) => {
    const { employeeid } = req.params;
    const sqlRemove = "DELETE FROM laboratorist WHERE employeeid= ?";
    Pool.query(sqlRemove, employeeid, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
 
 app.post("/api/postlaboratorist", (req, res) => {
    const {
        fullname,
        shift,
        qualifications,
        department,
        emailaddress,
        contactnumber,
        bloodgroup,
        licensecertificatenumber,
        experience,
        activestatus,
        managing_admin
    } = req.body;
 
    // Perform validation checks if needed
 
    const sqlInsert = "INSERT INTO laboratorist (fullname, shift, qualifications, department, emailaddress, contactnumber, bloodgroup, licensecertificatenumber, experience, activestatus, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
 
    Pool.query(
        sqlInsert,
        [
            fullname,
            shift,
            qualifications,
            department,
            emailaddress,
            contactnumber,
            bloodgroup,
            licensecertificatenumber,
            experience,
            activestatus,
            managing_admin
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting laboratorist record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
app.put("/api/updatelaboratorist/:employeeid", (req, res) => {
    const { employeeid } = req.params;
    const {
           
       
        fullname,
        shift,
        qualifications,
        department,
        emailaddress,
        contactnumber,
        bloodgroup,
        licensecertificatenumber,
        experience,
        activestatus,
        managing_admin
    } = req.body;
 
    const sqlUpdate = `
        UPDATE laboratorist
        SET
           
        fullname = ?,
        shift= ?,
        qualifications= ?,
        department= ?,
        emailaddress= ?,
        contactnumber = ?,
        bloodgroup= ?,
        licensecertificatenumber= ?,
        experience = ?,
        activestatus = ?,
        managing_admin= ?
       
        WHERE employeeid = ?;
    `;
 
    Pool.query(
        sqlUpdate,
        [
            fullname,
            shift,
            qualifications,
            department,
            emailaddress,
            contactnumber,
            bloodgroup,
            licensecertificatenumber,
            experience,
            activestatus,
            managing_admin,
        employeeid
           
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating Laboratorist record");
            } else {
                res.send(result);
            }
        }
    );
});
app.delete("/api/remove5/:pharmacist_id", (req, res) => {
    const { pharmacist_id } = req.params;
    const sqlRemove = "DELETE FROM pharmacist WHERE pharmacist_id= ?";
    Pool.query(sqlRemove, pharmacist_id, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
app.delete("/api/remove6/:patient_id", (req, res) => {
    const { patient_id } = req.params;
    const sqlRemove = "DELETE FROM appointment_booking WHERE patient_id= ?";
    Pool.query(sqlRemove, patient_id, (error, result) => {
        if (error) {
            console.log(error);
            res.status(500).send("Error deleting doctor record");
        } else {
            res.send(result);
        }
    });
});
 
app.get("/api/get/booking", (req, res) => {
    const sqlGet = "SELECT * FROM appointment_booking";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
// app.get("/api/get/patientdetails", (req, res) => {
//     const sqlGet = "SELECT * FROM patientdetails";
//     Pool.query(sqlGet, (error, result) => {
//         res.send(result);
//     });
// });

// app.get("/api/get/patientdetails/:patient_id", (req, res) => {
//     const patient_id = req.params.patient_id; // Extract the patient_id from request parameters
//     const sqlGet = "SELECT * FROM patientdetails WHERE patient_id = ?";
//     Pool.query(sqlGet, [patient_id], (error, result) => { // Pass patient_id as a parameter
//         if (error) {
//             console.error("Error fetching patient details:", error);
//             res.status(500).send("Error fetching patient details");
//         } else {
//             res.send(result);
//         }
//     });
// });
 
 
// app.post("/api/postpatientdetails", (req, res) => {
//     const {
//         patient_id,
//         weight,
//         height,
//          temperature,
//          blood_pressure
         
//     } = req.body;
 
//     // Perform validation checks if needed
 
//     const sqlInsert = "INSERT INTO patientdetails (patient_id, weight, height, temperature, blood_pressure) VALUES (?, ?, ?, ?, ?)";
 
//     Pool.query(
//         sqlInsert,
//         [
//             patient_id,
//             weight,
//             height,
//              temperature,
//              blood_pressure,
             
//         ],
//         (error, result) => {
//             if (error) {
//                 console.log(error);
//                 res.status(500).send("Error inserting Patientbooking record");
//             } else {
//                 res.send(result);
//             }
//         }
//     );
// });
// app.put("/api/updatepatientdetails/:patient_id", (req, res) => {
   
//     const {    
//             weight,
//             height,
//              temperature,
//              blood_pressure,
//     } = req.body;
 
//     const sqlUpdate = `
//         UPDATE patientdetails
//         SET
           
//         weight = ?,
//         height= ?,
//         temperature= ?,
//         blood_pressure= ?
       
       
       
//         WHERE patient_id = ?;
//     `;
 
//     Pool.query(
//         sqlUpdate,
//         [
//             weight,
//             height,
//              temperature,
//              blood_pressure
             
                 
//         ],
//         (error, result) => {
//             if (error) {
//                 console.log(error);
//                 res.status(500).send("Error updating patientdetails record");
//             } else {
//                 res.send(result);
//             }
//         }
//     );
// });
 
 
 
app.post("/api/postappointment", (req, res) => {
    const {
        name,
    contact,
    email,
    booking_date,
    clinic_name,
    address,
    doctor_name,
    slot_time,
    consultation_fee,
    weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status,
         managing_admin
         
    } = req.body;
 
    // Perform validation checks if needed
 
    const sqlInsert = "INSERT INTO appointment_booking (name, contact, email, booking_date, clinic_name, address, doctor_name, slot_time, consultation_fee, weight, height, temperature, blood_pressure, paymentMode, status, managing_admin ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
 
    Pool.query(
        sqlInsert,
        [
              name,
              contact,
              email,
              booking_date,
              clinic_name,
              address,
              doctor_name,
              slot_time,
              consultation_fee,
              weight,
              height,
               temperature,
               blood_pressure,
               paymentMode,
               status,
               managing_admin
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting Patientbooking record");
            } else {
                res.send(result);
            }
        }
    );
});
app.put("/api/updateappointment/:patient_id", (req, res) => {
    const { patient_id } = req.params;
    const {    
        name,
        contact,
        email,
        address,
        booking_date,
        clinic_name,
        doctor_name,
        slot_time,
        consultation_fee,
        weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status,
         managing_admin
    } = req.body;
 
    const sqlUpdate = `
        UPDATE appointment_booking
        SET
           
        name = ?,
        contact= ?,
        email= ?,
        address= ?,
        booking_date= ?,
        clinic_name = ?,
        doctor_name = ?,
        slot_time = ?,
        consultation_fee = ? ,
        weight = ?,
        height = ?,
         temperature = ?,
         blood_pressure = ?,
         paymentMode = ?,
         status = ?,
         managing_admin = ?
       
        WHERE patient_id = ?;
    `;
 
    Pool.query(
        sqlUpdate,
        [
            name,
            contact,
            email,
            address,
            booking_date,
            clinic_name,
            doctor_name,
            slot_time,
            consultation_fee,
            weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status,
         managing_admin,
 
            patient_id
                 
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating patientdetails record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
 
app.post("/api/postappointment1", (req, res) => {
    const {
       
    weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status
         
    } = req.body;
 
    // Perform validation checks if needed
 
    const sqlInsert = "INSERT INTO appointment_booking (  weight, height, temperature, blood_pressure, paymentMode, status ) VALUES ( ?, ?, ?, ?, ?, ?)";
 
    Pool.query(
        sqlInsert,
        [
           
            weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status
             
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error inserting Patientbooking record");
            } else {
                res.send(result);
            }
        }
    );
});
app.put("/api/updateappointment1/:patient_id", (req, res) => {
    const { patient_id } = req.params;
    const {    
       
        weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status
    } = req.body;
 
    const sqlUpdate = `
        UPDATE appointment_booking
        SET
           
        weight = ?,
        height = ?,
         temperature = ?,
         blood_pressure = ?,
         paymentMode = ?,
         status = ?
       
        WHERE patient_id = ?;
    `;
 
    Pool.query(
        sqlUpdate,
        [
            weight,
        height,
         temperature,
         blood_pressure,
         paymentMode,
         status,
 
            patient_id
                 
        ],
        (error, result) => {
            if (error) {
                console.log(error);
                res.status(500).send("Error updating patientdetails record");
            } else {
                res.send(result);
            }
        }
    );
});
 
 
 
app.get("/api/get/healthpackages", (req, res) => {
    const sqlGet = "SELECT * FROM healthpackages";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});

// const generatePDF = (formData, pdfFilePath) => {
//     const doc = new PDFDocument();
//     const outputStream = fs.createWriteStream(pdfFilePath);
//     doc.pipe(outputStream);
  
//     // Add patient details table to PDF
//     const table = {
//       headers: ['Field', 'Value'],
//       rows: [
//         ['Patient ID', formData.patient_id],
//         ['Name', formData.name],
//         ['Mobile Number', formData.contact],
//         ['Email', formData.email],
//         ['Address', formData.address],
//         ['Doctor', formData.doctor_name],
//         ['Booking Date', formData.booking_date],
//         ['Booking Time', formData.slot_time],
//         ['Weight', formData.weight],
//         ['Height', formData.height],
//         ['Temperature', formData.temperature],
//         ['Blood Pressure', formData.blood_pressure],
//         ['Consultation Fee', formData.consultation_fee],
//         ['Payment Mode', formData.paymentMode],
//         ['Payment Status', formData.status],
//       ]
//     };
  
//     const tableTop = 100; // Set the top position of the table
//     const colWidth = 200; // Set the width of each column
//     const rowHeight = 20; // Set the height of each row
  
//     try {
//       // Draw table headers
//       doc.font('Helvetica-Bold').fontSize(12);
//       table.headers.forEach((header, i) => {
//         doc.text(header, 50 + i * colWidth, tableTop);
//       });
  
//       // Draw table rows
//       doc.font('Helvetica').fontSize(10);
//       table.rows.forEach((row, rowIndex) => {
//         row.forEach((cell, cellIndex) => {
//           const value = cell !== undefined ? cell.toString() : ''; // Check for undefined value
//           doc.text(value, 50 + cellIndex * colWidth, tableTop + (rowIndex + 1) * rowHeight);
//         });
//       });
  
//       // Finalize the PDF document
//       doc.end();
  
//       // Ensure that the directory exists before writing the PDF file
//       const dirPath = path.dirname(pdfFilePath);
//       if (!fs.existsSync(dirPath)) {
//         fs.mkdirSync(dirPath, { recursive: true });
//       }
      
//       console.log('PDF generated successfully:', pdfFilePath);
//     } catch (error) {
//       console.error('Error generating PDF:', error);
//     }
// };

// app.use('/pdfs', express.static(path.join(__dirname, 'pdfs')));
//   // Endpoint to handle PDF generation and download
//   app.post('/api/download-pdf', (req, res) => {
//     const formData = req.body;
  
//     try {
//       // Generate a unique file name for the PDF
//     //   const pdfFilePath = path.join(__dirname, 'downloads', `${formData.name,Date.now()}.pdf`);
//       const pdfFilePath = path.join(__dirname, 'downloads', `${formData.name}_${formData.patient_id}_${Date.now()}.pdf`);

//       // Generate the PDF file based on the form data
//       generatePDF(formData, pdfFilePath);
  
//       // Send the generated PDF file as a response
//       res.download(pdfFilePath, (err) => {
//         if (err) {
//           console.error('Error downloading PDF:', err);
//           res.status(500).send('Internal Server Error');
//         } else {
//           console.log('PDF downloaded successfully');
//         }
//       });
//     } catch (error) {
//       console.error('Error generating PDF:', error);
//       res.status(500).send('Internal Server Error');
//     }
//   });
  
 
 

// const pdfsDirectory = path.join(__dirname, 'downloads'); // Path to the directory containing PDFs
// app.use('/pdfs', express.static(pdfsDirectory));


// app.get('/pdfs', (req, res) => {
//     fs.readdir(pdfsDirectory, (err, files) => {
//         if (err) {
//             console.error('Error reading directory:', err);
//             return res.status(500).send('Internal Server Error');
//         }

//         const pdfsData = files
//             .filter(file => file.endsWith('.pdf'))
//             .map((file, index) => ({ id: index + 1, url: `/pdfs/${file}` }));

//         res.json(pdfsData);
//     });
// });

// // app.get('/pdf-details', (req, res) => {
// //     const { url } = req.query;
// //     const pdfFileName = url.split('/').pop(); // Extract PDF file name from URL

// //     // Assuming JSON file with the same name as PDF file but with .json extension
// //     const jsonFilePath = path.join(pdfsDirectory, `${pdfFileName}.json`);

// //     // Check if JSON file exists
// //     if (fs.existsSync(jsonFilePath)) {
// //         // Read JSON file and send its contents as response
// //         fs.readFile(jsonFilePath, 'utf8', (err, data) => {
// //             if (err) {
// //                 console.error('Error reading JSON file:', err);
// //                 return res.status(500).send('Internal Server Error');
// //             }
// //             const pdfDetails = JSON.parse(data);
// //             res.json(pdfDetails);
// //         });
// //     } else {
// //         res.status(404).send('PDF details not found');
// //     }
// // });

const pdfParse = require('pdf-parse');

// app.get('/pdf-details', async (req, res) => {
//     const { url } = req.query;
//     const pdfFileName = url.split('/').pop(); // Extract PDF file name from URL
//     const pdfFilePath = path.join(pdfsDirectory, pdfFileName);

//     // Check if PDF file exists
//     if (!fs.existsSync(pdfFilePath)) {
//         return res.status(404).send('PDF file not found');
//     }

//     try {
//         // Read PDF file
//         const pdfBuffer = fs.readFileSync(pdfFilePath);

//         // Parse PDF content
//         const data = await pdfParse(pdfBuffer);

//         // Split text into lines
//         const lines = data.text.split('\n');

//         // Simplify the format into field: value pairs
//         const details = lines.reduce((acc, line) => {
//             const parts = line.split(/\s+/);
//             if (parts.length >= 2) {
//                 const field = parts.shift(); // First part is the field
//                 const value = parts.join(' '); // Join the remaining parts as the value
//                 acc.push(`${field}: ${value}`);
//             }
//             return acc;
//         },[]);

//         // const pdfDetails = {
//         //     // name: pdfFileName,
//         //     // size: fs.statSync(pdfFilePath).size, // File size in bytes
//         //     details: details, // Text content of the PDF formatted as field: value pairs
//         //     // You can add more details as needed
//         // };

//         res.json(details);
//     } catch (error) {
//         console.error('Error reading PDF file:', error);
//         res.status(500).send('Internal Server Error');
//     }
// });




// const generatePDF = (formData, pdfFilePath) => {
//     const doc = new PDFDocument();
//     const outputStream = fs.createWriteStream(pdfFilePath);
//     doc.pipe(outputStream);

//     // Add patient details table to PDF
//     const table = {
//         headers: ['Field', 'Value'],
//         rows: [
//             ['Patient ID', formData.patient_id],
//             ['Name', formData.name],
//             ['Mobile Number', formData.contact],
//             ['Email', formData.email],
//             ['Address', formData.address],
//             ['Doctor', formData.doctor_name],
//             ['Booking Date', formData.booking_date],
//             ['Slot Time', formData.slot_time],
//             ['Weight', formData.weight],
//             ['Height', formData.height],
//             ['Temperature', formData.temperature],
//             ['Blood Pressure', formData.blood_pressure],
//             ['Consultation Fee', formData.consultation_fee],
//             ['Payment Mode', formData.paymentMode],
//             ['Payment Status', formData.status],
//             ['Date', new Date().toLocaleDateString()], // Add current date
//             ['Time', new Date().toLocaleTimeString()] // Add current time
//         ]
//     };

//     const tableTop = 100; // Set the top position of the table
//     const colWidth = 200; // Set the width of each column
//     const rowHeight = 20; // Set the height of each row

//     try {
//         // Draw table headers
//         doc.font('Helvetica-Bold').fontSize(12);
//         table.headers.forEach((header, i) => {
//             doc.text(header, 50 + i * colWidth, tableTop);
//         });

//         // Draw table rows
//         doc.font('Helvetica').fontSize(10);
//         table.rows.forEach((row, rowIndex) => {
//             row.forEach((cell, cellIndex) => {
//                 const value = cell !== undefined ? cell.toString() : ''; // Check for undefined value
//                 doc.text(value, 50 + cellIndex * colWidth, tableTop + (rowIndex + 1) * rowHeight);
//             });
//         });

//         // Finalize the PDF document
//         doc.end();

//         // Ensure that the directory exists before writing the PDF file
//         const dirPath = path.dirname(pdfFilePath);
//         if (!fs.existsSync(dirPath)) {
//             fs.mkdirSync(dirPath, { recursive: true });
//         }

//         console.log('PDF generated successfully:', pdfFilePath);
//     } catch (error) {
//         console.error('Error generating PDF:', error);
//     }
// };

const pdfsDirectory = path.join(__dirname, 'downloads'); // Path to the directory containing PDFs
app.use('/pdfs', express.static(pdfsDirectory));


const generatePDF = (formData, pdfFilePath, res) => {
    const doc = new PDFDocument();
    const outputStream = fs.createWriteStream(pdfFilePath);
    doc.pipe(outputStream);
  
    // Add patient details table to PDF
    const table = {
      headers: ['Field', 'Value'],
      rows: [
        ['Patient ID', formData.patient_id],
        ['Name', formData.name],
        ['Mobile Number', formData.contact],
        ['Email', formData.email],
        ['Address', formData.address],
        ['Doctor', formData.doctor_name],
        ['Booking Date', formData.booking_date],
        ['Slot Time', formData.slot_time],
        ['Weight', formData.weight],
        ['Height', formData.height],
        ['Temperature', formData.temperature],
        ['Blood Pressure', formData.blood_pressure],
        ['Consultation Fee', formData.consultation_fee],
        ['Payment Mode', formData.paymentMode],
        ['Payment Status', formData.status],
        ['Date', new Date().toLocaleDateString()], // Add current date
        ['Time', new Date().toLocaleTimeString()] // Add current time
      ]
    };
  
    const tableTop = 100; // Set the top position of the table
    const colWidth = 200; // Set the width of each column
    const rowHeight = 20; // Set the height of each row
  
    // Draw table headers
    doc.font('Helvetica-Bold').fontSize(12);
    table.headers.forEach((header, i) => {
      doc.text(header, 50 + i * colWidth, tableTop);
    });
  
    // Draw table rows
    doc.font('Helvetica').fontSize(10);
    table.rows.forEach((row, rowIndex) => {
      row.forEach((cell, cellIndex) => {
        const value = cell !== undefined ? cell.toString() : ''; // Check for undefined value
        doc.text(value, 50 + cellIndex * colWidth, tableTop + (rowIndex + 1) * rowHeight);
      });
    });
  
    // Finalize the PDF document
    doc.end();
  
    outputStream.on('finish', () => {
      // Once the stream is finished writing, send the generated PDF file as a response
      res.download(pdfFilePath, (err) => {
        if (err) {
          console.error('Error downloading PDF:', err);
          res.status(500).send('Internal Server Error');
        } else {
          console.log('PDF downloaded successfully');
        }
      });
    });
  
    outputStream.on('error', (error) => {
      console.error('Error generating PDF:', error);
      res.status(500).send('Internal Server Error');
    });
  };
  app.post('/api/download-pdf', (req, res) => {
    const formData = req.body;
    const currentDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).replace(/\//g, '-'); // Replace slashes with dashes for file name
    
    const currentTime = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).replace(/:/g, '-'); // Replace colons with dashes for file name
    
    try {
      const pdfFilePath = path.join(__dirname, 'downloads', `${formData.name}_${formData.patient_id}_${currentDate}_${currentTime}.pdf`);
      generatePDF(formData, pdfFilePath, res);
    } catch (error) {
      console.error('Error generating PDF:', error);
      res.status(500).send('Internal Server Error');
    }
  });

app.get('/pdfs', (req, res) => {
    fs.readdir(pdfsDirectory, (err, files) => {
        if (err) {
            console.error('Error reading directory:', err);
            return res.status(500).send('Internal Server Error');
        }

        const pdfsData = files
            .filter(file => file.endsWith('.pdf'))
            .map((file, index) => ({ id: index + 1, url: `/pdfs/${file}` }));

        res.json(pdfsData);
    });
});

app.get('/pdf-details', async (req, res) => {
    const { url } = req.query;
    const pdfFileName = url.split('/').pop();
    const pdfFilePath = path.join(pdfsDirectory, pdfFileName);

    // Check if PDF file exists
    if (!fs.existsSync(pdfFilePath)) {
        return res.status(404).send('PDF file not found');
    }

    try {
        const pdfBuffer = fs.readFileSync(pdfFilePath);
        const data = await pdfParse(pdfBuffer);
        const lines = data.text.split('\n');
        const pdfDetails = {};
        const expectedFields = [
            'Patient ID',
            'Name',
            'Mobile Number',
            'Email',
            'Address',
            'Doctor',
            'Booking Date',
            'Slot Time',
            'Weight',
            'Height',
            'Temperature',
            'Blood Pressure',
            'Consultation Fee',
            'Payment Mode',
            'Payment Status',
            'Date',
            'Time'
        ];

        lines.forEach(line => {
            expectedFields.forEach(field => {
                if (line.includes(field)) {
                    const value = line.replace(field, '').trim();
                    // Remove unnecessary characters from field and value
                    const cleanedField = field.replace(/[{}[\]()'"`]/g, '').trim();
                    const cleanedValue = value.replace(/[{}[\]()'"`]/g, '').trim();
                    pdfDetails[cleanedField] = cleanedValue;
                }
            });
        });

        res.json(pdfDetails);
    } catch (error) {
        console.error('Error reading PDF file:', error);
        res.status(500).send('Internal Server Error');
    }
});
 

app.get("/api/get/doctors", (req, res) => {
  const sqlGet = "SELECT doctor_name, doctor_id, consultation_fee FROM admin_doctors";
  Pool.query(sqlGet, (error, result) => {
      if (error) {
          console.error('Error getting doctors:', error);
          res.status(500).json({ error: 'Internal server error' });
          return;
      }
      const doctorsData = result.map((doctor) => ({
          doctor_name: doctor.doctor_name,
          doctor_id: doctor.doctor_id,
          consultation_fee: doctor.consultation_fee
      }));
      res.json(doctorsData);
  });
});
 
app.get("/api/get/availableslots", (req, res) => {
    const { doctor_id, date } = req.query;
    const sqlGet = `SELECT ${date} FROM bookings WHERE doctor_id = ? `;
    Pool.query(sqlGet, [doctor_id, date], (error, result) => {
        if (error) {
            console.error('Error getting available slots:', error);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }
        const availableSlots = result.map((slot) => slot[date]);
        res.json(availableSlots);
    });
});
 
app.get('/api/available-slots/:doctorId/:date', async (req, res) => {
    try {
        
      const { doctorId, date } = req.params;
      const bookedSlotsQuery = await yourDatabase.query(
        'SELECT booked_slot FROM bookings WHERE doctor_id = ? AND booking_date = ?',
        [doctorId, date]
      );
 
      const bookedSlots = bookedSlotsQuery.map((booking) => booking.booked_slot);
 
      const allSlotsQuery = await yourDatabase.query(
        'SELECT time_slot FROM trybook WHERE doctor_id = ?',
        [doctorId]
      );
 
      const allSlots = allSlotsQuery.map((slot) => slot.time_slot);
 
      const availableSlots = allSlots.filter((slot) => !bookedSlots.includes(slot));
 
      res.json({ availableSlots });
    } catch (error) {
      console.error('Error fetching available slots:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
 
 
  app.get('/slots', (req, res) => {
    const { date, doctorId } = req.query;
    const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
   
    Pool.query(`SELECT ?? FROM bookings WHERE doctor_id = ?`, [dayOfWeek, doctorId], (error, results) => {
      if (error) {
        console.error('Error fetching available slots', error);
        res.status(500).send('Internal Server Error');
        return;
      }
   
      if (!results || !results[0] || !results[0][dayOfWeek]) {
        console.log(`No available slots for ${date}.`);
        res.status(404).send('No available slots');
        return;
      }
   
      const bookedSlotsQuery = `SELECT booking_time FROM appointment_booking WHERE doctor_name = ? AND booking_date = ?`;
      Pool.query(bookedSlotsQuery, [doctorId, date], (err, bookedSlots) => {
        if (err) {
          console.error('Error fetching booked slots', err);
          res.status(500).send('Internal Server Error');
          return;
        }
   
        const availableSlots = results[0][dayOfWeek].split(',').filter(slot => !bookedSlots.some(bookedSlot => bookedSlot.booking_time === slot));
        res.json(availableSlots);
      });
    });
  });
  app.listen(5000, () => {
    console.log("Server is running on port 5000");
});
app.post('/api/time_slots', (req, res) => {
    const { doctor_id, days, from_time, to_time } = req.body;
    const sql = 'INSERT INTO time_slots (doctor_id, days, from_time, to_time) VALUES (?, ?, ?, ?)';
    Pool.query(sql, [doctor_id, days, from_time, to_time], (err, result) => {
      if (err) {
        res.status(500).send('Error creating time slot');
      } else {
        res.status(201).send('Time slot created successfully');
      }
    });
  });
  
  app.get('/api/time_slots', (req, res) => {
    const sql = 'SELECT * FROM time_slots';
    Pool.query(sql, (err, result) => {
      if (err) {
        res.status(500).send('Error fetching time slots');
      } else {
        res.status(200).json(result);
      }
    });
  });
  
  app.put('/api/time_slots/:id', (req, res) => {
    const { doctor_id, days, from_time, to_time } = req.body;
    const id = req.params.id;
    const sql = 'UPDATE time_slots SET doctor_id = ?, days = ?, from_time = ?, to_time = ? WHERE id = ?';
    Pool.query(sql, [doctor_id, days, from_time, to_time, id], (err, result) => {
      if (err) {
        res.status(500).send('Error updating time slot');
      } else {
        res.status(200).send('Time slot updated successfully');
      }
    });
  });
  
  app.delete('/api/time_slots/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM time_slots WHERE id = ?';
    Pool.query(sql, [id], (err, result) => {
      if (err) {
        res.status(500).send('Error deleting time slot');
      } else {
        res.status(200).send('Time slot deleted successfully');
      }
    });
  });
  app.get("/api/get/optimings", (req, res) => {
    const sqlGet = "SELECT * FROM doctor_op_timings";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
 
// app.post('/api/postoptimings', (req, res) => {
//     console.log('Received data:', req.body);
//     const slotsArray = req.body.slotsArray;
 
//     const sql = 'INSERT INTO doctor_op_timings (doctor_id, days, from_time, to_time) VALUES ?';
 
//     const values = [];
 
//     for (const { day, doctor_id, slots } of slotsArray) { // Corrected the destructuring here
//       for (const { from, to } of slots) {
//         values.push([doctor_id, day, from, to]);
//       }
//     }
 
//     Pool.query(sql, [values], (err, result) => {
//       if (err) {
//         console.error('Error inserting data:', err);
//         res.status(500).send('Internal Server Error');
//       } else {
//         console.log('Data inserted successfully:', result);
//         res.status(200).send('Data inserted successfully');
//       }
//     });
//   });
//   app.post('/api/postoptimings', (req, res) => {
//     console.log('Received data:', req.body);
//     const { slotsArray, doctor_id } = req.body; // Destructure doctor_id from req.body
 
//     const sql = 'INSERT INTO doctor_op_timings (doctor_id, days, from_time, to_time) VALUES ?';
 
//     const values = [];
//     const days = Object.keys(slotsArray);
//     for (const day of days) {
//         for (const { from, to } of slotsArray[day]) {
//             values.push([doctor_id, day, from, to]); // Use doctor_id from request body
//         }
//     }
 
//     Pool.query(sql, [values], (err, result) => {
//         if (err) {
//             console.error('Error inserting data:', err);
//             res.status(500).send('Internal Server Error');
//         } else {
//             console.log('Data inserted successfully:', result);
//             res.status(200).send('Data inserted successfully');
//         }
//     });
// });

app.post('/api/postoptimings', (req, res) => {
    console.log('Received data:', req.body);
    const { slotsArray, doctor_id, doctor_name, date } = req.body; // Destructure doctor_id from req.body
 
    // Check if the date is already selected for the doctor_id
    const checkSql = 'SELECT * FROM doctor_op_timings WHERE doctor_id = ? AND date = ?';
    Pool.query(checkSql, [doctor_id, date], (checkErr, checkResult) => {
        if (checkErr) {
            console.error('Error checking existing data:', checkErr);
            res.status(500).send('Internal Server Error');
            return;
        }
 
        if (checkResult.length > 0) {
            // If a record already exists, return a message
            res.status(400).send('The date is already selected for this doctor');
            return;
        }
 
        // If the date is not selected, proceed with inserting the slotsArray data
        const insertSql = 'INSERT INTO doctor_op_timings (doctor_id, doctor_name, days, from_time, to_time, date) VALUES ?';
        const values = [];
        const days = Object.keys(slotsArray);
        for (const day of days) {
            for (const { from, to } of slotsArray[day]) {
                values.push([doctor_id, doctor_name, day, from, to, date]); // Use doctor_id from request body
            }
        }
 
        Pool.query(insertSql, [values], (insertErr, result) => {
            if (insertErr) {
                console.error('Error inserting data:', insertErr);
                res.status(500).send('Internal Server Error');
            } else {
                console.log('Data inserted successfully:', result);
                res.status(200).send('Data inserted successfully');
            }
        });
    });
});

app.get("/api/get", (req, res) => {
    const sqlGet = "SELECT * FROM admin_doctors";
    Pool.query(sqlGet, (error, result) => {
        res.send(result);
    });
});




let hospitals = [];

app.get('/api/Hospitals/list', (req, res) => {
  const query = 'SELECT HospitalFullName FROM Hospital_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Hospitals data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      hospitals = results;

      res.json(results);
    }
  });
});


app.get('/api/hospitalDetails', async (req, res) => {
  const hospitalName = req.query.name;

  console.log('Received request for hospital details with name:', hospitalName);

  try {
    // Use a promise-compatible version of the query interface
    const [results, fields] = await Pool.promise().query(
      'SELECT * FROM Hospital_Details WHERE HospitalFullName = ?',
      [hospitalName]
    );

    if (results.length > 0) {
      const selectedHospital = results[0];
      res.json({ hospitalDetails: selectedHospital });
    } else {
      console.log(`Hospital details not found for: ${hospitalName}`);
      res.status(404).json({ error: `Hospital details not found for: ${hospitalName}` });
    }
  } catch (error) {
    console.error('Error fetching hospital details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/api/Hospitals', (req, res) => {
  const query = 'SELECT * FROM Hospital_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching hospital data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/Hospitals', (req, res) => {
  const hospitalData = req.body;

  if (!hospitalData.HospitalFullName || !hospitalData.AuthorisedPerson ||!hospitalData.PrimaryAppointmentContactNumber ||!hospitalData.SecondaryAppointmentContactNumber ||!hospitalData.PrimaryEmail ||!hospitalData.SecondaryEmail ||!hospitalData.City ||!hospitalData.Country ||!hospitalData.Address ||!hospitalData.Website ||!hospitalData.Tagline ||!hospitalData.YearOfEstablishmentBranch ||!hospitalData.YearOfEstablishmentGroup ||!hospitalData.AppointmentBookingFacility ||!hospitalData.Cash ||!hospitalData.CreditCard ||!hospitalData.Cheque ||!hospitalData.DebitCard ||!hospitalData.OnlinePayment ||!hospitalData.AboutTheHospital ||!hospitalData.Days ||!hospitalData.StartTime ||!hospitalData.EndTime ||!hospitalData.NameOfInsuranceProvidersAssociated ||!hospitalData.EmergencyPhoneNumber ||!hospitalData.NumberOfAmbulances ||!hospitalData.BlooPoolank ||!hospitalData.AwardName ||!hospitalData.AwardingYear ||!hospitalData.CouncilName ||!hospitalData.ValidUpto ||!hospitalData.Type ||!hospitalData.NumberOfDoctors ||!hospitalData.NoOfBeds ||!hospitalData.Facilities ||!hospitalData.Specialities ||!hospitalData.EmergencyProcedures ||!hospitalData.AboutEmergencyServices ) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const insertQuery = 'INSERT INTO Hospital_Details SET ?';

  Pool.query(insertQuery, hospitalData, (queryErr, results) => {
    if (queryErr) {
      console.error('Error adding hospital:', queryErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ message: 'Hospital data inserted successfully' });
    }
  });
});

app.put('/api/Hospitals/:HospitalFullName', (req, res) => {
  const { HospitalFullName } = req.params;
  const updatedHospitalData = req.body;

  const query = 'UPDATE Hospital_Details SET ? WHERE HospitalFullName = ?';

  Pool.query(query, [updatedHospitalData, HospitalFullName], (err, results) => {
    if (err) {
      console.error('Error updating hospital:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedHospitalData);
    }
  });
});

app.delete('/api/Hospitals/:HospitalFullName', (req, res) => {
  const { HospitalID } = req.params;

  const query = 'DELETE FROM Hospital_Details WHERE HospitalFullName = ?';

  Pool.query(query, [HospitalID], (err, results) => {
    if (err) {
      console.error('Error deleting hospital:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Hospital not found' });
      } else {
        res.json({ message: 'Hospital deleted successfully' });
      }
    }
  });
});


let Clinics = [];

app.get('/api/Clinics/list', (req, res) => {
  const query = 'SELECT clinic_name FROM clinics';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching clinics data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      Clinics = results;

      res.json(results);
    }
  });
});


app.get('/api/clinicDetails', async (req, res) => {
  const clinicName = req.query.name;

  console.log('Received request for clinic details with name:', clinicName);

  try {
    // Use a promise-compatible version of the query interface
    const [results, fields] = await Pool.promise().query(
      'SELECT * FROM clinics WHERE clinic_name = ?',
      [clinicName]
    );

    if (results.length > 0) {
      const selectedclinic = results[0];
      res.json({ clinicDetails: selectedclinic });
    } else {
      console.log(`Clinic details not found for: ${clinicName}`);
      res.status(404).json({ error: `Clinic details not found for: ${clinicName}` });
    }
  } catch (error) {
    console.error('Error fetching clinic details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/api/clinics', (req, res) => {
  const query = 'SELECT * FROM clinics';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching clinics data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/clinics', (req, res) => {
  const clinicData = req.body;

  if (!clinicData.clinic_name || !clinicData.city ||!clinicData.country ||!clinicData.clinic_address ||!clinicData.website ||!clinicData.contact_number ||!clinicData.email ||!clinicData.tagline ||!clinicData.year_establishment_branch ||!clinicData.appointment_booking_facility ||!clinicData.mode_of_payment_cash ||!clinicData.mode_of_payment_credit_card ||!clinicData.mode_of_payment_cheque ||!clinicData.mode_of_payment_debit_card ||!clinicData.mode_of_payment_online ||!clinicData.about_the_clinic ||!clinicData.timings ||!clinicData.insurance_providers_associated ||!clinicData.emergency_phone_number ||!clinicData.emergency_procedures ||!clinicData.rating ||!clinicData.Specialities ||!clinicData.services ||!clinicData.filename ||!clinicData.video_filename ||!clinicData.Op_Timings ||!clinicData.Services_1 ) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const insertQuery = 'INSERT INTO clinics SET ?';

  Pool.query(insertQuery, clinicData, (queryErr, results) => {
    if (queryErr) {
      console.error('Error adding clinic:', queryErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ message: 'clinic data inserted successfully' });
    }
  });
});

app.put('/api/clinics/:clinic_name', (req, res) => {
  const { clinic_name } = req.params;
  const updatedClinicData = req.body;

  const query = 'UPDATE clinics SET ? WHERE clinic_name = ?';

  Pool.query(query, [updatedClinicData, clinic_name], (err, results) => {
    if (err) {
      console.error('Error updating clinics:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedClinicData);
    }
  });
});

app.delete('/api/clinics/:clinic_name', (req, res) => {
  const { ClinicID } = req.params;

  const query = 'DELETE FROM clinics WHERE clinic_name = ?';

  Pool.query(query, [ClinicID], (err, results) => {
    if (err) {
      console.error('Error deleting Clinic:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Clinic not found' });
      } else {
        res.json({ message: 'Clinic deleted successfully' });
      }
    }
  });
});

let doctors = [];

app.get('/api/Doctors/list', (req, res) => {
  const query = 'SELECT DoctorName FROM Doctors_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Doctor data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      doctors = results;

      res.json(results);
    }
  });
});


app.get('/api/DoctorsDetails', async (req, res) => {
  const DoctorName = req.query.name;

  console.log('Received request for Doctor details with name:', DoctorName);

  try {
    // Use a promise-compatible version of the query interface
    const [results, fields] = await Pool.promise().query(
      'SELECT * FROM Doctors_Details WHERE DoctorName = ?',
      [DoctorName]
    );

    if (results.length > 0) {
      const selectedHospital = results[0];
      res.json({ DoctorDetails: selectedHospital });
    } else {
      console.log(`Doctor details not found for: ${DoctorName}`);
      res.status(404).json({ error: `Doctor details not found for: ${DoctorName}` });
    }
  } catch (error) {
    console.error('Error fetching Doctor details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/api/Doctors', (req, res) => {
  const query = 'SELECT * FROM Doctors_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Doctor data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/Doctors', (req, res) => {
  const DoctorsData = req.body;

  if (!DoctorsData.DoctorName || !DoctorsData.RegistrationNo ||!DoctorsData.Email ||!DoctorsData.ContactNo ||!DoctorsData.Designation ||!DoctorsData.Degree ||!DoctorsData.CollegeName ||!DoctorsData.CompletionYear ||!DoctorsData.TreatmentsOffered ||!DoctorsData.ConsultationFee ||!DoctorsData.YearsOfExperience ||!DoctorsData.Awards ||!DoctorsData.Department ||!DoctorsData.Memberships ||!DoctorsData.PublicationsLink ||!DoctorsData.Monday ||!DoctorsData.Tuesday ||!DoctorsData.Wednesday ||!DoctorsData.Thursday ||!DoctorsData.Friday ||!DoctorsData.Saturday ||!DoctorsData.Sunday ||!DoctorsData.OrganisationName ||!DoctorsData.Tenure ||!DoctorsData.Role ||!DoctorsData.Council ||!DoctorsData.CouncilRegistrationNo ||!DoctorsData.filename ||!DoctorsData.Specializations ||!DoctorsData.Languages) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const insertQuery = 'INSERT INTO Doctors_Details SET ?';

  Pool.query(insertQuery, DoctorsData, (queryErr, results) => {
    if (queryErr) {
      console.error('Error adding Doctors:', queryErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ message: 'Doctor data inserted successfully' });
    }
  });
});

app.put('/api/Doctors/:DoctorName', (req, res) => {
  const { DoctorName } = req.params;
  const updatedDoctorData = req.body;

  const query = 'UPDATE Doctors_Details SET ? WHERE DoctorName = ?';

  Pool.query(query, [updatedDoctorData, DoctorName], (err, results) => {
    if (err) {
      console.error('Error updating Doctor:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedDoctorData);
    }
  });
});

app.delete('/api/Doctors/:DoctorName', (req, res) => {
  const { Doctor_Id } = req.params;

  const query = 'DELETE FROM Doctors_Details WHERE DoctorName = ?';

  Pool.query(query, [Doctor_Id], (err, results) => {
    if (err) {
      console.error('Error deleting Doctor:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Doctor not found' });
      } else {
        res.json({ message: 'Doctor deleted successfully' });
      }
    }
  });
});




let DiagnosticLab = [];

app.get('/api/Diagnostics/list', (req, res) => {
  const query = 'SELECT LabName FROM DiagnosticsLab_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Diagnostics data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      DiagnosticLab = results;

      res.json(results);
    }
  });
});


app.get('/api/DiagnosticDetails', async (req, res) => {
  const LabName = req.query.name;

  console.log('Received request for Diagnostic details with name:', LabName);

  try {
    // Use a promise-compatible version of the query interface
    const [results, fields] = await Pool.promise().query(
      'SELECT * FROM DiagnosticsLab_Details WHERE LabName = ?',
      [LabName]
    );

    if (results.length > 0) {
      const selectedHospital = results[0];
      res.json({ DiagnosticDetails: selectedHospital });
    } else {
      console.log(`Diagnostic details not found for: ${LabName}`);
      res.status(404).json({ error: `Diagnostic details not found for: ${LabName}` });
    }
  } catch (error) {
    console.error('Error fetching Diagnostic details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/api/Diagnostics', (req, res) => {
  const query = 'SELECT * FROM DiagnosticsLab_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Diagnostics data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/Diagnostics', (req, res) => {
  const DiagnosticsData = req.body;

  if (!DiagnosticsData.LabName || !DiagnosticsData.Location ||!DiagnosticsData.ContactNumber ||!DiagnosticsData.Email ||!DiagnosticsData.WorkingHours ||!DiagnosticsData.Website ||!DiagnosticsData.Accreditations ||!DiagnosticsData.TechnologiesUsed ||!DiagnosticsData.BookingAppAvailable ||!DiagnosticsData.EmergencyServices ||!DiagnosticsData.HomeCollectionServices ||!DiagnosticsData.ReportsDeliveryTime ||!DiagnosticsData.PaymentModesAccepted ||!DiagnosticsData.LabSpecialty ||!DiagnosticsData.LabCapacity ||!DiagnosticsData.StaffCount ||!DiagnosticsData.LabCertifications ||!DiagnosticsData.LabBranches ||!DiagnosticsData.LabAffiliations ||!DiagnosticsData.LabRating ||!DiagnosticsData.LabComments ||!DiagnosticsData.ServicesOffered ) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const insertQuery = 'INSERT INTO DiagnosticsLab_Details SET ?';

  Pool.query(insertQuery, DiagnosticsData, (queryErr, results) => {
    if (queryErr) {
      console.error('Error adding Diagnostics:', queryErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ message: 'Diagnostics data inserted successfully' });
    }
  });
});

app.put('/api/Diagnostics/:LabName', (req, res) => {
  const { LabName } = req.params;
  const updatedDiagnosticsData = req.body;

  const query = 'UPDATE DiagnosticsLab_Details SET ? WHERE LabName = ?';

  Pool.query(query, [updatedDiagnosticsData, LabName], (err, results) => {
    if (err) {
      console.error('Error updating Diagnostics:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedDiagnosticsData);
    }
  });
});

app.delete('/api/Diagnostics/:LabName', (req, res) => {
  const { LabID } = req.params;

  const query = 'DELETE FROM DiagnosticsLab_Details WHERE LabName = ?';

  Pool.query(query, [LabID], (err, results) => {
    if (err) {
      console.error('Error deleting Diagnostics:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Diagnostics not found' });
      } else {
        res.json({ message: 'Diagnostics deleted successfully' });
      }
    }
  });
});


let Ambulance = [];

app.get('/api/Ambulance/list', (req, res) => {
  const query = 'SELECT AmbulanceFullName FROM Ambulance_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Ambulance data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      Ambulance = results;

      res.json(results);
    }
  });
});


app.get('/api/AmbulanceDetails', async (req, res) => {
  const AmbulanceName = req.query.name;

  console.log('Received request for Ambulance details with name:', AmbulanceName);

  try {
    // Use a promise-compatible version of the query interface
    const [results, fields] = await Pool.promise().query(
      'SELECT * FROM Ambulance_Details WHERE AmbulanceFullName = ?',
      [AmbulanceName]
    );

    if (results.length > 0) {
      const selectedHospital = results[0];
      res.json({ AmbulanceDetails: selectedHospital });
    } else {
      console.log(`Ambulance details not found for: ${AmbulanceName}`);
      res.status(404).json({ error: `Ambulance details not found for: ${AmbulanceName}` });
    }
  } catch (error) {
    console.error('Error fetching Ambulance details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/api/Ambulance', (req, res) => {
  const query = 'SELECT * FROM Ambulance_Details';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching Ambulance data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/Ambulance', (req, res) => {
  const AmbulanceData = req.body;

  if (!AmbulanceData.AmbulanceFullName || !AmbulanceData.RegistrationNumber ||!AmbulanceData.VehicleType ||!AmbulanceData.VehicleCondition ||!AmbulanceData.AdditionalEquipment ||!AmbulanceData.Model ||!AmbulanceData.Manufacturer ||!AmbulanceData.YearOfManufacture ||!AmbulanceData.CurrentMileage ||!AmbulanceData.Status ||!AmbulanceData.EquipmentAvailability ||!AmbulanceData.OxygenSupply ||!AmbulanceData.DefibrillatorAvailability ||!AmbulanceData.MedicalSuppliesAvailability ||!AmbulanceData.LastMaintenanceDate ||!AmbulanceData.InsuranceExpirationDate ||!AmbulanceData.CommunicationSystem ||!AmbulanceData.ServiceHistory ) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const insertQuery = 'INSERT INTO Ambulance_Details SET ?';

  Pool.query(insertQuery, AmbulanceData, (queryErr, results) => {
    if (queryErr) {
      console.error('Error adding Ambulance:', queryErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ message: 'Ambulance data inserted successfully' });
    }
  });
});

app.put('/api/Ambulance/:AmbulanceFullName', (req, res) => {
  const { AmbulanceFullName } = req.params;
  const updatedAmbulanceData = req.body;

  const query = 'UPDATE Ambulance_Details SET ? WHERE AmbulanceFullName = ?';

  Pool.query(query, [updatedAmbulanceData, AmbulanceFullName], (err, results) => {
    if (err) {
      console.error('Error updating Ambulance:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedAmbulanceData);
    }
  });
});

app.delete('/api/Ambulance/:AmbulanceFullName', (req, res) => {
  const { AmbulanceID } = req.params;

  const query = 'DELETE FROM Ambulance_Details WHERE AmbulanceFullName = ?';

  Pool.query(query, [AmbulanceID], (err, results) => {
    if (err) {
      console.error('Error deleting Ambulance:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Ambulance not found' });
      } else {
        res.json({ message: 'Ambulance deleted successfully' });
      }
    }
  });
});


let patients = [];

app.get('/api/Patients/list', (req, res) => {
  const query = 'SELECT name FROM appointment_booking';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching patients data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      patients = results;

      res.json(results);
    }
  });
});


app.get('/api/patientDetails', async (req, res) => {
  const patientName = req.query.name;

  console.log('Received request for patient details with name:', patientName);

  try {
    // Use a promise-compatible version of the query interface
    const [results, fields] = await Pool.promise().query(
      'SELECT * FROM appointment_booking WHERE name = ?',
      [patientName]
    );

    if (results.length > 0) {
      const selectedHospital = results[0];
      res.json({ patientDetails: selectedHospital });
    } else {
      console.log(`Patient details not found for: ${patientName}`);
      res.status(404).json({ error: `Patient details not found for: ${patientName}` });
    }
  } catch (error) {
    console.error('Error fetching Patient details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/api/Patients', (req, res) => {
  const query = 'SELECT * FROM appointment_booking';

  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching patients data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/Patients', (req, res) => {
  const patientData = req.body;

  if (!patientData.name || !patientData.contact ||!patientData.email ||!patientData.address ||!patientData.booking_date ||!patientData.clinic_name ||!patientData.doctor_name ||!patientData.slot_time ||!patientData.consultation_fee ||!patientData.weight ||!patientData.height ||!patientData.temperature ||!patientData.blood_pressure ||!patientData.paymentMode ||!patientData.status ||!patientData.cancellationReasons ) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const insertQuery = 'INSERT INTO appointment_booking SET ?';

  Pool.query(insertQuery, patientData, (queryErr, results) => {
    if (queryErr) {
      console.error('Error adding patient:', queryErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json({ message: 'Patients data inserted successfully' });
    }
  });
});

app.put('/api/Patients/:name', (req, res) => {
  const { name } = req.params;
  const updatedPatientData = req.body;

  const query = 'UPDATE appointment_booking SET ? WHERE name = ?';

  Pool.query(query, [updatedPatientData, name], (err, results) => {
    if (err) {
      console.error('Error updating patient:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedPatientData);
    }
  });
});

app.delete('/api/Patients/:name', (req, res) => {
  const { PatientID } = req.params;

  const query = 'DELETE FROM appointment_booking WHERE name = ?';

  Pool.query(query, [PatientID], (err, results) => {
    if (err) {
      console.error('Error deleting Patient:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Patient not found' });
      } else {
        res.json({ message: 'Patient deleted successfully' });
      }
    }
  });
});








// // Nodemailer configuration
// app.post('/users', async (req, res) => {
//   const { username, password, Primary_name, Secondary_name, email, role, contact_number, managing_admin } = req.body;

//   const userQuery = 'INSERT INTO AddAdmins (username, password, Primary_name, Secondary_name, email, role, contact_number, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
//   Pool.query(userQuery, [username, password, Primary_name, Secondary_name, email, role, contact_number, managing_admin], async (userErr, userResults) => {
//     if (userErr) {
//       console.error('Error during signup:', userErr);
//       res.status(500).send('Error during signup');
//       return;
//     }

//     // Retrieve the auto-generated user_id
//     const userId = userResults.insertId;

//     // Construct the detail query based on the role
//     let detailQuery;
//     let detailValues;
//     if (role === 'admin') {
//       detailQuery = 'INSERT INTO admin_details (user_id, username, email, contact_number, password) VALUES (?, ?, ?, ?, ?)';
//       detailValues = [userId, username, email, contact_number, password];
//     } else if (role === 'Super Admin') {
//       detailQuery = 'INSERT INTO superadmin_details (user_id, username, email, contact_number, password) VALUES (?, ?, ?,?, ?)';
//       detailValues =[userId, username, email, contact_number, password];
//     } else {
//       detailQuery = 'INSERT INTO user_details (user_id,username ,email, contact_number , password) VALUES (?, ?, ?, ?, ?)';
//       detailValues = [userId, username, email, contact_number, password];
//     }

//     // Perform the detail insertion
//     Pool.query(detailQuery, detailValues, async (detailErr, detailResults) => {
//       if (detailErr) {
//         console.error(`Error during ${role} signup:`, detailErr);
//         res.status(500).send(`Error during ${role} signup`);
//         return;
//       }

//       // Send welcome email
//       const mailOptions = {
//         from: 'sisindrareddy143@gmail.com',
//         to: email,
//         subject: 'Welcome to our platform!',
//         text: `Dear ${username},\n\nThank you for signing up with us!\n\nYour account details:\nName: ${username}\nEmail: ${email}\nPhone Number: ${contact_number}\nRole: ${role}\n\nBest regards,\nThe Hospi Team`
//       };

//       try {
//         await transporter.sendMail(mailOptions);
//         res.status(201).send('Signup successful! Welcome email sent.');
//       } catch (emailErr) {
//         console.error('Error sending welcome email:', emailErr);
//         res.status(500).send('Signup successful, but failed to send welcome email.');
//       }
//     });
//   });
// });




// app.post('/api/login', (req, res) => {
//   const { username, password } = req.body;

//   const query = 'SELECT * FROM AddAdmins WHERE username = ? AND password = ?';
//   Pool.query(query, [username, password], (err, results) => {
//     if (err) {
//       console.error('Error during login:', err);
//       res.status(500).send('Error during login');
//       return;
//     }

//     if (results.length > 0) {
//       res.json(results[0]);
//     } else {
//       res.status(401).send('Invalid credentials');
//     }
//   });
// });

// app.get('/api/users', (req, res) => {
//   const query = 'SELECT * FROM AddAdmins';

//   Pool.query(query, (err, results) => {
//     if (err) {
//       console.error('Error fetching users:', err);
//       res.status(500).send('Error fetching users');
//       return;
//     }

//     res.json(results);
//   });
// });
// app.get('/api/userdetails/:userId', (req, res) => {
//   const userId = req.params.userId;

//   const query = 'SELECT * FROM AddAdmins WHERE adminID = ?';

//   Pool.query(query, [userId], (err, results) => {
//     if (err) {
//       console.error('Error fetching user details:', err);
//       res.status(500).send('Error fetching user details');
//       return;
//     }

//     // Ensure that the query returns exactly one row
//     if (results.length === 1) {
//       res.json(results[0]); // Send the first (and only) row of the result
//     } else {
//       res.status(404).send('User details not found');
//     }
//   });
// });
// // app.get('/api/adminuserdetails/:userId', (req, res) => {
// //   const userId = req.params.userId;

// //   const query = 'SELECT * FROM admin_details WHERE user_id = ?';

// //   Pool.query(query, [userId], (err, results) => {
// //     if (err) {
// //       console.error('Error fetching user details:', err);
// //       res.status(500).send('Error fetching user details');
// //       return;
// //     }

// //     // Ensure that the query returns exactly one row
// //     if (results.length === 1) {
// //       res.json(results[0]); // Send the first (and only) row of the result
// //     } else {
// //       res.status(404).send('User details not found');
// //     }
// //   });
// // });


// app.get('/api/adminuserdetails/:userId', (req, res) => {
//   const userId = req.params.userId;

//   const query = 'SELECT * FROM AddAdmins WHERE adminID = ?';

//   Pool.query(query, [userId], (err, results) => {
//     if (err) {
//       console.error('Error fetching user details:', err);
//       res.status(500).json({ error: 'Error fetching user details' });
//       return;
//     }

//     if (results.length === 1) {
//       res.json(results[0]);
//     } else {
//       res.status(404).json({ error: 'User details not found' });
//     }
//   });
// })

// app.get('/api/superadminuserdetails/:userId', (req, res) => {
//   const userId = req.params.userId;

//   const query = 'SELECT * FROM AddAdmins WHERE adminID = ?';

//   Pool.query(query, [userId], (err, results) => {
//     if (err) {
//       console.error('Error fetching super admin user details:', err);
//       res.status(500).send('Error fetching super admin user details');
//       return;
//     }

//     // Ensure that the query returns exactly one row
//     if (results.length === 1) {
//       res.json(results[0]); // Send the first (and only) row of the result
//     } else {
//       res.status(404).send('Super admin user details not found');
//     }
//   });
// });

// // Add a new endpoint for forgot password
// app.post('/forgot-password', (req, res) => {
//   const { email } = req.body;

//   // Generate OTP
//   const otp = generateOTP();

//   // Save OTP in the database
//   const insertQuery = `INSERT INTO otps (email, otp) VALUES (?, ?)`;
//   Pool.query(insertQuery, [email, otp], (insertError, insertResults) => {
//     if (insertError) {
//       console.error('Error during forgot password:', insertError);
//       res.status(500).send('Error during forgot password');
//       return;
//     }

//     // Send OTP email
//     sendOTPEmail(email, otp);

//     res.send('OTP sent successfully');
//   });
// });

// // Add a new endpoint for resetting password
// // app.post('/reset-password', (req, res) => {
// //   const { email, otp, newPassword } = req.body;

// //   // Verify OTP
// //   const selectQuery = `SELECT otp FROM otps WHERE email = ? ORDER BY id DESC LIMIT 1`;
// //   Pool.query(selectQuery, [email], (selectError, selectResults) => {
// //     if (selectError) {
// //       console.error('Error during password reset:', selectError);
// //       res.status(500).send('Error during password reset');
// //       return;
// //     }

// //     if (selectResults.length === 0 || selectResults[0].otp !== otp) {
// //       res.status(401).send('Invalid OTP');
// //       return;
// //     }

// //     const updateQuery = `UPDATE AddAdmins SET password = ? WHERE email = ?`;
// //     Pool.query(updateQuery, [newPassword, email], (updateError, updateResults) => {
// //       if (updateError) {
// //         console.error('Error during password reset:', updateError);
// //         res.status(500).send('Error during password reset');
// //         return;
// //       }

// //       // Delete the used OTP
// //       const deleteQuery = `DELETE FROM otps WHERE email = ? AND otp = ?`;
// //       Pool.query(deleteQuery, [email, otp], (deleteError, deleteResults) => {
// //         if (deleteError) {
// //           console.error('Error during password reset:', deleteError);
// //           res.status(500).send('Error during password reset');
// //           return;
// //         }

// //         res.send('Password reset successfully');
// //       });
// //     });
// //   });
// // });

// app.post('/reset-password', (req, res) => {
//   const { email, otp, newPassword } = req.body;

//   // Verify OTP
//   const selectQuery = `SELECT otp FROM otps WHERE email = ? ORDER BY id DESC LIMIT 1`;
//   Pool.query(selectQuery, [email], (selectError, selectResults) => {
//     if (selectError) {
//       console.error('Error during password reset:', selectError);
//       res.status(500).send('Error during password reset');
//       return;
//     }

//     if (selectResults.length === 0 || selectResults[0].otp !== otp) {
//       res.status(401).send('Invalid OTP');
//       return;
//     }

//     const updateQuery = `UPDATE AddAdmins SET password = ? WHERE email = ?`;
//     Pool.query(updateQuery, [newPassword, email], (updateError, updateResults) => {
//       if (updateError) {
//         console.error('Error during password reset:', updateError);
//         res.status(500).send('Error during password reset');
//         return;
//       }

//       // Delete the used OTP
//       const deleteQuery = `DELETE FROM otps WHERE email = ? AND otp = ?`;
//       Pool.query(deleteQuery, [email, otp], (deleteError, deleteResults) => {
//         if (deleteError) {
//           console.error('Error during password reset:', deleteError);
//           res.status(500).send('Error during password reset');
//           return;
//         }

//         res.send('Password reset successfully');
//       });
//     });
//   });
// });

// app.post('/api/logout', (req, res) => {
//   const { sessionDuration } = req.body;
//   const userId = req.user.adminID; // Assuming you have implemented user authentication and stored user information in req.user

//   // Update user's session duration in the database
//   const updateQuery = `UPDATE AddAdmins SET session_duration = ? WHERE adminID = ?`;
//   Pool.query(updateQuery, [sessionDuration, userId], (err, results) => {
//     if (err) {
//       console.error('Error updating session duration:', err);
//       res.status(500).send('Error updating session duration');
//       return;
//     }

//     res.send('Session duration updated successfully');
//   });
// });



































app.get('/api/admins', (req, res) => {
  const { role } = req.query;
  let query = 'SELECT * FROM AddAdmins';

  if (role) {
    query += ` WHERE role = '${role}'`;
  }

  // Use the connection Pool to handle database connections
  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    connection.query(query, (queryErr, results) => {
      connection.release(); // Release the connection back to the Pool

      if (queryErr) {
        console.error('Error fetching admins:', queryErr);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        res.json(results);
      }
    });
  });
});

app.get('/api/admins/managingAdmins', (req, res) => {
  const { role } = req.query;

  const query = 'SELECT managing_admin FROM AddAdmins WHERE role = ?';

  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    connection.query(query, [role], (queryErr, results) => {
      connection.release();

      if (queryErr) {
        console.error('Error fetching managing admins:', queryErr);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        const managingAdmins = results.map((result) => result.managing_admin);
        res.json(managingAdmins);
      }
    });
  });
});

// Add a new API endpoint to get the list of managing admins
app.get('/api/managingAdmins', (req, res) => {
  const query = 'SELECT DISTINCT managing_admin FROM AddAdmins';

  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    connection.query(query, (queryErr, results) => {
      connection.release();

      if (queryErr) {
        console.error('Error fetching managing admins:', queryErr);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        const managingAdmins = results.map((result) => result.managing_admin);
        res.json(managingAdmins);
      }
    });
  });
});


// Create an API endpoint to add admins
app.post('/api/admins', (req, res) => {
  const { username, password, Primary_name, Secondary_name, email, contact_number, role, managing_admin } = req.body;

  // Validate the request body
  if (!username || !password || !Primary_name || !Secondary_name || !email || !contact_number || !role || !managing_admin) {
    return res.status(400).json({ error: 'Invalid request. Please provide username, email, and password.' });
  }

  const insertQuery = 'INSERT INTO AddAdmins (username, password, Primary_name, Secondary_name, email, contact_number, role, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [username, password, Primary_name, Secondary_name, email, contact_number, role, managing_admin];

  // Use the connection Pool to handle database connections
  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    connection.query(insertQuery, values, (queryErr, results) => {
      connection.release(); // Release the connection back to the Pool

      if (queryErr) {
        console.error('Error adding admin:', queryErr);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        res.status(201).json({ Message: 'Data Inserted Succesfully' }); 
      }
    });
  });
});

app.put('/api/admins/:adminID', (req, res) => {
  const { adminID } = req.params;
  const updatedAdminData = req.body;

  const query = 'UPDATE AddAdmins SET ? WHERE adminID = ?';

  Pool.query(query, [updatedAdminData, adminID], (err, results) => {
    if (err) {
      console.error('Error updating admin:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedAdminData);
    }
  });
});

app.delete('/api/admins/:adminID', (req, res) => {
  const { adminID } = req.params;

  const query = 'DELETE FROM AddAdmins WHERE adminID = ?';

  Pool.query(query, [adminID], (err, results) => {
    if (err) {
      console.error('Error deleting admin:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Admin not found' });
      } else {
        res.json({ message: 'Admin deleted successfully' });
      }
    }
  });
});

app.get('/api/get/doctortimings/:doctor_id/:value', (req, res) => {
  const { doctor_id, value } = req.params;
  const sqlGet = "SELECT * FROM doctor_op_timings WHERE doctor_id = ? and days = ?";
  Pool.query(sqlGet, [doctor_id, value], (error, results) => {
    if (error) {
      console.error('Error fetching doctor timings:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.json(results);
  });
});
app.get('/api/get/doctortimings/:doctor_id/:value/:date', (req, res) => {
  const { doctor_id, value, date } = req.params;
  const sqlGet = "SELECT * FROM doctor_op_timings WHERE doctor_id = ? AND days = ? AND DATE(date) = ?  ";
  Pool.query(sqlGet, [doctor_id, value, date], (error, results) => {
    if (error) {
      console.error('Error fetching doctor timings:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.json(results);
  });
});

// app.get('/api/get/doctortimings/:doctor_id/:value', (req, res) => {
//     const { doctor_id, value } = req.params;
//     const sqlGet = "SELECT * FROM doctor_op_timings WHERE doctor_id = ? and days = ?";
//     Pool.query(sqlGet, [doctor_id, value], (error, results) => {
//       if (error) {
//         console.error('Error fetching doctor timings:', error);
//         res.status(500).json({ error: 'Internal server error' });
//         return;
//       }
//       if (results.length > 0) {
//         res.status(400).json({ error: 'Timing already exists' });
//         return;
//       }
//       // If no duplicate, continue with your logic
//       // For example, insert the new timing
//       // const sqlInsert = "INSERT INTO doctor_op_timings (doctor_id, days, from_time, to_time) VALUES (?, ?, ?, ?)";
//       // Pool.query(sqlInsert, [doctor_id, days, from_time, to_time], (error, results) => {
//       //   if (error) {
//       //     console.error('Error inserting doctor timing:', error);
//       //     res.status(500).json({ error: 'Internal server error' });
//       //     return;
//       //   }
//       //   res.json({ message: 'Timing added successfully' });
//       // });
//     });
//   });

app.delete('/api/deleteall/doctortiming/:doctor_id/:date', (req, res) => {
  const {  doctor_id , date} = req.params;
  const query = `DELETE FROM doctor_op_timings WHERE  doctor_id = ? AND DATE(date) = ?`;
  Pool.query(query, [ doctor_id, date], (error, results) => {
    if (error) {
      console.error('Error deleting doctor timings for the day:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.json({ message: 'All timings for the day deleted successfully' });
  });
});


app.get('/api/locationss3', (req, res) => {
  const query = 'SELECT * FROM location'; 
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    res.json(results);
  });
});

app.get("/api", (req, res) => {
  return  res.json({message : "welcome to ambulance service"});
})


// const client = new Client();
 
// client.on('qr', (qrCode) => {
//   // Display QR code for user to scan
//   qrcode.generate(qrCode, { small: true });
// });
 
// client.on('ready', () => {
//   console.log('WhatsApp client is ready');
// });


 
// app.post('/send-whatsapp-notification', (req, res) => {
//   const { phoneNumber, message } = req.body;
 
//   // Send WhatsApp message
//   client
//     .sendMessage(`${phoneNumber}@c.us`, message)
//     .then((response) => {
//       console.log('Message sent:', response);
//       res.status(200).json({ success: true });
//     })
//     .catch((error) => {
//       console.error('Error sending message:', error);
//       res.status(500).json({ success: false, error: error.message });
//     });
// });


app.get('/api/fare_breakup', (req, res) => {
  const query = 'SELECT * FROM fare_breakup ORDER BY id DESC LIMIT 1';
 
  Pool.query(query, (error, results) => {
    if (error) {
      console.error('Error fetching fare details:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      const fareDetails = results[0];
      res.json(fareDetails);
    }
  });
});


app.post('/api/booking', (req, res) => {

  const { CName, Email, Phone_No, Payment_mode, Payment_type, Dcity, Dstate } = req.body;

  // Validate the request body
  if (!CName || !Email || !Phone_No || !Payment_mode || !Payment_type || !Dcity || !Dstate) {
    return res.status(400).json({ error: 'Invalid request. Please provide username, email, and password.' });
  }

  const insertQuery = 'INSERT INTO ambulance_booking (CName, Email, Phone_No, Payment_mode, Payment_type, Dcity, Dstate) VALUES (?, ?, ?, ?, ?, ?, ?)';
  const values = [CName, Email, Phone_No, Payment_mode, Payment_type, Dcity, Dstate];

  // Use the connection Pool to handle database connections
  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    connection.query(insertQuery, values, (queryErr, results) => {
      connection.release(); // Release the connection back to the Pool

      if (queryErr) {
        console.error('Error booking ambulanca:', queryErr);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        res.status(201).json({ Message: 'Data Inserted Succesfully' }); 
      }
    });
  });
});

// app.post('/api/fare_breakup', (req, res) => {

//   const { distance, base_fare, driver_allowance, gst, additional_charge, total_cost } = req.body;

//   // Validate the request body
//   if (!distance || !base_fare || !driver_allowance || !gst || !additional_charge || !total_cost ) {
//     return res.status(400).json({ error: 'Invalid request. Please provide username, email, and password.' });
//   }

//   const insertQuery = 'INSERT INTO fare_breakup (distance, base_fare, driver_allowance, gst, additional_charge, total_cost) VALUES (?, ?, ?, ?, ?, ?)';
//   const values = [distance, base_fare, driver_allowance, gst, additional_charge, total_cost];

//   // Use the connection Pool to handle database connections
//   Pool.getConnection((err, connection) => {
//     if (err) {
//       console.error('Error getting database connection:', err);
//       res.status(500).json({ error: 'Internal Server Error' });
//       return;
//     }

//     connection.query(insertQuery, values, (queryErr, results) => {
//       connection.release(); // Release the connection back to the Pool

//       if (queryErr) {
//         console.error('Error booking ambulanca:', queryErr);
//         res.status(500).json({ error: 'Internal Server Error' });
//       } else {
//         res.status(201).json({ Message: 'Data Inserted Succesfully' }); 
//       }
//     });
//   });
// });


app.post('/api/fare_breakup', (req, res) => {
  const { distance, base_fare, driver_allowance, gst, additional_charge, total_cost } = req.body;

  // Validate the request body
  if (!distance || !base_fare || !driver_allowance || !gst || !additional_charge || !total_cost) {
    return res.status(400).json({ error: 'Invalid request. Please provide distance, base_fare, driver_allowance, gst, additional_charge, and total_cost.' });
  }

  const insertQuery = 'INSERT INTO fare_breakup (distance, base_fare, driver_allowance, gst, additional_charge, total_cost) VALUES (?, ?, ?, ?, ?, ?)';
  const values = [distance, base_fare, driver_allowance, gst, additional_charge, total_cost];

  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    connection.query(insertQuery, values, (queryErr, results) => {
      connection.release(); // Release the connection back to the Pool

      if (queryErr) {
        console.error('Error booking ambulance:', queryErr);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        res.status(201).json({ message: 'Data Inserted Successfully' }); 
      }
    });
  });
});











 
app.get('/slots', (req, res) => {
  console.log('Request Query:', req.query);
  const { date, doctorId } = req.query;
  if (!date) {
    return res.status(400).send('Date parameter is required');
  }
 
  const formattedDate = new Date(date).toISOString();
  const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
 
  Pool.query(`SELECT ${dayOfWeek} FROM bookings WHERE doctor_id = ?`, [doctorId], (error, results) => {
 
    if (error) {
      console.error('Error fetching available slots', error);
      res.status(500).send('Internal Server Error');
    } else {
      const bookedSlotsQuery = `SELECT slot_time FROM trybook WHERE doctor_id = ? AND booking_date = ?`;
      Pool.query(bookedSlotsQuery, [doctorId, date], (err, bookedSlots) => {
        if (err) {
          console.error('Error fetching booked slots', err);
          res.status(500).send('Internal Server Error');
          return;
        }
 
        const availableSlots = results[0][dayOfWeek].split(',').filter(slot => !bookedSlots.some(bookedSlot => bookedSlot.slot_time === slot));
        res.json(availableSlots);
      });
    }
  });
});


app.get('/other-details/:doctorId', async (req, res) => {
  const doctorId = req.params.doctorId;
 
  try {
    const response = await Pool.promise().query('SELECT * FROM bookings WHERE doctor_id = ?', [doctorId]);
   
    const additionalDetails = response[0];
    res.json(additionalDetails);
  } catch (error) {
    console.error('Error fetching additional details', error);
    res.status(500).send('Internal Server Error');
  }
});
 
app.get('/trybook', (req, res) => {
  Pool.query('SELECT * FROM trybook', (error, results) => {
    if (error) {
      console.error('Error fetching trybook data', error);
      res.status(500).send('Internal Server Error');
    } else {
      res.json(results);
    }
  });
});
 

 
app.get('/clinics', (req, res) => {
  const { name, Timings, services, specializations, ratings } = req.query;
  let query = 'SELECT * FROM clinics WHERE 1';
  if (name) query += ` AND clinic_name='${name}'`; 
  if (Timings) query += ` AND timings='${Timings}'`;
  if (services) query += ` AND services LIKE '%${services}%'`;
  if (specializations) query += ` AND specializations LIKE '%${specializations}%'`;
  if (ratings) query += ` AND rating='${ratings}'`;
  Pool.query(query, (err, result) => {
    if (err) {
      res.status(500).send('Error fetching clinics');
    } else {
      res.status(200).send(result);
    }
  });
});

app.get('/hospital', (req, res) => {
  const { name, Timings, services, specializations, ratings } = req.query;
  let query = 'SELECT * FROM Hospital_Details WHERE 1';
  if (name) query += ` AND HospitalFullName='${name}'`; 
  if (Timings) query += ` AND StartTime='${Timings}'`;
  if (services) query += ` AND EndTime LIKE '%${Timings}%'`;
  if (specializations) query += ` AND Days LIKE '%${Days}%'`; 
  if (ratings) query += ` AND rating='${ratings}'`;
  Pool.query(query, (err, result) => {
    if (err) {
      res.status(500).send('Error fetching clinics');
    } else {
      res.status(200).send(result);
    }
  });
});

 
app.get('/clinic-specialties/:clinicId', (req, res) => {
  const clinicId = req.params.clinicId;
 
  Pool.query(
    `SELECT s.specialty_id, s.specialty_name
     FROM specialties s
     INNER JOIN clinic_specialties cs ON s.specialty_id = cs.specialty_id
     WHERE cs.clinic_id = ?`,
    [clinicId],
    (err, result) => {
      if (err) {
        res.status(500).send('Error fetching clinic specialties');
      } else {
        res.status(200).send(result);
      }
    }
  );
});

app.get('/hospital-specialties/:hospiId', (req, res) => {
  const hospiId = req.params.hospiId;
 
  Pool.query(
    `SELECT s.specialty_id, s.specialty_name
     FROM specialties s
     INNER JOIN hospital_specialties cs ON s.specialty_id = cs.specialty_id
     WHERE cs.hospi_id = ?`,
    [hospiId],
    (err, result) => {
      if (err) {-
        res.status(500).send('Error fetching hospital specialties');
      } else {
        res.status(200).send(result);
      }
    }
  );
});
 
app.get('/clinic-doctors/:clinicId/:specialtyId', async (req, res) => {
  const { clinicId, specialtyId } = req.params;
 
  try {
    const doctorsQuery = `
      SELECT d.doctor_id, d.doctor_name
      FROM admin_doctors d
      INNER JOIN doctor_specialties ds ON d.doctor_id = ds.doctor_id
      INNER JOIN doctor_clinic dc ON d.doctor_id = dc.doctor_id
      WHERE dc.clinic_id = ? AND ds.specialty_id = ?
    `;
 
    const doctors = await Pool.promise().query(doctorsQuery, [clinicId, specialtyId]);
   
    res.status(200).send(doctors[0]);
  } catch (error) {
    console.error('Error fetching clinic doctors:', error);
    res.status(500).send('Error fetching clinic doctors');
  }
});

app.get('/hospi-doctors/:hospiId/:specialtyId', async (req, res) => {
  const {hospiId, specialtyId } = req.params;
 
  try {
    const doctorsQuery = `
      SELECT d.doctor_id, d.doctor_name
      FROM admin_doctors d
      INNER JOIN doctor_specialties ds ON d.doctor_id = ds.doctor_id
      INNER JOIN Hospi_doctor dc ON d.doctor_id = dc.doctor_id
      WHERE dc.hospi_id = ? AND ds.specialty_id = ?
    `;
 
    const doctors = await Pool.promise().query(doctorsQuery, [hospiId, specialtyId]);
   
    res.status(200).send(doctors[0]);
  } catch (error) {
    console.error('Error fetching Hospital doctors:', error);
    res.status(500).send('Error fetching Hospital doctors');
  }
});
 
app.get('/doctors', (req, res) => {
  Pool.query('SELECT * FROM bookings', (error, results) => {
    if (error) {
      console.error('Error fetching doctors', error);
      res.status(500).send('Internal Server Error');
    } else {
      res.json(results);
    }
  });
});

app.get('/clinic-types', (req, res) => {
  const query = 'SELECT DISTINCT Types FROM clinics'; 
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    const types = results.map(result => result.Types); 
    res.json(types);
  });
});

app.get('/clinic-types1', (req, res) => {
  const query = 'SELECT DISTINCT Types FROM Hospital_Details'; 
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    const types = results.map(result => result.Types); 
    res.json(types);
  });
});

app.get('/specialization-types', (req, res) => {
  const query = 'SELECT DISTINCT  Specialities FROM clinics'; 
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    res.json(results);
  });
});
app.get('/specialization-types1', (req, res) => {
  const query = 'SELECT DISTINCT  Specialities FROM Hospital_Details'; 
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    res.json(results);
  });
});

app.get('/locationss', (req, res) => {
  const query = 'SELECT * FROM clinics'; 
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    res.json(results);
  });
});

app.get('/locationss1', (req, res) => {
  const query = 'SELECT * FROM Hospital_Details'; 
  Pool.query(query, (err, results) => {
    if (err) {
      // throw err;
    }
    res.json(results);
  });
});

app.get('/doctor-details/:doctorId', (req, res) => {
  const doctorId = req.params.doctorId;
  Pool.query(
    `SELECT * FROM admin_doctors WHERE doctor_id = ?`,
    [doctorId],
    (err, doctorResult) => {
      if (err) {
        console.error('Error fetching doctor details:', err);
        res.status(500).send('Error fetching doctor details');
      } else {
        if (doctorResult.length > 0) {
          const doctorDetails = doctorResult[0];
 
          res.status(200).send(doctorDetails);
        } else {
          res.status(404).send('Doctor details not found');
        }
      }
    }
  );
});
 
app.get('/api/available-slots/:doctorId/:date', async (req, res) => {
  try {
    const { doctorId, date } = req.params;
    const bookedSlotsQuery = await yourDatabase.query(
      'SELECT slot_time FROM bookings WHERE doctor_id = ? AND booking_date = ?',
      [doctorId, date]
    );
 
    const bookedSlots = bookedSlotsQuery.map((booking) => booking.booked_slot);
 
    const allSlotsQuery = await yourDatabase.query(
      'SELECT slot_time FROM trybook WHERE doctor_id = ?',
      [doctorId]
    );
 
    const allSlots = allSlotsQuery.map((slot) => slot.time_slot);
 
    const availableSlots = allSlots.filter((slot) => !bookedSlots.includes(slot));
 
    res.json({ availableSlots });
  } catch (error) {
    console.error('Error fetching available slots:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});
 
 
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
 

 

 

 
app.get("/api/get-clinic-image/:clinic_id", (req, res) => {
  const { clinic_id } = req.params;
  const sqlSelectImages = "SELECT filename FROM clinics WHERE clinic_id = ?";
 
  Pool.query(sqlSelectImages, [clinic_id], (err, result) => {
    if (err) {
      console.error("Error fetching images from database:", err);
      res.status(500).json({ status: 500, message: "Internal Server Error" });
    } else {
      console.log("Filenames from database:", result);
 
      const filenames = result.map(item => item.filename);
 
      if (filenames.length > 0) {
        const imagePath = path.join(__dirname, "uploads", filenames[0]);
        res.sendFile(imagePath);
      } else {
        res.status(404).json({ status: 404, message: "Image not found" });
      }
    }
  });
});

app.get("/api/get-clinic-image1/:hospi_id", (req, res) => {
  const { hospi_id } = req.params;
  const sqlSelectImages = "SELECT filename FROM Hospital_Details WHERE hospi_id = ?";
 
  Pool.query(sqlSelectImages, [hospi_id], (err, result) => {
    if (err) {
      console.error("Error fetching images from database:", err);
      res.status(500).json({ status: 500, message: "Internal Server Error" });
    } else {
      console.log("Filenames from database:", result);
 
      const filenames = result.map(item => item.filename);
 
      if (filenames.length > 0) {
        const imagePath = path.join(__dirname, "uploads", filenames[0]);
        res.sendFile(imagePath);
      } else {
        res.status(404).json({ status: 404, message: "Image not found" });
      }
    }
  });
});
 
app.get("/api/get-doctor-image/:doctor_id", (req, res) => {
  const { doctor_id } = req.params;
  const sqlSelectImage = "SELECT filename FROM doctors WHERE doctor_id = ?";
 
  Pool.query(sqlSelectImage, [doctor_id], (err, result) => {
    if (err) {
      console.error("Error fetching image from database:", err);
      res.status(500).json({ status: 500, message: "Internal Server Error" });
    } else {
      const filename = result[0] ? result[0].filename : null;
 
      if (filename) {
        const imagePath = path.join(__dirname, "uploads", filename);
        res.sendFile(imagePath);
      } else {
        res.status(404).json({ status: 404, message: "Image not found" });
      }
    }
  });
});

app.get('/bookings', (req, res) => {  
  const { doctor_id, date } = req.query;

  Pool.query(
    'SELECT slot_time FROM trybook WHERE doctor_id = ? AND booking_date = ?',
    [doctor_id, date],
    (error, results) => {
      if (error) {
        console.error('Error fetching bookings', error);
        res.status(500).send('Internal Server Error');
        return;
      }

      const bookedSlots = results.map(row => row.slot_time);

      res.json(bookedSlots);
    }
  );
});

app.get('/api/get-video/:clinic_id', (req, res) => {
  const { clinic_id } = req.params;
  const sqlSelectVideo = 'SELECT video_filename FROM clinics WHERE clinic_id = ?';
 
  Pool.query(sqlSelectVideo, [clinic_id], (err, result) => {
    if (err) {
      console.error('Error fetching video from database:', err);
      res.status(500).json({ status: 500, message: 'Internal Server Error' });
    } else {
      console.log('Video filename from database:', result);
 
      if (result.length > 0 && result[0].video_filename) {
        const videoFilename = result[0].video_filename;
        const videoPath = path.join(__dirname, 'uploads', videoFilename);
 
        res.sendFile(videoPath);
      } else {
        res.status(404).json({ status: 404, message: 'Video not found' });
      }
    }
  });
});
 
app.get('/api/get-video1/:hospi_id', (req, res) => {
  const { hospi_id } = req.params;
  const sqlSelectVideo = 'SELECT video_filename FROM Hospital_Details WHERE hospi_id = ?';
 
  Pool.query(sqlSelectVideo, [hospi_id], (err, result) => {
    if (err) {
      console.error('Error fetching video from database:', err);
      res.status(500).json({ status: 500, message: 'Internal Server Error' });
    } else {
      console.log('Video filename from database:', result);
 
      if (result.length > 0 && result[0].video_filename) {
        const videoFilename = result[0].video_filename;
        const videoPath = path.join(__dirname, 'uploads', videoFilename);
 
        res.sendFile(videoPath);
      } else {
        res.status(404).json({ status: 404, message: 'Video not found' });
      }
    }
  });
});

// app.post('/api/appointment_booking', (req, res) => {
//   const formData = req.body;

//   const sqlInsertBooking = 'INSERT INTO appointment_booking (name, contact, email, address, booking_date, slot_time, clinic_name, locality, doctor_name, consultation_fee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
//   const sqlInsertTryBook = 'INSERT INTO trybook (doctor_id, name, booking_date, slot_time) VALUES (?, ?, ?, ?)';

//   Pool.getConnection((err, connection) => {
//     if (err) {
//       console.error('Error getting database connection:', err);
//       res.status(500).json({ success: false, message: 'Internal Server Error' });
//       return;
//     }

//     connection.beginTransaction((err) => {
//       if (err) {
//         console.error('Error beginning transaction:', err);
//         res.status(500).json({ success: false, message: 'Internal Server Error' });
//         connection.release(); 
//         return;
//       }

//       connection.query(sqlInsertBooking, [formData.name, formData.contact, formData.email, formData.address, formData.booking_date, formData.slot_time, formData.clinic_name, formData.locality, formData.doctor_name, formData.consultation_fee], (err, result) => {
//         if (err) {
//           console.error('Error storing appointment booking details:', err);
//           connection.rollback(() => {
//             connection.release(); 
//             res.status(500).json({ success: false, message: 'Internal Server Error' });
//           });
//           return;
//         }

//         const { insertId: appointmentId } = result;

//         connection.query(sqlInsertTryBook, [formData.doctor_id, formData.name, formData.booking_date, formData.slot_time], (err) => {
//           if (err) {
//             console.error('Error storing trybook details:', err);
//             connection.rollback(() => {
//               connection.release(); 
//               res.status(500).json({ success: false, message: 'Internal Server Error' });
//             });
//             return;
//           }

//           connection.commit((err) => {
//             if (err) {
//               console.error('Error committing transaction:', err);
//               connection.rollback(() => {
//                 connection.release(); 
//                 res.status(500).json({ success: false, message: 'Internal Server Error' });
//               });
//               return;
//             }

//             connection.release();

//             res.status(200).json({ success: true, message: 'Appointment booked successfully!' });
//           });
//         });
//       });
//     });
//   });
// });

// app.post('/api/appointment_bookinghospital', (req, res) => {
//   const formData = req.body;

//   const sqlInsertBooking = 'INSERT INTO Hospital_Appointment (name, contact, email, address, booking_date, slot_time, HospitalFullName, locality, doctor_name, consultation_fee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
//   const sqlInsertTryBook = 'INSERT INTO trybook (doctor_id, name, booking_date, slot_time) VALUES (?, ?, ?, ?)';

//   Pool.getConnection((err, connection) => {
//     if (err) {
//       console.error('Error getting database connection:', err);
//       res.status(500).json({ success: false, message: 'Internal Server Error' });
//       return;
//     }

//     connection.beginTransaction((err) => {
//       if (err) {
//         console.error('Error beginning transaction:', err);
//         res.status(500).json({ success: false, message: 'Internal Server Error' });
//         connection.release(); 
//         return;
//       }

//       connection.query(sqlInsertBooking, [formData.name, formData.contact, formData.email, formData.address, formData.booking_date, formData.slot_time, formData.HospitalFullName, formData.locality, formData.doctor_name, formData.consultation_fee], (err, result) => {
//         if (err) {
//           console.error('Error storing appointment booking details:', err);
//           connection.rollback(() => {
//             connection.release(); 
//             res.status(500).json({ success: false, message: 'Internal Server Error' });
//           });
//           return;
//         }

//         const { insertId: appointmentId } = result;

//         connection.query(sqlInsertTryBook, [formData.doctor_id, formData.name, formData.booking_date, formData.slot_time], (err) => {
//           if (err) {
//             console.error('Error storing trybook details:', err);
//             connection.rollback(() => {
//               connection.release(); 
//               res.status(500).json({ success: false, message: 'Internal Server Error' });
//             });
//             return;
//           }

//           connection.commit((err) => {
//             if (err) {
//               console.error('Error committing transaction:', err);
//               connection.rollback(() => {
//                 connection.release(); 
//                 res.status(500).json({ success: false, message: 'Internal Server Error' });
//               });
//               return;
//             }

//             connection.release();

//             res.status(200).json({ success: true, message: 'Appointment booked successfully!' });
//           });
//         });
//       });
//     });
//   });
// });

app.get('/api/appointment_booking', (req, res) => {
  const sqlSelect = 'SELECT * FROM appointment_booking ORDER BY patient_id DESC LIMIT 1';
 
  Pool.query(sqlSelect, (error, results) => {
    if (error) {
      console.error('Error retrieving data:', error);
      return res.status(500).json({ success: false, error: 'Internal server error' });
    }
 
    res.json({ success: true, data: results });
  });
});
 
app.get('/api/appointment_booking1', (req, res) => {
  const sqlSelect = 'SELECT * FROM Hospital_Appointment ORDER BY patient_id DESC LIMIT 1';
 
  Pool.query(sqlSelect, (error, results) => {
    if (error) {
      console.error('Error retrieving data:', error);
      return res.status(500).json({ success: false, error: 'Internal server error' });
    }
 
    res.json({ success: true, data: results });
  });
});

app.put('/api/appointment_booking/:patient_id', (req, res) => {
  const patient_id = req.params.patient_id;
  const { name, contact, email, address, booking_date, slot_time } = req.body;
 
  if (!name || !contact || !email || !address || !booking_date || !slot_time) {
    return res.status(400).json({ success: false, error: 'Incomplete data. Please provide name, contact, email, address, booking_date, and slot_time.' });
  }
 
  Pool.query(
    'UPDATE appointment_booking SET name=?, contact=?, email=?, address=?, booking_date=?, slot_time=? WHERE patient_id=?',
    [name, contact, email, address, booking_date, slot_time, patient_id],
    async (error, results) => {
      if (error) {
        console.error('Error updating data:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
      }
 
      const updatedData = await Pool.promise().query('SELECT patient_id, name, contact, email, address, booking_date, slot_time FROM appointment_booking WHERE patient_id = ?', [patient_id]);
 
      res.json({ success: true, message: 'Appointment updated successfully', data: updatedData[0][0] });
    }
  );
});


app.put('/api/appointment_booking1/:patient_id', (req, res) => {
  const patient_id = req.params.patient_id;
  const { name, contact, email, address, booking_date, slot_time } = req.body;
 
  if (!name || !contact || !email || !address || !booking_date || !slot_time) {
    return res.status(400).json({ success: false, error: 'Incomplete data. Please provide name, contact, email, address, booking_date, and slot_time.' });
  }
 
  Pool.query(
    'UPDATE Hospital_Appointment SET name=?, contact=?, email=?, address=?, booking_date=?, slot_time=? WHERE patient_id=?',
    [name, contact, email, address, booking_date, slot_time, patient_id],
    async (error, results) => {
      if (error) {
        console.error('Error updating data:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
      }
 
      const updatedData = await Pool.promise().query('SELECT patient_id, name, contact, email, address, booking_date, slot_time FROM appointment_booking WHERE patient_id = ?', [patient_id]);
 
      res.json({ success: true, message: 'Appointment updated successfully', data: updatedData[0][0] });
    }
  );
});


// --------------------------------------------
  
app.get('/api/appointment_bookinguser', (req, res) => {
  const name = req.query.name; // Assuming the name is passed as a query parameter
 
  // SQL query using LIKE operator to search for names containing 'rajitha'
  const sqlSelect = `SELECT * FROM appointment_booking WHERE name LIKE '%${'rajitha'}%'`;
 
  Pool.query(sqlSelect, (error, results) => {
    if (error) {
      console.error('Error retrieving data:', error);
      return res.status(500).json({ success: false, error: 'Internal server error' });
    }
 
    res.json({ success: true, data: results });
  });
});
 
app.put('/api/appointment_booking/:patient_id', (req, res) => {
  const patient_id = req.params.patient_id;
  const { name, contact, email, address, booking_date, slot_time } = req.body;
 
  if (!name || !contact || !email || !address || !booking_date || !slot_time) {
    return res.status(400).json({ success: false, error: 'Incomplete data. Please provide name, contact, email, address, booking_date, and booking_time.' });
  }
 
  Pool.query(
    'UPDATE appointment_booking SET name=?, contact=?, email=?, address=?, booking_date=?, slot_time=? WHERE patient_id=?',
    [name, contact, email, address, booking_date, slot_time, patient_id],
    async (error, results) => {
      if (error) {
        console.error('Error updating data:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
      }
 
      const updatedData = await Pool.promise().query('SELECT patient_id, name, contact, email, address, booking_date, slot_time FROM appointment_booking WHERE patient_id = ?', [patient_id]);
 
      res.json({ success: true, message: 'Appointment updated successfully', data: updatedData[0][0] });
    }
  );
});
app.put('/api/user_details/:user_id', (req, res) => {
  const user_id = req.params.user_id;
  const { username, email, contact_number, password } = req.body;
 
  if (!username || !email || !contact_number || !password) {
    return res.status(400).json({ success: false, error: 'Incomplete data. Please provide username, email, contact_number, and password.' });
  }
 
  Pool.query(
    'UPDATE user_details SET username=?, email=?, contact_number=?, password=? WHERE user_id=?',
    [username, email, contact_number, password, user_id],
    async (error, results) => {
      if (error) {
        console.error('Error updating data:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
      }
 
      const updatedData = await Pool.promise().query('SELECT user_id, username, email, contact_number FROM user_details WHERE user_id = ?', [user_id]);
 
      res.json({ success: true, message: 'User details updated successfully', data: updatedData[0][0] });
    }
  );
});
app.get('/user/last', (req, res) => {
  const query = 'SELECT * FROM user_details ORDER BY user_id DESC LIMIT 1'; // Get the last user based on user ID
  Pool.query(query, (err, results) => {
    if (err) {
      throw err;
    }
    res.json(results[0]); 
  });
});
 
// Nodemailer configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'sisindrareddy143@gmail.com',
    pass: 'zmrgjkvomgybyaal'
  },
  debug: true // Enable debugging
});

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Send OTP Email
const sendOTPEmail = (email, otp) => {
  const mailOptions = {
    from: 'sisindrareddy1996@gmail.com',
    to: email,
    subject: 'OTP Verification',
    text: `Your OTP for verification is: ${otp}`
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
};

// API endpoint for sending OTP
app.post('/send-otp', (req, res) => {
  const email = req.body.email;
  const otp = generateOTP();

  // Save OTP in the database
  const insertQuery = `INSERT INTO otps (email, otp) VALUES (?, ?)`;
  Pool.query(insertQuery, [email, otp], (err, results) => {
    if (err) throw err;

    // Send OTP email
    sendOTPEmail(email, otp);

    res.send('OTP sent successfully');
  });
});

// API endpoint for verifying OTP
app.post('/verify-otp', (req, res) => {
  const email = req.body.email;
  const otp = req.body.otp;

  // Retrieve the OTP from the database
  const selectQuery = `SELECT otp FROM otps WHERE email = ? ORDER BY id DESC LIMIT 1`;
  Pool.query(selectQuery, [email], (err, results) => {
    if (err) throw err;

    if (results.length === 0) {
      res.send({ message: 'No OTP found for this email' });
    } else {
      const storedOTP = results[0].otp;
      if (otp === storedOTP) {
        res.send({ message: 'OTP verified successfully' });
        // You can proceed to the next page or perform any action here
      } else {
        res.send({ message: 'Invalid OTP' });
      }
    }
  });
});


app.post('/users', async (req, res) => {
  const { username, password, Primary_name, Secondary_name, email, role, contact_number, managing_admin } = req.body;

  const userQuery = 'INSERT INTO AddAdmins (username, password, Primary_name, Secondary_name, email, role, contact_number, managing_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  Pool.query(userQuery, [username, password, Primary_name, Secondary_name, email, role, contact_number, managing_admin], async (userErr, userResults) => {
    if (userErr) {
      console.error('Error during signup:', userErr);
      res.status(500).send('Error during signup');
      return;
    }

    // Retrieve the auto-generated user_id
    const userId = userResults.insertId;

    // Construct the detail query based on the role
    let detailQuery;
    let detailValues;
    if (role === 'admin') {
      detailQuery = 'INSERT INTO admin_details (user_id, username, email, contact_number, password) VALUES (?, ?, ?, ?, ?)';
      detailValues = [userId, username, email, contact_number, password];
    } else if (role === 'Super Admin') {
      detailQuery = 'INSERT INTO superadmin_details (user_id, username, email, contact_number, password) VALUES (?, ?, ?,?, ?)';
      detailValues =[userId, username, email, contact_number, password];
    } else {
      detailQuery = 'INSERT INTO user_details (user_id,username ,email, contact_number , password) VALUES (?, ?, ?, ?, ?)';
      detailValues = [userId, username, email, contact_number, password];
    }

    // Perform the detail insertion
    Pool.query(detailQuery, detailValues, async (detailErr, detailResults) => {
      if (detailErr) {
        console.error(`Error during ${role} signup:`, detailErr);
        res.status(500).send(`Error during ${role} signup`);
        return;
      }

      // Send welcome email
      const mailOptions = {
        from: 'sisindrareddy143@gmail.com',
        to: email,
        subject: 'Welcome to our platform!',
        text: `Dear ${username},\n\nThank you for signing up with us!\n\nYour account details:\nName: ${username}\nEmail: ${email}\nPhone Number: ${contact_number}\nRole: ${role}\n\nBest regards,\nThe Hospi Team`
      };

      try {
        await transporter.sendMail(mailOptions);
        res.status(201).send('Signup successful! Welcome email sent.');
      } catch (emailErr) {
        console.error('Error sending welcome email:', emailErr);
        res.status(500).send('Signup successful, but failed to send welcome email.');
      }
    });
  });
});




// app.post('/api/login', (req, res) => {
//   const { username, password, loginTime, sessionDuration } = req.body;

//   const query = 'SELECT * FROM AddAdmins WHERE username = ? AND password = ?';
//   Pool.query(query, [username, password], (err, results) => {
//     if (err) {
//       console.error('Error during login:', err);
//       res.status(500).send('Error during login');
//       return;
//     }

//     if (results.length > 0) {
//       const userId = results[0].adminID; // Assuming the user ID is stored in the 'adminID' column
//       // const loginTimestamp = new Date(loginTime).getTime();
//       // const currentTimestamp = new Date().getTime();
//       // // const sessionDuration = (currentTimestamp - loginTimestamp) / (1000 * 60); // Convert milliseconds to minutes
//       // const sessionDuration = Math.floor((currentTimestamp - loginTimestamp) / (1000 * 60)); // Convert milliseconds to minutes and round down
//       const sessionDurationMinute = parseFloat(sessionDuration);
//       const insertLoginTimeQuery = 'INSERT INTO login_usage (userId, username, login_time, session_duration) VALUES (?, ?, ?, ?)';
//       console.log("Request Payload:", req.body); // Log request payload to check sessionDuration value
//       Pool.query(insertLoginTimeQuery, [userId, username, loginTime, sessionDurationMinute], (loginErr, loginResults) => {
//         if (loginErr) {
//           console.error('Error storing login time:', loginErr);
//           res.status(500).send('Error storing login time'); // Send error response
//           // Handle error
//         } else {
//           // Login time stored successfully
//           // Proceed with your login logic
//           console.log("Login time stored successfully");
//           res.json(results[0]);
//           // res.status(200).json({ message: 'Login successful' });
//         }
//       });
//       // res.json(results[0]);
//     } else {
//       res.status(401).send('Invalid credentials');
//     }
//   });
// });

// Modify the backend API to include managing_admin data in the response
app.post('/api/login', async (req, res) => {
  const { username, password, loginTime, sessionDuration } = req.body;
  // const hashedPassword = await bcrypt.hash(password, 10);

  const query = 'SELECT * FROM AddAdmins WHERE username = ? AND password = ?';
  Pool.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error during login:', err);
      res.status(500).send('Error during login');
      return;
    }
    if (results.length > 0) {
      const userId = results[0].adminID;
      const sessionDurationMinute = parseFloat(sessionDuration);
      const insertLoginTimeQuery = 'INSERT INTO login_usage (userId, username, login_time, session_duration) VALUES (?, ?, ?, ?)';
      Pool.query(insertLoginTimeQuery, [userId, username, loginTime, sessionDurationMinute], (loginErr, loginResults) => {
        if (loginErr) {
          console.error('Error storing login time:', loginErr);
          res.status(500).send('Error storing login time');
        } else {
          // Modify the response to include managing_admin data
          const responseData = { ...results[0], managing_admin: results[0].managing_admin };
          res.json(responseData);
        }
      });
    } else {
      res.status(401).send('Invalid credentials');
    }
  });
});


app.get('/api/users', (req, res) => {
  const query = 'SELECT * FROM AddAdmins';

  Pool.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching users:', err);
      res.status(500).send('Error fetching users');
      return;
    }

    res.json(results);
  });
});
app.get('/api/userdetails/:username', (req, res) => {
  const userId = req.params.username;

  const query = 'SELECT * FROM AddAdmins WHERE username = ?';

  Pool.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching user details:', err);
      res.status(500).send('Error fetching user details');
      return;
    }

    // Ensure that the query returns exactly one row
    if (results.length === 1) {
      res.json({ managingAdmin: results[0].managing_admin });
    } else {
      res.status(404).send('User details not found');
    }
  });
});


app.get('/api/adminuserdetails/:username', (req, res) => {
  const username = req.params.username;

  const query = 'SELECT * FROM AddAdmins WHERE username = ?';

  Pool.query(query, [username], (err, results) => {
    if (err) {
      console.error('Error executing SQL query:', err);
      console.log('Query results:', results);
      res.status(500).json({ error: 'Error fetching user details' });
      return;
    }

    console.log('Query results:', results);

    if (results.length === 1) {
      res.json(results[0]);
      //res.json({ managingAdmin: results[0].managing_admin });
    } else {
      res.status(404).json({ error: 'User details not found' });
    }
  });
});


app.get('/api/superadminuserdetails/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = 'SELECT * FROM AddAdmins WHERE adminID = ?';

  Pool.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching super admin user details:', err);
      res.status(500).send('Error fetching super admin user details');
      return;
    }

    // Ensure that the query returns exactly one row
    if (results.length === 1) {
      res.json(results[0]); // Send the first (and only) row of the result
    } else {
      res.status(404).send('Super admin user details not found');
    }
  });
});

// Add a new endpoint for forgot password
app.post('/forgot-password', (req, res) => {
  const { email } = req.body;

  // Generate OTP
  const otp = generateOTP();

  // Save OTP in the database
  const insertQuery = `INSERT INTO otps (email, otp) VALUES (?, ?)`;
  Pool.query(insertQuery, [email, otp], (insertError, insertResults) => {
    if (insertError) {
      console.error('Error during forgot password:', insertError);
      res.status(500).send('Error during forgot password');
      return;
    }

    // Send OTP email
    sendOTPEmail(email, otp);

    res.send('OTP sent successfully');
  });
});

// Add a new endpoint for resetting password
// app.post('/reset-password', (req, res) => {
//   const { email, otp, newPassword } = req.body;

//   // Verify OTP
//   const selectQuery = `SELECT otp FROM otps WHERE email = ? ORDER BY id DESC LIMIT 1`;
//   Pool.query(selectQuery, [email], (selectError, selectResults) => {
//     if (selectError) {
//       console.error('Error during password reset:', selectError);
//       res.status(500).send('Error during password reset');
//       return;
//     }

//     if (selectResults.length === 0 || selectResults[0].otp !== otp) {
//       res.status(401).send('Invalid OTP');
//       return;
//     }

//     const updateQuery = `UPDATE AddAdmins SET password = ? WHERE email = ?`;
//     Pool.query(updateQuery, [newPassword, email], (updateError, updateResults) => {
//       if (updateError) {
//         console.error('Error during password reset:', updateError);
//         res.status(500).send('Error during password reset');
//         return;
//       }

//       // Delete the used OTP
//       const deleteQuery = `DELETE FROM otps WHERE email = ? AND otp = ?`;
//       Pool.query(deleteQuery, [email, otp], (deleteError, deleteResults) => {
//         if (deleteError) {
//           console.error('Error during password reset:', deleteError);
//           res.status(500).send('Error during password reset');
//           return;
//         }

//         res.send('Password reset successfully');
//       });
//     });
//   });
// });

app.post('/reset-password', (req, res) => {
  const { email, otp, newPassword } = req.body;

  // Verify OTP
  const selectQuery = `SELECT otp FROM otps WHERE email = ? ORDER BY id DESC LIMIT 1`;
  Pool.query(selectQuery, [email], (selectError, selectResults) => {
    if (selectError) {
      console.error('Error during password reset:', selectError);
      res.status(500).send('Error during password reset');
      return;
    }

    if (selectResults.length === 0 || selectResults[0].otp !== otp) {
      res.status(401).send('Invalid OTP');
      return;
    }

    const updateQuery = `UPDATE AddAdmins SET password = ? WHERE email = ?`;
    Pool.query(updateQuery, [newPassword, email], (updateError, updateResults) => {
      if (updateError) {
        console.error('Error during password reset:', updateError);
        res.status(500).send('Error during password reset');
        return;
      }

      // Delete the used OTP
      const deleteQuery = `DELETE FROM otps WHERE email = ? AND otp = ?`;
      Pool.query(deleteQuery, [email, otp], (deleteError, deleteResults) => {
        if (deleteError) {
          console.error('Error during password reset:', deleteError);
          res.status(500).send('Error during password reset');
          return;
        }

        res.send('Password reset successfully');
      });
    });
  });
});

// Add this route to receive session duration on logout
app.post('/api/logout',verifyToken, (req, res) => {
  const { sessionDuration } = req.body;
  const userId = req.user.adminID;

  // Update user's session duration in the database
  const updateQuery = `UPDATE AddAdmins SET session_duration = ? WHERE adminID = ?`;
  Pool.query(updateQuery, [sessionDuration, userId], (err, results) => {
    if (err) {
      console.error('Error updating session duration:', err);
      res.status(500).send('Error updating session duration');
      return;
    }

    res.send('Session duration updated successfully');
    res.clearCookie('token');
    res.json({ success: true, message: 'Logged out successfully' });
  });
});


app.post('/login', async (req, res) => {
  try {
      const { username, loginTime } = req.body;
      const user = { username, adminID: 'exampleAdminID' };
      const token = jwt.sign(user, jwtSecretKey, { expiresIn: '1h' });
      // Insert login time into the database
      await Pool.query('INSERT INTO login_usage (username, login_time) VALUES (?, ?)', [username, loginTime]);

      // Respond with success message
      res.status(200).json({ message: 'Login successful', token });
  } catch (error) {
      console.error('Error during login:', error);
      res.status(500).json({ error: 'Internal server error' });
  }
});

function verifyToken(req, res, next) {
  const token = req.headers['authorization'];

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  jwt.verify(token.split(' ')[1], jwtSecretKey, (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    req.user = decoded;
    next();
  });
}

app.get('/products', verifyToken, (req, res) => {
  const query = 'SELECT * FROM Ecom_Products';
  Pool.query(query, (error, results) => {
    if (error) {
      res.status(500).json({ error: 'Error fetching products' });
    } else {
      res.status(200).json(results);
    }
  });
});

app.post('/cart/update', (req, res) => {
  const { productId, quantity, username} = req.body;

  const updateQuery = 'UPDATE ShoppingCart SET quantity = ? WHERE username = ? AND productId = ?';
  Pool.query(updateQuery, [quantity, username, productId], (error, result) => {
      if (error) {
          console.error('Error updating item quantity in cart:', error);
          res.status(500).json({ success: false, message: 'Error updating item quantity in cart' });
      } else {
          // Update total price after updating quantity
          updateTotalPrice(username);
          res.status(200).json({ success: true, message: 'Item quantity updated successfully' });
      }
  });
});

 
app.get("/api/getdoctor", (req, res) => {
  const sqlGet = "SELECT * FROM admin_doctors  where doctor_id = 2"
 Pool.query(sqlGet, (error, result) => {
    res.send(result);
  });
});
 
 
app.get("/api/get10", (req, res) => {
  const doctorName = req.query.doctorName; // Assuming you're passing doctorName as a query parameter
  const sqlGet = `SELECT COUNT(*) FROM appointment_booking WHERE doctor_name LIKE ?`;
 Pool.query(sqlGet, [`%${'Dr. David Smith'}%`], (error, result) => {
    if (error) {
      // Handle error appropriately
      console.error(error);
      res.status(500).send("Internal Server Error");
    } else {
      let totalPatients = 0;
      if (result.length > 0) {
        // Iterate through the result to calculate the total count
        result.forEach(row => {
          totalPatients += row.totalPatients;
        });
      }
      res.send({ totalPatients }); // Send the totalPatients count as JSON
    }
  });
});
 
 
app.get("/api/get11", (req, res) => {
  const doctorName = req.query.doctorName; // Assuming you're passing doctorName as a query parameter
  const sqlGet = `SELECT * FROM appointment_booking WHERE doctor_name LIKE ?`;
 Pool.query(sqlGet, [`%${'Dr. David Smith'}%`], (error, result) => {
    if (error) {
      // Handle error appropriately
      console.error(error);
      res.status(500).send("Internal Server Error");
    } else {
      res.send(result);
    }
  });
});
 
 
app.get("/api/getgender", (req, res) => {
  const doctorName = req.query.doctorName;
  const sqlGet = `
    SELECT
      SUM(CASE WHEN gender = 'male' THEN 1 ELSE 0 END) AS male_count,
      SUM(CASE WHEN gender = 'female' THEN 1 ELSE 0 END) AS female_count
    FROM appointment_booking
    WHERE doctor_name LIKE ?`;
 Pool.query(sqlGet, [`%${doctorName}%`], (error, result) => {
    if (error) {
      console.error("Error querying database: " + error);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      const maleCount = result[0].male_count;
      const femaleCount = result[0].female_count;
      const totalAppointments = maleCount + femaleCount;
     
      const maleRatio = (maleCount / totalAppointments) * 100;
      const femaleRatio = (femaleCount / totalAppointments) * 100;
 
      const pieChartData = [
        { gender: 'Male', count: maleCount, ratio: maleRatio },
        { gender: 'Female', count: femaleCount, ratio: femaleRatio }
      ];
 
      res.json(pieChartData);
    }
  });
});
 
 
 
app.get("/api/getGenderCount", (req, res) => {
  const doctorName = req.query.doctorName; // Extract doctorName from query parameters
  let sqlGet = `
    SELECT
      gender,
      COUNT(*) AS count
    FROM appointment_booking where doctor_name LIKE ?`;
 
 
  sqlGet += ` GROUP BY gender`;
 
 Pool.query(sqlGet, [`%${'Dr. David Smith'}%`],(error, result) => {
    if (error) {
      console.error("Error querying database: " + error);
      res.status(500).send("Internal Server Error");
    } else {
      // Calculate total count of patients
      const totalCount = result.reduce((acc, curr) => acc + curr.count, 0);
      // Calculate gender ratio count
      const genderRatioData = result.map(item => ({
        gender: item.gender,
        count: item.count,
        ratio: (item.count / totalCount) * 100
      }));
      res.json(genderRatioData);
    }
  });
});
 
 
 
app.get("/api/get5", (req, res) => {
  const doctorName = req.query.doctorName;
  const sqlGet = `SELECT * FROM Hospital_Appointment WHERE doctor_name LIKE ?`;
 Pool.query(sqlGet, [`%${'Dr. David Smith'}%`], (error, result) => {
    if (error) {
     
      console.error(error);
      res.status(500).send("Internal Server Error");
    } else {
      res.send(result);
    }
  });
});


app.get("/api/get3", (req, res) => {
  const sqlGet = "SELECT DISTINCT days,from_time,to_time FROM doctor_op_timings WHERE doctor_id = 2";
 Pool.query(sqlGet, (error, result) => {
    if (error) {
      console.error('Error fetching timings:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(result);
    }
  });
});
app.get("/api/get4doctor", (req, res) => {
  const sqlGet = "SELECT * FROM   clinics  WHERE clinic_id = 2";
 
 Pool.query(sqlGet, (error, result) => {
    if (error) {
      console.error("Error executing join query:", error);
      res.status(500).json({ error: "Internal Server Error" });
      return;
    }
    res.json(result);
  });
});
 
app.get("/api/get-total-patients", (req, res) => {
  const sqlGet = `SELECT COUNT(*) AS totalPatients FROM appointment_booking where doctor_name LIKE ?`;
 Pool.query(sqlGet,[`%${'Dr. David Smith'}%`], (error, result) => {
    if (error) {
      console.error(error);
      res.status(500).send("Internal Server Error");
    } else {
      const totalPatients = result[0].totalPatients;
      res.send({ totalPatients });
    }
  });
});
 
app.get("/api/get-today-appointments-count", (req, res) => {
  const today = new Date().toISOString().slice(0, 10); // Get today's date in YYYY-MM-DD format
  const sqlGetTodayAppointmentsCount = `SELECT COUNT(*) AS todayAppointmentsCount FROM appointment_booking WHERE DATE(booking_date) = '${today}' AND doctor_name LIKE ? `;
 Pool.query(sqlGetTodayAppointmentsCount, [`%${'Dr. David Smith'}%`], (error, result) => {
    if (error) {
      console.error("Error fetching today's appointments count:", error);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      const todayAppointmentsCount = result[0].todayAppointmentsCount;
      res.json({ todayAppointmentsCount });
    }
  });
});
 
 
app.get("/api/get-confirmed-patients-count", (req, res) => {
  const sqlGetConfirmedPatientsCount = "SELECT COUNT(*) AS confirmedPatientsCount FROM appointment_booking WHERE status = 'Confirmed' AND doctor_name LIKE ?";
 Pool.query(sqlGetConfirmedPatientsCount, [`%${'Dr. David Smith'}%`], (error, result) => {
    if (error) {
      console.error("Error fetching confirmed patients count:", error);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      const confirmedPatientsCount = result[0].confirmedPatientsCount;
      res.json({ totalConfirmedPatients: confirmedPatientsCount });
      // Corrected key name
    }
  });
});
 
 
 
app.get('/api/get-booking-dates-by-month', (req, res) => {
  // SQL query to fetch booking dates grouped by month
  const sqlGetBookingDatesByMonth = `
    SELECT YEAR(booking_date) AS year, MONTH(booking_date) AS month, COUNT(*) AS count
    FROM appointment_booking
    WHERE doctor_name LIKE '%Dr. David Smith%'
    GROUP BY YEAR(booking_date), MONTH(booking_date)
  `;
 
  // Execute the SQL query
 Pool.query(sqlGetBookingDatesByMonth, (error, results) => {
    if (error) {
      console.error("Error fetching booking dates by month:", error);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      // Send the results as JSON response
      res.json({ bookingDatesByMonth: results });
    }
  });
});
 
app.get('/api/get-recent-appointments', (req, res) => {
  // SQL query to fetch recent appointments for Dr. David Smith
  const sqlGetRecentAppointments = `
    SELECT *
    FROM appointment_booking
    WHERE doctor_name LIKE '%Dr. David Smith%'
    ORDER BY booking_date DESC
    LIMIT 5
  `;
 
  // Execute the SQL query
 Pool.query(sqlGetRecentAppointments, (error, results) => {
    if (error) {
      console.error("Error fetching recent appointments:", error);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      // Send the results as JSON response
      res.json({ recentAppointments: results });
    }
  });
});
 
 
 
app.post("/api/post", (req, res) => {
  const { name, email, date, visittime, contact, doctor, age, injury } = req.body;
  const sqlInsert = "INSERT INTO appotmentlist (name, email, date, visittime,contact, doctor, age, injury) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
 Pool.query(sqlInsert, [name, email, date, visittime, contact, doctor, age, injury], (error, result) => {
    if (error) {
      console.log(error)
    }
  });
});
 
app.delete("/api/remove/:id", (req, res) => {
  const { id } = req.params;
  const sqlRemove = "DELETE FROM appotmentlist WHERE id= ?";
 Pool.query(sqlRemove, id, (error, result) => {
    if (error) {
      console.log(error)
    }
  });
});
app.get("/api/get-image/:doctor_id", (req, res) => {
  const { doctor_id } = req.params;
  const sqlSelectImage =
    "SELECT filename FROM admin_doctors WHERE doctor_id = 2";
 Pool.query(sqlSelectImage, [doctor_id], (err, result) => {
    if (err) {
      console.error("Error fetching image from database:", err);
      res.status(500).json({ status: 500, message: "Internal Server Error" });
    } else {
      const filename = result[0] ? result[0].filename : null;
 
      if (filename) {
        const imagePath = path.join(__dirname, "uploads", filename);
        res.sendFile(imagePath);
      } else {
        res.status(404).json({ status: 404, message: "Image not found" });
      }
    }
  });
});

app.post("/api/register1", async (req, res) => {
  try {
    const { Email } = req.query; // Extract email from query parameters
 
    // Create a transporter using SMTP transport
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: 'sisindrareddy143@gmail.com',
        pass: 'zmrgjkvomgybyaal'
      }
    });
 
    // Email options
    const mailOptions = {
     
      to: Email,// Recipient email address
      subject: 'Welcome Ambulance Services!',
      text: 'Your Ambulance Booked Successfully for selected date' // Customize the email content as needed
    };
 
    // Send the email
    await transporter.sendMail(mailOptions);
   
    console.log('Email sent successfully');
    res.status(200).json({ status: 200, message: 'Email sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ status: 500, error: 'Failed to send email' });
  }
}); 




// Route to fetch hospital details based on managing admin
app.get("/api/hospital-details/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM Hospital_Details WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


app.get("/api/hospital-details/doctors/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM admin_doctors WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

app.get("/api/hospital-details/nurse/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM nurse WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

app.get("/api/hospital-details/patient/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM patients WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

app.get("/api/hospital-details/pharmacist/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM pharmacist WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

app.get("/api/hospital-details/laboratorist/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM laboratorist WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


app.get("/api/hospital-details/receptionist/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM receptionist WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


// app.get("/api/hospital-details/user/:username", (req, res) => {
//   const { username } = req.params;
//   const sqlManagingAdmin = "SELECT username FROM AddAdmins WHERE username = ?";
  
//   Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
//       if (error) {
//           console.error("Error fetching user:", error);
//           res.status(500).json({ error: "Internal server error" });
//       } else {
//           if (managingAdminResult.length === 0) {
//               res.status(404).json({ error: "user not found" });
//           } else {
//               const managingAdmin = managingAdminResult[0].username;
//               const sqlHospitalDetails = "SELECT * FROM appointment_booking WHERE name = ?";
              
//               Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
//                   if (error) {
//                       console.error("Error fetching hospital details:", error);
//                       res.status(500).json({ error: "Internal server error" });
//                   } else {
//                       res.json(hospitalDetailsResult);
//                   }
//               });
//           }
//       }
//   });
// });


app.get("/api/hospital-details/user/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT username FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching user:", error);
          return res.status(500).json({ error: "Internal server error" });
      }
      
      if (managingAdminResult.length === 0) {
          return res.status(404).json({ error: "User not found" });
      }
      
      const managingAdmin = managingAdminResult[0].username;
      
      const sqlHospitalDetails = `
        SELECT 
          ha.*, 
          ab.* 
        FROM 
          Hospital_Appointment ha
        JOIN 
          appointment_booking ab 
        ON 
          ha.name = ab.name 
        WHERE 
          ha.name = ?`;

      Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
          if (error) {
              console.error("Error fetching hospital details:", error);
              return res.status(500).json({ error: "Internal server error" });
          }
          
          res.json(hospitalDetailsResult);
      });
  });
});


app.get('/api/addadmin/:username', (req, res) => {
  const { username } = req.params;
  const sql = 'SELECT * FROM AddAdmins WHERE username = ?';
  
  Pool.query(sql, [username], (err, result) => {
    if (err) {
      console.error('Error fetching data:', err);
      res.status(500).json({ error: 'Internal server error' });
    } else {
      if (result.length > 0) {
        res.json(result[0]);
      } else {
        res.status(404).json({ error: 'Admin not found' });
      }
    }
  });
});



// app.get("/api/hospital-details/doctoradmin/:username", (req, res) => {
//   const { username } = req.params;
//   const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
//   Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
//       if (error) {
//           console.error("Error fetching managing admin:", error);
//           res.status(500).json({ error: "Internal server error" });
//       } else {
//           if (managingAdminResult.length === 0) {
//               res.status(404).json({ error: "Managing admin not found" });
//           } else {
//               const managingAdmin = managingAdminResult[0].managing_admin;
//               const sqlHospitalDetails = "SELECT * FROM admin_doctors WHERE managing_admin = ?";
              
//               Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
//                   if (error) {
//                       console.error("Error fetching hospital details:", error);
//                       res.status(500).json({ error: "Internal server error" });
//                   } else {
//                       res.json(hospitalDetailsResult);
//                   }
//               });
//           }
//       }
//   });
// });


app.get("/api/hospital-details/totalpatients/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT count(*) as total FROM appointment_booking WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

// app.get("/api/hospital-details/doctorname/:username", (req, res) => {
//   const { username } = req.params;
//   const today = new Date().toISOString().split('T')[0]; // Get today's date in "YYYY-MM-DD" format
  
//   const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
//   Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
//     if (error) {
//       console.error("Error fetching managing admin:", error);
//       res.status(500).json({ error: "Internal server error" });
//     } else {
//       if (managingAdminResult.length === 0) {
//         res.status(404).json({ error: "Managing admin not found" });
//       } else {
//         const managingAdmin = managingAdminResult[0].managing_admin;
//         const sqlHospitalDetails = "SELECT COUNT(*) AS todayAppointmentsCount FROM appointment_booking WHERE doctor_name = ?";
        
//         Pool.query(sqlHospitalDetails, [managingAdmin, today], (error, appointmentCountResult) => {
//           if (error) {
//             console.error("Error fetching today's appointments count:", error);
//             res.status(500).json({ error: "Internal server error" });
//           } else {
//             const todayAppointmentsCount = appointmentCountResult[0].todayAppointmentsCount;
//             res.json({ todayAppointmentsCount });
//           }
//         });
//       }
//     }
//   });
// });


app.get("/api/hospital-details/doctorname/:username", (req, res) => {
  const { username } = req.params;
  const today = new Date().toISOString().split('T')[0]; // Get today's date in "YYYY-MM-DD" format
  
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
    if (error) {
      console.error("Error fetching managing admin:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (managingAdminResult.length === 0) {
        res.status(404).json({ error: "Managing admin not found" });
      } else {
        const managingAdmin = managingAdminResult[0].managing_admin;
        const sqlTodayAppointments = "SELECT count(*) as count FROM appointment_booking WHERE managing_admin = ? AND booking_date = ?";
        
        Pool.query(sqlTodayAppointments, [managingAdmin, today], (error, appointmentsResult) => {
          if (error) {
            console.error("Error fetching today's appointments:", error);
            res.status(500).json({ error: "Internal server error" });
          } else {
            res.json(appointmentsResult);
          }
        });
      }
    }
  });
});

app.get("/api/hospital-details/conformedstatus/:username", (req, res) => {
  const { username } = req.params;
  const today = new Date().toISOString().split('T')[0]; // Get today's date in "YYYY-MM-DD" format
  
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
    if (error) {
      console.error("Error fetching managing admin:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (managingAdminResult.length === 0) {
        res.status(404).json({ error: "Managing admin not found" });
      } else {
        const managingAdmin = managingAdminResult[0].managing_admin;
        const sqlTodayAppointments = "SELECT COUNT(*) AS confirmedPatientsCount FROM appointment_booking WHERE status = 'Confirmed' AND managing_admin = ?";
        
        Pool.query(sqlTodayAppointments, [managingAdmin, today], (error, appointmentsResult) => {
          if (error) {
            console.error("Error fetching today's appointments:", error);
            res.status(500).json({ error: "Internal server error" });
          } else {
            res.json(appointmentsResult);
          }
        });
      }
    }
  });
});


app.get("/api/hospital-details/recentapt/:username", (req, res) => {
  const { username } = req.params;
  const today = new Date().toISOString().split('T')[0]; // Get today's date in "YYYY-MM-DD" format
  
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
    if (error) {
      console.error("Error fetching managing admin:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (managingAdminResult.length === 0) {
        res.status(404).json({ error: "Managing admin not found" });
      } else {
        const managingAdmin = managingAdminResult[0].managing_admin;
        const sqlTodayAppointments = "SELECT name, booking_date FROM appointment_booking WHERE managing_admin = ?";
        
        Pool.query(sqlTodayAppointments, [managingAdmin, today], (error, appointmentsResult) => {
          if (error) {
            console.error("Error fetching today's appointments:", error);
            res.status(500).json({ error: "Internal server error" });
          } else {
            res.json(appointmentsResult);
          }
        });
      }
    }
  });
});


app.get("/api/hospital-details/gender-count/:username", (req, res) => {
  const { username } = req.params;

  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
    if (error) {
      console.error("Error fetching managing admin:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (managingAdminResult.length === 0) {
        res.status(404).json({ error: "Managing admin not found" });
      } else {
        const managingAdmin = managingAdminResult[0].managing_admin;
        const sqlGenderCounts = "SELECT Gender, COUNT(*) as gendercount FROM appointment_booking WHERE managing_admin = ? GROUP BY Gender";
        
        Pool.query(sqlGenderCounts, [managingAdmin], (error, genderCountsResult) => {
          if (error) {
            console.error("Error fetching gender counts:", error);
            res.status(500).json({ error: "Internal server error" });
          } else {
            // Construct response object with gender counts
            const genderCounts = {};
            genderCountsResult.forEach(row => {
              genderCounts[row.Gender] = row.count;
            });
            res.json(genderCounts);
          }
        });
      }
    }
  });
});

app.get("/api/hospital-details/get-booking-dates-by-month/:username", (req, res) => {
  const { username } = req.params;

  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
    if (error) {
      console.error("Error fetching managing admin:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (managingAdminResult.length === 0) {
        res.status(404).json({ error: "Managing admin not found" });
      } else {
        const managingAdmin = managingAdminResult[0].managing_admin;
        const sqlBookingDatesByMonth = "SELECT MONTH(booking_date) AS month, COUNT(*) AS count FROM appointment_booking WHERE managing_admin = ? GROUP BY MONTH(booking_date)";
        
        Pool.query(sqlBookingDatesByMonth, [managingAdmin], (error, bookingDatesResult) => {
          if (error) {
            console.error("Error fetching booking dates by month:", error);
            res.status(500).json({ error: "Internal server error" });
          } else {
            res.json({ bookingDatesByMonth: bookingDatesResult });
          }
        });
      }
    }
  });
});



app.get("/api/doctor-details/appointment/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM appointment_booking WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


app.get("/api/doctor-details/appointmentclinic/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM Hospital_Appointment WHERE HospitalFullName = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


app.get("/api/doctor-details/shifttiming/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM clinics WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

app.get("/api/doctor-details/shift1/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM admin_doctors";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});



app.get("/api/doctor-details/shifttime/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT DISTINCT days,from_time,to_time FROM doctor_op_timings WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});

app.get("/api/doctor-details/shifttime2/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT DISTINCT days,from_time,to_time FROM doctor_op_timings WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


// app.get("/api/doctor-details/workspace/:username", (req, res) => {
//   const { username } = req.params;
//   const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
//   Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
//       if (error) {
//           console.error("Error fetching managing admin:", error);
//           res.status(500).json({ error: "Internal server error" });
//       } else {
//           if (managingAdminResult.length === 0) {
//               res.status(404).json({ error: "Managing admin not found" });
//           } else {
//               const managingAdmin = managingAdminResult[0].managing_admin;
//               const sqlHospitalDetails = "SELECT * FROM   clinics  WHERE managing_admin= ?";
              
//               Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
//                   if (error) {
//                       console.error("Error fetching hospital details:", error);
//                       res.status(500).json({ error: "Internal server error" });
//                   } else {
//                       res.json(hospitalDetailsResult);
//                   }
//               });
//           }
//       }
//   });
// });


// app.get("/api/doctor-details/workspace/:username", (req, res) => {
//   const { username } = req.params;
//   const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";

//   Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
//       if (error) {
//           console.error("Error fetching managing admin:", error);
//           res.status(500).json({ error: "Internal server error" });
//       } else {
//           if (managingAdminResult.length === 0) {
//               res.status(404).json({ error: "Managing admin not found" });
//           } else {
//               const managingAdmin = managingAdminResult[0].managing_admin;
//               const sqlHospitalDetails = "SELECT * FROM clinics WHERE managing_admin = ?";

//               Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
//                   if (error) {
//                       console.error("Error fetching hospital details:", error);
//                       res.status(500).json({ error: "Internal server error" });
//                   } else {
//                       res.locals.hospitalDetails = hospitalDetailsResult;
//                       next(); // Call the next middleware to continue processing
//                   }
//               });
//           }
//       }
//   });
// });

// // Middleware to fetch clinic details based on clinic name
// app.get("/api/doctor-details/workspace/:username", (req, res, next) => {
//   const clinicName = req.query.clinicName; // Assuming clinicName is provided as query parameter
//   const sqlClinicDetails = "SELECT * FROM clinics WHERE clinic_name = ?";

//   Pool.query(sqlClinicDetails, [clinicName], (error, clinicDetailsResult) => {
//       if (error) {
//           console.error("Error fetching clinic details:", error);
//           res.status(500).json({ error: "Internal server error" });
//       } else {
//           res.json({ hospitalDetails: res.locals.hospitalDetails, clinicDetails: clinicDetailsResult });
//       }
//   });
// });


app.get("/api/doctor-details/workspace/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM clinics WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult);
                  }
              });
          }
      }
  });
});


app.get("/api/doctor-details/clinic/:clinicName", (req, res) => {
  const { clinicName } = req.params;
  const sqlClinicDetails = "SELECT * FROM clinics WHERE clinic_name = ?";
  
  Pool.query(sqlClinicDetails, [clinicName], (error, clinicDetailsResult) => {
      if (error) {
          console.error("Error fetching clinic details:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          res.json(clinicDetailsResult);
      }
  });
});


app.get("/api/doctor-details/workspace1/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM Hospital_Details WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult1) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult1);
                  }
              });
          }
      }
  });
});


app.get("/api/doctor-details/clinic1/:clinicName", (req, res) => {
  const { hospitalName } = req.params;
  const sqlClinicDetails = "SELECT * FROM Hospital_Details WHERE HospitalFullName = ?";
  
  Pool.query(sqlClinicDetails, [hospitalName], (error, clinicDetailsResult1) => {
      if (error) {
          console.error("Error fetching clinic details:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          res.json(clinicDetailsResult1);
      }
  });
});


app.get("/api/hospital-details/doctoradmin/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM admin_doctors WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult1) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult1);
                  }
              });
          }
      }
  });
});


app.get("/api/doctor-details/doctor1/:Name", (req, res) => {
  const { hospitalName } = req.params;
  const sqlClinicDetails = "SELECT * FROM admin_doctors WHERE doctor_name = ?";
  
  Pool.query(sqlClinicDetails, [hospitalName], (error, clinicDetailsResult1) => {
      if (error) {
          console.error("Error fetching clinic details:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          res.json(clinicDetailsResult1);
      }
  });
});


app.get("/api/get-image/:doctorName", (req, res) => {
  const { doctorName } = req.params;
  const sql = "SELECT filename FROM admin_doctors WHERE doctor_name = ?";
  
  Pool.query(sql, [doctorName], (error, results) => {
    if (error) {
      console.error("Error fetching image:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: "Image not found" });
      } else {
        res.json({ filename: results[0].filename });
      }
    }
  });
});


router.get("/api/get-image/:doctorName", (req, res) => {
  const { doctorName } = req.params;
  const sql = "SELECT filename FROM admin_doctors WHERE doctor_name = ?";
  
  Pool.query(sql, [doctorName], (error, results) => {
    if (error) {
      console.error("Error fetching image:", error);
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: "Image not found" });
      } else {
        res.json({ filename: results[0].filename });
      }
    }
  });
});

module.exports = router;


app.get("/api/get/doctor-slots/:doctor_Id/:date", (req, res) => {
  const { doctor_Id, date } = req.params;
 
  // Use placeholders (?) in the SQL query and pass parameters separately
  const sqlGetSlots = "SELECT DISTINCT from_time, to_time FROM doctor_op_timings WHERE CONCAT(from_time, ' - ', to_time) NOT IN (SELECT slot_time FROM appointment_booking WHERE doctor_id = ? AND booking_date = ?) AND doctor_id = ? AND date = ?";
 
  // Execute the query with the correct parameters
  Pool.query(sqlGetSlots, [doctor_Id, date, doctor_Id, date], (error, result) => {
      if (error) {
          console.error('Error getting doctor slots:', error);
          res.status(500).json({ error: 'Internal server error' });
          return;
      }
 
      const slots = result.map((slot) => ({
          from_time: slot.from_time,
          to_time: slot.to_time
      }));
      res.json(slots);
  });
});

app.get("/api/get/hspdoctor-slots/:doctor_Id/:date", (req, res) => {
  const { doctor_Id, date } = req.params;
 
  // Use placeholders (?) in the SQL query and pass parameters separately
  const sqlGetSlots = "SELECT DISTINCT from_time, to_time FROM doctor_op_timings WHERE CONCAT(from_time, ' - ', to_time) NOT IN (SELECT slot_time FROM Hospital_Appointment WHERE doctor_id = ? AND booking_date = ?) AND doctor_id = ? AND date = ?";
 
  // Execute the query with the correct parameters
  Pool.query(sqlGetSlots, [doctor_Id, date, doctor_Id, date], (error, result) => {
      if (error) {
          console.error('Error getting doctor slots:', error);
          res.status(500).json({ error: 'Internal server error' });
          return;
      }
 
      const slots = result.map((slot) => ({
          from_time: slot.from_time,
          to_time: slot.to_time
      }));
      res.json(slots);
  });
});


app.post('/api/appointment_booking', (req, res) => {
  const formData = req.body;
 
  const sqlInsertBooking = 'INSERT INTO appointment_booking ( name, contact, email, address, booking_date, slot_time, clinic_name, locality, doctor_id, doctor_name, consultation_fee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  const sqlInsertTryBook = 'INSERT INTO trybook (doctor_id, name, booking_date, slot_time) VALUES (?, ?, ?, ?)';
 
  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ success: false, message: 'Internal Server Error' });
      return;
    }
 
    connection.beginTransaction((err) => {
      if (err) {
        console.error('Error beginning transaction:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
        connection.release();
        return;
      }
 
      connection.query(sqlInsertBooking, [formData.name, formData.contact, formData.email, formData.address, formData.booking_date, formData.slot_time, formData.clinic_name, formData.locality, formData.doctor_id,  formData.doctor_name, formData.consultation_fee], (err, result) => {
        if (err) {
          console.error('Error storing appointment booking details:', err);
          connection.rollback(() => {
            connection.release();
            res.status(500).json({ success: false, message: 'Internal Server Error' });
          });
          return;
        }
 
        const { insertId: appointmentId } = result;
 
        connection.query(sqlInsertTryBook, [formData.doctor_id, formData.name, formData.booking_date, formData.slot_time], (err) => {
          if (err) {
            console.error('Error storing trybook details:', err);
            connection.rollback(() => {
              connection.release();
              res.status(500).json({ success: false, message: 'Internal Server Error' });
            });
            return;
          }
 
          connection.commit((err) => {
            if (err) {
              console.error('Error committing transaction:', err);
              connection.rollback(() => {
                connection.release();
                res.status(500).json({ success: false, message: 'Internal Server Error' });
              });
              return;
            }
 
            connection.release();
 
            res.status(200).json({ success: true, message: 'Appointment booked successfully!' });
          });
        });
      });
    });
  });
});
 
app.post('/api/appointment_bookinghospital', (req, res) => {
  const formData = req.body;
 
  const sqlInsertBooking = 'INSERT INTO Hospital_Appointment ( name, contact, email, address, booking_date, slot_time, HospitalFullName, locality, doctor_id, doctor_name, consultation_fee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  const sqlInsertTryBook = 'INSERT INTO trybook (doctor_id, name, booking_date, slot_time) VALUES (?, ?, ?, ?)';
 
  Pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection:', err);
      res.status(500).json({ success: false, message: 'Internal Server Error' });
      return;
    }
 
    connection.beginTransaction((err) => {
      if (err) {
        console.error('Error beginning transaction:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
        connection.release();
        return;
      }
 
      connection.query(sqlInsertBooking, [formData.name, formData.contact, formData.email, formData.address, formData.booking_date, formData.slot_time, formData.HospitalFullName, formData.locality, formData.doctor_id,  formData.doctor_name, formData.consultation_fee], (err, result) => {
        if (err) {
          console.error('Error storing appointment booking details:', err);
          connection.rollback(() => {
            connection.release();
            res.status(500).json({ success: false, message: 'Internal Server Error' });
          });
          return;
        }
 
        const { insertId: appointmentId } = result;
 
        connection.query(sqlInsertTryBook, [formData.doctor_id, formData.name, formData.booking_date, formData.slot_time], (err) => {
          if (err) {
            console.error('Error storing trybook details:', err);
            connection.rollback(() => {
              connection.release();
              res.status(500).json({ success: false, message: 'Internal Server Error' });
            });
            return;
          }
 
          connection.commit((err) => {
            if (err) {
              console.error('Error committing transaction:', err);
              connection.rollback(() => {
                connection.release();
                res.status(500).json({ success: false, message: 'Internal Server Error' });
              });
              return;
            }
 
            connection.release();
 
            res.status(200).json({ success: true, message: 'Appointment booked successfully!' });
          });
        });
      });
    });
  });
});


app.get("/api/get/doctor-slots/:doctorId/:date", (req, res) => {
  const { doctorId, date } = req.params;
  // const day = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
 
 
  const sqlGetSlots = "SELECT DISTINCT from_time , to_time FROM doctor_op_timings WHERE concat( from_time ,' - ', to_time) NOT IN (SELECT slot_time FROM appointment_booking WHERE doctor_id=? AND booking_date=?) AND doctor_id=? AND date=?";
  // const sqlGetSlots = "SELECT DISTINCT from_time, to_time FROM doctor_op_timings WHERE doctor_id = ?  AND days = ?;";
  Pool.query(sqlGetSlots, [doctorId, date, doctorId, date], (error, result) => {
      if (error) {
          console.error('Error getting doctor slots:', error);
          res.status(500).json({ error: 'Internal server error' });
          return;
      }
 
      const slots = result.map((slot) => ({
          from_time: slot.from_time,
          to_time: slot.to_time
      }));
      res.json(slots);
  });
});


app.get("/api/hospital-details/appointment_booking/:username", (req, res) => {
  const { username } = req.params;
  const sqlManagingAdmin = "SELECT managing_admin FROM AddAdmins WHERE username = ?";
  
  Pool.query(sqlManagingAdmin, [username], (error, managingAdminResult) => {
      if (error) {
          console.error("Error fetching managing admin:", error);
          res.status(500).json({ error: "Internal server error" });
      } else {
          if (managingAdminResult.length === 0) {
              res.status(404).json({ error: "Managing admin not found" });
          } else {
              const managingAdmin = managingAdminResult[0].managing_admin;
              const sqlHospitalDetails = "SELECT * FROM appointment_booking WHERE managing_admin = ?";
              
              Pool.query(sqlHospitalDetails, [managingAdmin], (error, hospitalDetailsResult1) => {
                  if (error) {
                      console.error("Error fetching hospital details:", error);
                      res.status(500).json({ error: "Internal server error" });
                  } else {
                      res.json(hospitalDetailsResult1);
                  }
              });
          }
      }
  });
});

app.get('/api/data', (req, res) => {
  const sql = 'SELECT * FROM booking';
  Pool.query(sql, (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.json(result);
  });
});

// Update a booking
app.put('/api/data/:id', (req, res) => {
  const { id } = req.params;
  const { name, phone_number, email, date, timeslot, doctor } = req.body;
  const sql = `
    UPDATE booking 
    SET name = ?, phone_number = ?, email = ?, date = ?, timeslot = ?, doctor = ? 
    WHERE id = ?
  `;
  const values = [name, phone_number, email, date, timeslot, doctor, id];
  Pool.query(sql, values, (err, result) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.json({ id, name, phone_number, email, date, timeslot, doctor });
  });
});
