const express = require("express");
const router = new express.Router();
const nodemailer = require("nodemailer");
 
 
 
 
 
// send mail
router.post("/api/register",  (req, res) => {
 
    // const { Email } = req.body;
 
 
    try {
            console.log(req.query.Email);
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.EMAIL,
                pass: process.env.PASSWORD
            }
        });
 
        const mailOptions = {
            from: process.env.EMAIL,
            to: req.query.Email,
            subject: "Booking Conformation Mail",
            html: 'You had booked your Ambulance succesfully for the Specified date and Time'
        };
 
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log("Error" + error)
            } else {
                console.log("Email sent:" + info.response);
                res.status(201).json({status:201,info})
            }
        })
 
    } catch (error) {
        console.log("Error:" + error);
        res.status(401).json({status:401,error})
    }
});
 
 
module.exports = router;