const mysql = require("mysql2");


const Pool = mysql.createPool({
    host: "103.92.235.85",
    user: "yatayati_hteam",
    password: "VinayHD@1922",
    database: "yatayati_hospi-basic",
}); // Assuming you have a database connection file

// Define the collection name
const COLLECTION_NAME = 'users';

// Define functions to interact with the users collection
module.exports = {
  async getUserByUsername(username) {
    const db = getDb(); // Get the database instance
    return await db.collection(COLLECTION_NAME).findOne({ username });
  },

  // Add other CRUD operations as needed
};
