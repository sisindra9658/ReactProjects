const express = require('express');
const router = express.Router();

// Route to fetch managing admin's name based on the logged-in admin's username
router.get('/managingAdminName/:username', async (req, res) => {
  try {
    const { username } = req.params;
    const admin = await AdminModel.findOne({ username });
    if (admin) {
      const managingAdminUsername = admin.managing_admin;
      const managingAdmin = await AdminModel.findOne({ username: managingAdminUsername });
      if (managingAdmin) {
        const managingAdminName = `${managingAdmin.Primary_name} ${managingAdmin.Secondary_name}`;
        res.json({ managingAdminName });
      } else {
        res.status(404).json({ error: 'Managing admin not found' });
      }
    } else {
      res.status(404).json({ error: 'Admin not found' });
    }
  } catch (error) {
    console.error('Error fetching managing admin name:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;