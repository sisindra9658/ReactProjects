import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';

export default function TextFieldSizes() {
  const [age, setAge] = React.useState('');
  const [Ambulance, setAmbulance] = React.useState('');


  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const handleChange1 = (event) => {
    setAmbulance(event.target.value);
  };

  return (
    <>
    <h1 style={{justifyContent:"center", display:"flex"}}>EDIT PROFILE</h1>
    <div className='row' style={{justifyContent:"center", display:"flex"}}>
    <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { m: 1, width: '100%' },
      }}
      noValidate
      autoComplete="off"
    >
      <div>
      <div className='column'>

      <TextField label="FName" placeholder="First Name" id="outlined-size-normal" style={{width:"350px"}} />
      </div>
      <div className='column'>

      <TextField label="LName" placeholder="Last Name" id="outlined-size-normal" style={{width:"350px"}} />
      </div>
      <div className='column'>

      <TextField label="Phone number" placeholder="Phone Number" id="outlined-size-normal" style={{width:"350px"}} />
      </div>
      <div className='column'>

    <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label">gender</InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={age}
        label="Age"
        onChange={handleChange}
        style={{width:"350px", height:"50px"}}
      >
        <MenuItem value="Age">
        </MenuItem>
        <MenuItem value={10}>Male</MenuItem>
        <MenuItem value={20}>Female</MenuItem>
      </Select>
    </FormControl>
    </div>
    <div className='column'>

    <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label">Ambulance Type</InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={Ambulance}
        label="Type"
        onChange={handleChange1}
        style={{width:"350px", height:"50px"}}
      >
        <MenuItem value="Ambulance Type">
        </MenuItem>
        <MenuItem value={10}>Isolation  Ambulance</MenuItem>
        <MenuItem value={20}>First Responder Ambulance</MenuItem>
        <MenuItem value={30}>Advanced life Support</MenuItem>
        <MenuItem value={40}>MVA Ambulance</MenuItem>
        <MenuItem value={50}>Advanced life Support</MenuItem>
        <MenuItem value={60}>Patient Transport Ambulance</MenuItem>
        <MenuItem value={70}>ICU  Ambulance</MenuItem>
        <MenuItem value={80}>Non Emergency</MenuItem>
        <MenuItem value={90}>Patient Transport Ambulance</MenuItem>
        <MenuItem value={11}>Neanatal Ambulance</MenuItem>
        <MenuItem value={12}>Ambulance Bus</MenuItem>
        <MenuItem value={13}>Dead Body Ambulance</MenuItem>
      </Select>
    </FormControl>
    </div>
    <div className='column'>

    <Stack spacing={2} direction="row" style={{justifyContent:"center", display:"flex", marginTop:"15px"}}>
      <Button variant="contained">Update</Button>
    </Stack>
    
    </div>
      </div>
    </Box>
    </div>
    </>
  );
}
