import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';
// import axios from 'axios';

const SearchSection = () => {
  // const { username } = useParams();
  // const [userData, setUserData] = useState(null);
  const [managingAdmin, setManagingAdmin] = useState(null);



  // useEffect(() => {
  //   const fetchUserDetails = async () => {
  //     try {
  //       const response = await axios.get(`http://localhost:5000/api/adminuserdetails/${username}`);
  //       setUserData(response.data);
  //     } catch (error) {
  //       console.error('Error fetching user data:', error);
  //     }
  //   };

  //   fetchUserDetails();
  // }, [username]);


  useEffect(() => {
    // Retrieve userData from local storage
    const userData = JSON.parse(localStorage.getItem('userData'));
    if (userData) {
      setManagingAdmin(userData.managing_admin);
    }
  }, []);


  return (
    <div>
        <div style={{marginLeft:'50px'}}>
        <h1 style={{color:'#00ab9f'}}>{managingAdmin}</h1>
          </div>
    </div>
  );
};

export default SearchSection;
