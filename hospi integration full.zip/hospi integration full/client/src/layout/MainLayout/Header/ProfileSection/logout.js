// Action types
export const LOGOUT_USER = 'LOGOUT_USER';

// Action creators
export const logoutUser = () => ({
  type: LOGOUT_USER
});

export const clearAccessToken = () => ({
  type: 'CLEAR_ACCESS_TOKEN'
});
