import { useState, useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { logoutUser, clearAccessToken } from 'layout/MainLayout/Header/ProfileSection/logout'; // Importing logoutUser action creator
// import { useParams } from 'react-router-dom';
import PropTypes from 'prop-types';
import React from 'react';
import axios from 'axios';

import {  useNavigate } from 'react-router-dom';

// material-ui
import { useTheme } from '@mui/material/styles';
import {
  Avatar,
  Box,
  Chip,
  ClickAwayListener,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Paper,
  Popper,
  Typography
} from '@mui/material';

// third-party
import PerfectScrollbar from 'react-perfect-scrollbar';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import Transitions from 'ui-component/extended/Transitions';


// assets
import { IconLogout, IconUser } from '@tabler/icons';
 

// ==============================|| PROFILE MENU ||============================== //

const ProfileSection = () => {
  const theme = useTheme();
  const customization = useSelector((state) => state.customization);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [open, setOpen] = useState(false);
  /**
   * anchorRef is used on different componets and specifying one type leads to other components throwing an error
   * */
  const anchorRef = useRef(null);

  const [loggedInUsername, setLoggedInUsername] = useState('');


useEffect(() => {
  // Retrieve username from local storage
  const usernameFromStorage = localStorage.getItem('username');
  console.log('Username retrieved from localStorage:', usernameFromStorage);
  if (usernameFromStorage) {
    setLoggedInUsername(usernameFromStorage);
  }
}, []);


const LOGOUT_TIME = 20 * 60 * 1000;
  let logoutTimer = useRef(null);


  const handleLogout = () => {
    // localStorage.removeItem('username');
    // localStorage.removeItem('userData');
    dispatch(logoutUser());
    dispatch(clearAccessToken());
    sessionStorage.removeItem('username'); 
  
    const loginTime = localStorage.getItem('loginTime');
    if (loginTime) {
      const currentTime = new Date().getTime();
      const sessionDuration = (currentTime - parseInt(loginTime)) / (1000 * 60);
  
      axios.post('http://localhost:5000/api/logout', { sessionDuration })
        .then(() => {
          console.log('Logout successful');
        })
        .catch(error => {
          console.error('Error during logout:', error);
        });
    }
  
    try {
      window.location.href = 'http://localhost:3000';
    } catch (error) {
      console.error('Error navigating to login page:', error);
    }
  };

  const handleClose = (event) => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }
    setOpen(false);
};

  const handleListItemClick = (event, index, route = '') => {
    setSelectedIndex(index);
    handleClose(event);

    if (route && route !== '') {
      navigate(route);
    }
  };
  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const startLogoutTimer = () => {
    logoutTimer.current = setTimeout(() => {
      handleLogout();
    }, LOGOUT_TIME);
  };

  const resetLogoutTimer = () => {
    clearTimeout(logoutTimer.current);
    startLogoutTimer();
  };

  const prevOpen = useRef(open);
  useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);

  useEffect(() => {
    startLogoutTimer();
    return () => {
      clearTimeout(logoutTimer.current);
    };
  }, []);

  return (
    <>
        <Chip
           sx={{
            display: 'flex',
            alignItems: 'center',
            padding: '8px 16px',
            borderRadius: '27px',
            transition: 'all .2s ease-in-out',
            backgroundColor: 'white',
            '&:hover': {
              backgroundColor: 'white',
            },
          }}        
          icon={
          <Box
  sx={{
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#4edcd8', // Change this to your desired background color
    padding: '8px 16px', // Add padding to adjust spacing
    borderRadius: '27px',
    transition: 'all .2s ease-in-out',
    borderColor: theme.palette.primary.light,
    '&:hover': {
      backgroundColor: 'red', // Change this to your desired hover background color
    },
  }}
>
  <Avatar
    sx={{
      ...theme.typography.mediumAvatar,
      margin: '0 8px 0 0',
      cursor: 'pointer',
    }}
    ref={anchorRef}
    aria-controls={open ? 'menu-list-grow' : undefined}
    aria-haspopup="true"
    color="blue"
  />
  <Typography variant="body1" sx={{ color: 'white', fontWeight: 'bold' }}>{ loggedInUsername || 'Guest'}</Typography>
</Box>

          }
          ref={anchorRef}
          aria-controls={open ? 'menu-list-grow' : undefined}
          aria-haspopup="true"
          onClick={handleToggle}
          color="primary"
        />


      <Popper
        placement="bottom-end"
        open={open}
        anchorEl={anchorRef.current}
        role={undefined}
        transition
        disablePortal
        popperOptions={{
          modifiers: [
            {
              name: 'offset',
              options: {
                offset: [0, 14]
              }
            }
          ]
        }}
      >
        {({ TransitionProps }) => (
          <Transitions in={open} {...TransitionProps}>
            <Paper>
              <ClickAwayListener onClickAway={handleClose}>
                <MainCard border={false} elevation={16} content={false} boxShadow shadow={theme.shadows[16]}>
                  <PerfectScrollbar style={{ height: '100%', maxHeight: 'calc(100vh - 250px)', overflowX: 'hidden' }}>
                    <Box sx={{ p: 2 }}>
                      <List
                        component="nav"
                        sx={{
                          width: '100%',
                          maxWidth: 180,
                          minWidth: 150,
                          backgroundColor: theme.palette.background.paper,
                          borderRadius: '10px',
                          [theme.breakpoints.down('md')]: {
                            minWidth: '100%'
                          },
                          '& .MuiListItemButton-root': {
                            mt: 0.5
                          }
                        }}
                      >
                        <ListItemButton
                          sx={{ borderRadius: `${customization.borderRadius}px` }}
                          selected={selectedIndex === 4}
                          onClick={(event) => {
                            handleListItemClick(event, 1, 'editprofile');
                            resetLogoutTimer(); // Reset the auto logout timer when an action is performed
                          }}
                        >
                          <ListItemIcon>
                            <IconUser stroke={1.5} size="1.3rem" />
                          </ListItemIcon>
                          <ListItemText primary={<Typography variant="body2">Edit Profile</Typography>} />
                        </ListItemButton>
                        <ListItemButton
                          sx={{ borderRadius: `${customization.borderRadius}px` }}
                          selected={selectedIndex === 4}
                          onClick={() => {
                            handleLogout();
                            resetLogoutTimer();
                          }}
                        >
                          <ListItemIcon>
                            <IconLogout stroke={1.5} size="1.3rem" />
                          </ListItemIcon>
                          <ListItemText primary={<Typography variant="body2">Logout</Typography>} />
                        </ListItemButton>
                      </List>
                    </Box>
                  </PerfectScrollbar>
                </MainCard>
              </ClickAwayListener>
            </Paper>
          </Transitions>
        )}
      </Popper>
    </>
  );
};

ProfileSection.propTypes = {
  username: PropTypes.string.isRequired
};

export default ProfileSection;