const config = {
  // basename: '/free',
  defaultPath: '/dashboard/default',
  fontFamily: `'Roboto', sans-serif`,
  borderRadius: 12
};

export default config;
