// import { useSelector } from 'react-redux';
// import { ThemeProvider } from '@mui/material/styles';
// import { CssBaseline, StyledEngineProvider } from '@mui/material';
// // import { BrowserRouter, Routes } from "react-router-dom";


// import Routes from 'routes';

// // defaultTheme
// import themes from 'themes';

// // project imports
// import NavigationScroll from 'layout/NavigationScroll';
// import Profile from 'Profile';
// // import Profile from 'Profile';
// // import Profile from 'Profile';


// // ==============================|| APP ||============================== //

// const App = () => {
//   const customization = useSelector((state) => state.customization);

//   return (
//     <StyledEngineProvider injectFirst>
//       <ThemeProvider theme={themes(customization)}>
//         <CssBaseline />
//         <NavigationScroll>
//           <Routes />
//           {/* <BrowserRouter> */}
//           <Routes  path="/profile" element={<Profile />} />   
//                {/* /  </BrowserRouter> */}
//           {/* <Profile/> */}
//           {/* <Routes  path="/profile" element={<Profile />} />   */}
//         </NavigationScroll>
//       </ThemeProvider>
//     </StyledEngineProvider>
//   );
// };

// export default App;
 
import React from 'react';
import { useSelector } from 'react-redux';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline, StyledEngineProvider } from '@mui/material';
import { Routes, Route } from 'react-router-dom';
import AppRoutes from 'routes';
import themes from 'themes';
import NavigationScroll from 'layout/NavigationScroll';
 
const App = () => {
  const customization = useSelector((state) => state.customization);
 
  return (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={themes(customization)}>
        <CssBaseline />
        <NavigationScroll>
          <Routes>
            <Route path="*" element={<AppRoutes />} />
          </Routes>
        </NavigationScroll>
      </ThemeProvider>
    </StyledEngineProvider>
  );
};
 
export default App;