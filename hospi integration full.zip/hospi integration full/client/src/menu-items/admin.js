// assets
import { IconKey } from '@tabler/icons';
import { FaUserCog } from 'react-icons/fa';
import { FaUserPlus } from 'react-icons/fa';



// constant
const icons = {
  IconKey,
  FaUserCog,
  FaUserPlus
};

const pages = {
  id: 'pages',
  type: 'group',
  
  children: [
    {
      title: 'Admins',
      type: 'collapse',
      icon: icons.FaUserCog,

      children: [
        {
          id: 'add admins',
          title: 'Add Admin',
          type: 'item',
          url: '/SuperAdmin/util-Addadmin',
          icon: icons.FaUserPlus,
        },
        {
          id: 'manage admin',
          title: 'Manage Admins',
          type: 'item',
          url: '/SuperAdmin/util-Manageadmin',
          icon: icons.FaUserCog,
        }
      ]
    }
  ]
};

export default pages;
