import { FaFlask } from 'react-icons/fa';
import { FaUserMd } from 'react-icons/fa';
import { FaBed } from 'react-icons/fa';
import { FaUserNurse } from 'react-icons/fa';
import { FaPrescriptionBottle } from 'react-icons/fa';
import { FaSuitcase } from 'react-icons/fa';
import { FaUsers } from 'react-icons/fa6';
import { FaCalendarAlt } from 'react-icons/fa';
import { FaMedkit } from 'react-icons/fa';
import { FaFileAlt } from 'react-icons/fa';


const icons = {
  FaFlask,
  FaUserMd,
  FaBed,
  FaUserNurse,
  FaPrescriptionBottle,
  FaSuitcase,
  FaUsers,
  FaCalendarAlt,
  FaMedkit,
  FaFileAlt
};

const utilities = {
  url: '/',
  id: 'utilities',
  type: 'group',
  children: [
    {
     
    id: 'Staff',
    title: 'Staff',
    type: 'collapse',
    icon: icons.FaUsers,
    url: '/',
    children: [
      {
        id: 'Doctors',
        title: 'Doctors',
        type: 'item',
        url: '/Admin/util-Doctors',
        icon: icons.FaUserMd ,
        breadcrumbs: true,
        target: false
      },
      {
        id: 'Patients',
        title: 'Patients',
        type: 'item',
        url: '/Admin/util-Patients',
        icon: icons.FaBed,
        breadcrumbs: true,
        target: false
      },
      {
        id: 'Nurses',
        title: 'Nurses',
        type: 'item',
        url: '/Admin/util-Nurses',
        icon: icons.FaUserNurse,
        breadcrumbs: true,
        target: false
      },
      {
        id: 'Pharmacist',
        title: 'Pharmacist',
        type: 'item',
        url: '/Admin/util-Pharmacist',
        icon: icons.  FaPrescriptionBottle,
        breadcrumbs: true,
        target: false
      },
      {
        id: 'Laboratorist',
        title: 'Laboratorist',
        type: 'item',
        icon: icons.FaFlask,
        breadcrumbs: true,
        url: '/Admin/util-Laboratorist',
        target: false
      },
      {
        id: 'Receptionist',
        title: 'Receptionist',
        type: 'item',
        url: '/Admin/util-Receptionist',
        icon: icons.FaSuitcase,
        breadcrumbs: true,
        target: false
      },
     
    ]},
    {
      id: 'Appointmentbooking',
      title: 'Appointment Booking',
      type: 'item',
      url: '/Admin/util-Appointmentbooking',
      icon: icons.FaCalendarAlt,
      breadcrumbs: true,
      target: false
    },
    {
      id: 'Packages',
      title: 'Health Packages',
      type: 'item',
      url: '/Admin/util-Healthpackages',
      icon: icons.FaMedkit,
      breadcrumbs: true,
      target: false
    },
    {
      id: 'Reports',
      title: 'Reports',
      type: 'item',
      url: '/Admin/util-Reports',
      icon: icons.FaFileAlt,
      breadcrumbs: true,
      target: false
    }
  ]
  
};

export default utilities;
