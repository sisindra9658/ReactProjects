import { FaQuestionCircle } from 'react-icons/fa';
import { MdHelpOutline } from 'react-icons/md';
import { VscReferences } from "react-icons/vsc";
 
 
 
// constant
const icons = {
  FaQuestionCircle,
  MdHelpOutline,
  VscReferences
};
 
const otherpages = {
  id: 'otherpages',
  type: 'group',
  children: [
    {
      id: 'FAQ',
      title: 'FAQ',
      type: 'item',
      url: '/Doctor/DoctorFaq',
      icon: icons.FaQuestionCircle,
    },
    // {
    //   id: 'Help',
    //   title: 'Help',
    //   type: 'item',
    //   icon: icons.MdHelpOutline,
    //   url: '/utils/util-help'
    // },
    // {
    //   id: 'Refer',
    //   title: 'Refer',
    //   type: 'item',
    //   url: '/utils/util-refer',
    //   icon: icons.VscReferences
    // },
  ]
};
 
export default otherpages;
 