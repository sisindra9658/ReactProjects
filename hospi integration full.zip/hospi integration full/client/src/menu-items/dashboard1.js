// assets
import { IconDashboard } from '@tabler/icons';

// constant
const icons = { IconDashboard };

const dashboard1 = {
  id: 'dashboard',
  title: 'Super Admin Dashboard',
  type: 'group',
  children: [
    {
      id: 'Dashboard',
      title: 'Dashboard',
      type: 'item',
      url: '/SuperAdmin',
      icon: icons.IconDashboard
    }
  ]
};

export default dashboard1;
