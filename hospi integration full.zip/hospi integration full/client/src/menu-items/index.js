// import dashboard from './dashboard';
 
// import utilities from './utilities';
// import otherpages from './otherpages';
// import dashboard1 from './dashboard1';
 
// import utilities1 from './utilities1';
// import otherpages1 from './otherpages1';
// import pages from './admin';
 
// const menuItems = {
//   items: [dashboard, utilities, otherpages,dashboard1, pages,utilities1, otherpages1],
//   // items: [dashboard1, pages,utilities1, otherpages1]
 
// };
 
// export default menuItems;
 
// import dashboard from './dashboard';
// import utilities from './utilities';
// import otherpages from './otherpages';
// import dashboard1 from './dashboard1';
// import utilities1 from './utilities1';
// import otherpages1 from './otherpages1';
// import pages from './admin';
 
// const isGroup1 = true; // Set this condition based on your requirement
// const isGroup2 = false;
// const menuItems = {
//   items: []
// };
 
// if (isGroup1) {
//   menuItems.items.push(dashboard, utilities, otherpages);
// } else if (!isGroup2) {
//   menuItems.items.push(dashboard1, pages, utilities1, otherpages1);
// }
 
// export default menuItems;
 
 
import dashboard from './dashboard';
import utilities from './utilities';
import otherpages from './otherpages';
import dashboard1 from './dashboard1';
import dashboard2 from './dashboard2';
import utilities1 from './utilities1';
import utilities2 from './utilities2';
import otherpages1 from './otherpages1';
import otherpages2 from './otherpages2';
import pages from './admin';
// import UserUtil from './UserUtil';
 
// const isGroup1 = true; // Set this condition based on your requirement
// const isGroup2 = false;
const menuItems = {
  items: []
};
 
// Determine the current role based on the path
const path = window.location.pathname;
const isAdmin = path.startsWith('/Admin');
const isSuperadmin = path.startsWith('/SuperAdmin');
const isUser = path.startsWith('/User');
const isDoctor = path.startsWith('/Doctor');
 
if (isAdmin) {
  menuItems.items.push(dashboard, utilities, otherpages);
} else if (isSuperadmin) {
  menuItems.items.push(dashboard1, pages, utilities1, otherpages1);
}
else if (isDoctor) {
  menuItems.items.push(dashboard2,  utilities2, otherpages2);
}
else if (isUser) {
  menuItems.items.push();
}
export default menuItems;
 