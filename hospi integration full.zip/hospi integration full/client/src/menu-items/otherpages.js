import { FaQuestionCircle } from 'react-icons/fa';
import { MdHelpOutline } from 'react-icons/md';
import { VscReferences } from "react-icons/vsc";




const icons = {
    FaQuestionCircle,
    MdHelpOutline,
    VscReferences,
    
};

const utilities = {
  id: 'otherpages',
  type: 'group',
  
    children: [
      
      {
        id: 'FAQ',
        title: 'FAQ',
        type: 'item',
        url: '/Admin/util-FAQ',
        icon: icons.FaQuestionCircle ,
        breadcrumbs: false
      },
      {
        id: 'Refference',
        title: 'Refference',
        type: 'item',
        url: '/Admin/util-Refference',
        icon: icons.VscReferences,
        breadcrumbs: false
      },
      {
        id: 'Help',
        title: 'Help',
        type: 'item',
        url: '/Admin/util-Help',
        icon: icons.MdHelpOutline,
        breadcrumbs: false
      }
      
     
      
   
  ]
  
};

export default utilities;
