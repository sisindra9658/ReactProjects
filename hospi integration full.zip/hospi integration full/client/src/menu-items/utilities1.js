import DocumentScannerIcon from '@mui/icons-material/DocumentScanner';
import PeopleIcon from '@mui/icons-material/People';
import MapIcon from '@mui/icons-material/Map';
import SummarizeIcon from '@mui/icons-material/Summarize';
import ReceiptIcon from '@mui/icons-material/Receipt';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import ApartmentIcon from '@mui/icons-material/Apartment';
import AirportShuttleIcon from '@mui/icons-material/AirportShuttle';
import { FaUserMd } from 'react-icons/fa';
import { FaFlask } from 'react-icons/fa';
import { FaUserCog } from 'react-icons/fa';
import { FaUser } from 'react-icons/fa';



// constant
const icons = {
  DocumentScannerIcon,
  PeopleIcon,
  MapIcon,
  SummarizeIcon,
  ReceiptIcon,
  AirportShuttleIcon,
  LocalHospitalIcon,
  ApartmentIcon,
  FaUserMd,
  FaFlask,
  FaUserCog,
  FaUser
};

const utilities1 = {
  id: 'utilities',
  type: 'group',
  children: [
    // {
    //   id: 'Manageadmin',
    //   title: 'Manageadmin',
    //   type: 'item',
    //   url: '/SuperAdmin/util-Manageadmin',
    //   icon: icons.ApartmentIcon,
    // },
    // {
    //   id: 'Addadmin',
    //   title: 'Addadmin',
    //   type: 'item',
    //   url: '/SuperAdmin/util-Addadmin',
    //   icon: icons.ApartmentIcon,
    // },
    {
      id: 'Hospital',
      title: 'Hospital',
      type: 'item',
      url: '/SuperAdmin/util-Hospitals',
      icon: icons.ApartmentIcon,
    },
    {
      id: 'Clinics',
      title: 'Clinics',
      type: 'item',
      url: '/SuperAdmin/util-Clinics',
      icon: icons.LocalHospitalIcon,
    },
    {
      id: 'Ambulance',
      title: 'Ambulance',
      type: 'item',
      url: '/SuperAdmin/util-Ambulance',
      icon: icons.AirportShuttleIcon,
    },
    {
      id: 'Doctors',
      title: 'Doctors',
      type: 'item',
      icon: icons.FaUserMd,
      url: '/SuperAdmin/util-Doctors'
    },
    {
      id: 'Diagnosticlabs',
      title: 'Diagnostic Labs',
      type: 'item',
      url: '/SuperAdmin/util-Diagnosticlabs',
      icon: icons.FaFlask,
    },
    {
      id: 'Patients',
      title: 'Patients',
      type: 'item',
      url: '/SuperAdmin/util-Patients',
      icon: icons.FaUser,
    },
  ]
};

export default utilities1;
