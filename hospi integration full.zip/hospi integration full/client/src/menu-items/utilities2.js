import DocumentScannerIcon from '@mui/icons-material/DocumentScanner';
import PeopleIcon from '@mui/icons-material/People';
import MapIcon from '@mui/icons-material/Map';
import SummarizeIcon from '@mui/icons-material/Summarize';
import ReceiptIcon from '@mui/icons-material/Receipt';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import ApartmentIcon from '@mui/icons-material/Apartment';
import AirportShuttleIcon from '@mui/icons-material/AirportShuttle';
import { FaUserMd } from 'react-icons/fa';
import { FaFlask } from 'react-icons/fa';
import { FaUserCog } from 'react-icons/fa';
import { FaCalendarAlt } from 'react-icons/fa';
import { FaUser } from 'react-icons/fa';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
 
 
 
 
// constant
const icons = {
  DocumentScannerIcon,
  PeopleIcon,
  MapIcon,
  SummarizeIcon,
  ReceiptIcon,
  AirportShuttleIcon,
  LocalHospitalIcon,
  ApartmentIcon,
  FaUserMd,
  FaFlask,
  FaUserCog,
  FaCalendarAlt,
  FaUser,
  AccessTimeIcon
};
 
const utilities = {
  id: 'utilities',
  type: 'group',
  children: [
    // {
    //   id: 'Hospital',
    //   title: 'Hospital',
    //   type: 'item',
    //   url: '/utils/util-Hospitals',
    //   icon: icons.ApartmentIcon,
    // },
    {
      id: 'Appointment',
      title: 'Appointment',
      type: 'item',
      url: '/Doctor/DoctorAppointment',
      icon: icons.FaCalendarAlt,
    },
    {
      id: 'PatientsDetail',
      title: 'PatientsDetails',
      type: 'item',
      url: '/Doctor/Doctorpatient',
      icon: icons.FaUser,
    },
    {
      id: 'ShiftTiming',
      title: 'ShiftTiming',
      type: 'item',
      url: '/Doctor/DoctorShifttiming',
      icon: icons.AccessTimeIcon,
    },
    {
      id: 'MyWorkSpace',
      title: 'MyWorkSpace',
      type: 'item',
      url: '/Doctor/DoctorMyWorkSpace',
      icon: icons.ApartmentIcon,
    },
    // {
    //   id: 'Clinics',
    //   title: 'Clinics',
    //   type: 'item',
    //   url: '/utils/util-Clinics',
    //   icon: icons.LocalHospitalIcon,
    // },
    // {
    //   id: 'Ambulance',
    //   title: 'Ambulance',
    //   type: 'item',
    //   url: '/utils/util-Ambulance',
    //   icon: icons.AirportShuttleIcon,
    // },
    // {
    //   id: 'Doctors',
    //   title: 'Doctors',
    //   type: 'item',
    //   icon: icons.FaUserMd,
    //   url: '/utils/util-Doctors'
    // },
    // {
    //   id: 'Diagnosticlabs',
    //   title: 'Diagnostic Labs',
    //   type: 'item',
    //   url: '/utils/util-Diagnosticlabs',
    //   icon: icons.FaFlask,
    // },
  ]
};
 
export default utilities;
 