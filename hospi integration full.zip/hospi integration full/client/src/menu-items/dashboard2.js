// assets
import { IconDashboard } from '@tabler/icons';
 
// constant
const icons = { IconDashboard };
 
const dashboard = {
  id: 'dashboard',
  title: 'Doctor Profile Dashboard',
  type: 'group',
  children: [
    {
      id: 'Dashboard',
      title: 'Dashboard',
      type: 'item',
      url: '/Doctor',
      icon: icons.IconDashboard
    }
  ]
};
 
export default dashboard;
 