
const UserUtil = {
  id: 'utilities',
  type: 'group',
  children: [
    
    {
      id: 'Hospital',
      title: 'Hospital',
      type: 'item',
      url: '/User/Hospitals',
     
    },
    {
      id: 'Clinics',
      title: 'Clinics',
      type: 'item',
      url: '/User/Clinics',
     
    },
    {
      id: 'Ambulance',
      title: 'Ambulance',
      type: 'item',
      url: '/User/Ambulance',
     
    },
    {
      id: 'Diagnosticlabs',
      title: 'Diagnosticlabs',
      type: 'item',
   
      url: '/User/Diagnosticlabs'
    },
    {
      id: 'Healthpackage',
      title: 'Healthpackage',
      type: 'item',
      url: '/User/HealthPage',
    //   icon: icons.FaFlask,
    },
    // {
    //   id: 'Patients',
    //   title: 'Patients',
    //   type: 'item',
    //   url: '/SuperAdmin/util-Patients',
    //   icon: icons.FaUser,
    // },
  ]
};

export default UserUtil;
