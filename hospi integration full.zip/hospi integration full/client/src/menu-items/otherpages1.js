import { FaQuestionCircle } from 'react-icons/fa';
import { MdHelpOutline } from 'react-icons/md';
import { VscReferences } from "react-icons/vsc";



// constant
const icons = {
  FaQuestionCircle,
  MdHelpOutline,
  VscReferences
};

const otherpages1 = {
  id: 'otherpages',
  type: 'group',
  children: [
    {
      id: 'FAQ',
      title: 'FAQ',
      type: 'item',
      url: '/SuperAdmin/util-faq',
      icon: icons.FaQuestionCircle,
    },
    {
      id: 'Help',
      title: 'Help',
      type: 'item',
      icon: icons.MdHelpOutline,
      url: '/SuperAdmin/util-help'
    },
    {
      id: 'Refer',
      title: 'Refer',
      type: 'item',
      url: '/Superadmin/util-refer',
      icon: icons.VscReferences
    },
  ]
};

export default otherpages1;
