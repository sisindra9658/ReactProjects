import logo from './logo.png';

const Logo = () => {
  return ( <img src={logo} alt="logo" width="180" /> );
};

export default Logo;
