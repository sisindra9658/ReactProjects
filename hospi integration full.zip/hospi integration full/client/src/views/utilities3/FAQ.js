import React from 'react'

function FAQ() {
  return (
    <div>FAQ</div>
  )
}

export default FAQ