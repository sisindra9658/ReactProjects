import React, { useState, useEffect } from 'react';
import { Card, CardContent, Typography, Grid } from '@mui/material';

function Index() {
  const [clinicData, setClinicData] = useState(null);
  const [hospitalData, setHospitalData] = useState(null);

  useEffect(() => {
    fetchClinicData();
    fetchHospitalData();
  }, []);

  const fetchClinicData = async () => {
    try {
      const username = localStorage.getItem('username');
      const response = await fetch(`http://localhost:5000/api/doctor-details/workspace/${username}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      setClinicData(data);
    } catch (error) {
      console.error('Error fetching clinic data:', error);
    }
  };

  const fetchHospitalData = async () => {
    try {
      const username = localStorage.getItem('username');
      const response = await fetch(`http://localhost:5000/api/doctor-details/workspace1/${username}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      setHospitalData(data);
    } catch (error) {
      console.error('Error fetching hospital data:', error);
    }
  };

  return (
    <>
    <Grid container spacing={2} justify="center" alignItems="center" style={{ marginTop: '50px' }}>
      {/* {hospitalData && <HospitalCard hospital={hospitalData} />} */}
      {hospitalData && hospitalData.map(hospital => (
        <Grid item key={hospital.hospi_id}>
          <HospitalCard hospital={hospital} />
        </Grid>
      ))}
      {clinicData && clinicData.map(clinic => (
        <Grid item key={clinic.clinic_id}>
          <ClinicCard clinic={clinic} />
        </Grid>
      ))}
    </Grid>
    </>
  );
}

function HospitalCard({ hospital }) {
  const [isHovered, setIsHovered] = useState(false);
  return (
    <div style={cardStyle}>
      <Card style={{ ...cardContentStyle, backgroundColor: '#99cdfa', transform: isHovered ? 'translateY(-5px)' : 'none' }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardContent>
          <Typography variant="h5" component="h1" style={{ textAlign: 'center', marginBottom: '10px', color: '#333', fontSize: '24px' }}>
            Hospital Details
          </Typography>
          <Typography style={{ textAlign: 'center', marginBottom: '10px', color: '#333', fontSize: '18px' }}>
            Hospital Name: {hospital.HospitalFullName}
          </Typography>
          <Typography style={{ textAlign: 'center', marginBottom: '5px', fontSize: '16px' }}>
            City: {hospital.city}
          </Typography>
          <Typography style={{ textAlign: 'center', marginBottom: '5px', fontSize: '16px' }}>
            Location: {hospital.locality}
          </Typography>
        </CardContent>
      </Card>
    </div>
  );
}

function ClinicCard({ clinic }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div style={cardStyle}>
      <Card
        style={{ ...cardContentStyle, backgroundColor: '#99cdfa', transform: isHovered ? 'translateY(-5px)' : 'none' }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardContent>
          <Typography variant="h5" component="h1" style={{ textAlign: 'center', marginBottom: '10px', color: '#333', fontSize: '24px' }}>
            Clinic Details
          </Typography>
          <Typography style={{ textAlign: 'center', marginBottom: '5px', fontSize: '18px' }}>
            Clinic Name: {clinic.clinic_name}
          </Typography>
          <Typography style={{ textAlign: 'center', marginBottom: '5px', fontSize: '16px' }}>
            City: {clinic.city}
          </Typography>
          <Typography style={{ textAlign: 'center', marginBottom: '5px', fontSize: '16px' }}>
            Location: {clinic.locality}
          </Typography>
        </CardContent>
      </Card>
    </div>
  );
}

const cardStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '50px',
  marginRight: '150px'
};

const cardContentStyle = {
  width: '420px',
  height: '200px',
  borderRadius: '10px',
  transition: 'transform 0.3s ease-in-out',
  boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
};

export default Index;
