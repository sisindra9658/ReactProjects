import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
  TextField,
  IconButton,
  MenuItem,
  Select,
} from "@mui/material";
import SearchIcon from '@mui/icons-material/Search';
import "./patient.css";

const Form = () => {
  const [clinicPatients, setClinicPatients] = useState([]);
  const [hospitalPatients, setHospitalPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [workplaceFilter, setWorkplaceFilter] = useState("All");

  useEffect(() => {
    const fetchData = async () => {
      try {
        let clinicUrl = "";
        let hospitalUrl = "";
        if (workplaceFilter === "All" || workplaceFilter === "Clinic") {
          const username = localStorage.getItem('username'); 
          clinicUrl = `http://localhost:5000/api/doctor-details/appointment/${username}`;
          const clinicResponse = await fetch(clinicUrl);
          if (!clinicResponse.ok) {
            throw new Error(`Failed to fetch Clinic data`);
          }
          const clinicData = await clinicResponse.json();
          setClinicPatients(clinicData);
        }
        if (workplaceFilter === "All" || workplaceFilter === "Hospital") {
          const username = localStorage.getItem('username'); 
          hospitalUrl = `http://localhost:5000/api/doctor-details/appointmentclinic/${username}`;
          const hospitalResponse = await fetch(hospitalUrl);
          if (!hospitalResponse.ok) {
            throw new Error(`Failed to fetch Hospital data`);
          }
          const hospitalData = await hospitalResponse.json();
          setHospitalPatients(hospitalData);
        }
      } catch (error) {
        console.error(error);
      }
    };

    fetchData();
  }, [workplaceFilter]);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleWorkplaceChange = (e) => {
    setWorkplaceFilter(e.target.value);
  };

  const filteredClinicPatients = clinicPatients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredHospitalPatients = hospitalPatients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Box m="20px">
      <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
        <Select
          value={workplaceFilter}
          onChange={handleWorkplaceChange}
          style={{ width: '150px', height: '50px', backgroundColor: 'black' }}
        >
          <MenuItem value="All">Filter through workplace</MenuItem>
          <MenuItem value="Clinic">Clinic</MenuItem>
          <MenuItem value="Hospital">Hospital</MenuItem>
        </Select>
        <TextField
          placeholder="Search by name..."
          value={searchTerm}
          onChange={handleSearch}
          style={{ width: '300px', height: '50px', borderRadius: '10px' }}
          InputProps={{
            startAdornment: (
              <IconButton disabled>
                <SearchIcon />
              </IconButton>
            ),
          }}
        />
      </Box>
      {(workplaceFilter === "All" || workplaceFilter === "Clinic") && (
        <Box mb={2}>
          <TableContainer component={Paper} className="styled-table">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Number</TableCell>
                  <TableCell>Weight</TableCell>
                  <TableCell>Height</TableCell>
                  <TableCell>Temperature</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Workplace</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredClinicPatients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell>{patient.patient_id}</TableCell>
                    <TableCell>{patient.name}</TableCell>
                    <TableCell>{patient.email}</TableCell>
                    <TableCell>{patient.contact}</TableCell>
                    <TableCell>{patient.weight}</TableCell>
                    <TableCell>{patient.height}</TableCell>
                    <TableCell>{patient.temperature}</TableCell>
                    <TableCell>{patient.status}</TableCell>
                    <TableCell>{patient.clinic_name}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}
      {(workplaceFilter === "All" || workplaceFilter === "Hospital") && (
        <Box mt={10}>
          <TableContainer component={Paper} className="styled-table">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Number</TableCell>
                  <TableCell>Weight</TableCell>
                  <TableCell>Height</TableCell>
                  <TableCell>Blood Pressure</TableCell>
                  <TableCell>Temperature</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Workplace</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredHospitalPatients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell>{patient.patient_id}</TableCell>
                    <TableCell>{patient.name}</TableCell>
                    <TableCell>{patient.email}</TableCell>
                    <TableCell>{patient.contact}</TableCell>
                    <TableCell>{patient.weight}</TableCell>
                    <TableCell>{patient.height}</TableCell>
                    <TableCell>{patient.blood_pressure}</TableCell>
                    <TableCell>{patient.temperature}</TableCell>
                    <TableCell>{patient.status}</TableCell>
                    <TableCell>{patient.HospitalFullName}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}
    </Box>
  );
};

export default Form;
