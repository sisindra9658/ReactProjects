import React, { useState, useEffect } from "react";
import axios from "axios";

import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  TextField,
  Select,
  MenuItem,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import "./styles.css";

const Contacts = () => {
  const [contacts, setContacts] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState([]);
  const [openPopup, setOpenPopup] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [filteredContacts, setFilteredContacts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [workplaceFilter, setWorkplaceFilter] = useState("All");
  const [noDataMessage, setNoDataMessage] = useState("");

  const handleOpenPopup = (contact) => {
    setSelectedContact(contact);
    setOpenPopup(true);
  };

  const handleClosePopup = () => {
    setOpenPopup(false);
  };

  // useEffect(() => {
  //   const fetchContacts = async () => {
  //     try {
  //       const response = await axios.get("http://localhost:5000/api/get11", {
  //         params: {
  //           doctorName: "Dr. David Smith", // Change to the desired doctor's name
  //         },
  //       });
  //       setContacts(response.data);
  //     } catch (error) {
  //       console.error("Error fetching contacts:", error);
  //     }
  //   };

  //   const fetchHospitalDetails = async () => {
  //     try {
  //       const response = await axios.get("http://localhost:5000/api/get5", {
  //         params: {
  //           doctorName: "Dr. David Smith", // Change to the desired doctor's name
  //         },
  //       });
  //       setHospitalDetails(response.data);
  //       // Fetch clinic details as well when hospital details are fetched
  //       fetchClinicDetails();
  //     } catch (error) {
  //       console.error("Error fetching hospital details:", error);
  //     }
  //   };

  //   fetchContacts();
  //   fetchHospitalDetails();
  // }, []);

  useEffect(() => {
  
    const fetchContacts = async () => {
      try {
        const username = localStorage.getItem('username'); 
        const response = await axios.get(`http://localhost:5000/api/doctor-details/appointment/${username}`);
        setContacts(response.data);
      } catch (error) {
        console.error('Error fetching managing admin details:', error);
      }
    };  

    const fetchHospitalDetails = async () => {
      try {
        const username = localStorage.getItem('username'); 
        const response = await axios.get(`http://localhost:5000/api/doctor-details/appointmentclinic/${username}`);
        setHospitalDetails(response.data);
      } catch (error) {
        console.error("Error fetching hospital details:", error);
      }
    };

    fetchContacts();
    fetchHospitalDetails();
  }, []);

  useEffect(() => {
    // Merge contacts and hospitalDetails when workplaceFilter is "All"
    let mergedContacts = [];
    if (workplaceFilter === "All") {
      mergedContacts = [...contacts, ...hospitalDetails];
    } else if (workplaceFilter === "Clinic") {
      mergedContacts = contacts;
    } else {
      mergedContacts = hospitalDetails;
    }

    // Filter merged contacts based on search term for name and booking date
    const filtered = mergedContacts.filter((contact) => {
      const nameMatches = contact.name.toLowerCase().includes(searchTerm.toLowerCase());
      const dateMatches = contact.booking_date.includes(searchTerm);
      return nameMatches || dateMatches;
    });

    setFilteredContacts(filtered);

    // Set no data message if no matching contacts found
    if (filtered.length === 0 && searchTerm !== "") {
      setNoDataMessage("No contacts found matching the search term.");
    } else {
      setNoDataMessage("");
    }
  }, [searchTerm, contacts, hospitalDetails, workplaceFilter]);

  const handleWorkplaceChange = (event) => {
    setWorkplaceFilter(event.target.value);
  };

  return (
    <Box m="20px">
      {/* <Header title="APPOINTMENTS" subtitle="List of Appointment " /> */}
      <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
        <Select
          value={workplaceFilter}
          onChange={handleWorkplaceChange}
          style={{ width: "150px", height: "50px", backgroundColor: "black" }}
        >
          <MenuItem value="All">Filter through workplace</MenuItem>
          <MenuItem value="Clinic">Clinic</MenuItem>
          <MenuItem value="Hospital">Hospital</MenuItem>
        </Select>
        <TextField
          style={{ width: "300px", height: "50px", backgroundColor: "#637E76", borderRadius: "10px" }}
          placeholder="Search through name/booking date...."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            endAdornment: (
              <IconButton>
                <SearchIcon />
              </IconButton>
            ),
          }}
        />
      </Box>
      {noDataMessage && <div>{noDataMessage}</div>}
      {filteredContacts.length > 0 && (
        <table className="doctorstyled-table">
          <thead>
            <tr>
              <th>Id.</th>
              <th>FullName</th>
              <th>Booking date</th>
              <th>Slot Timing</th>
              <th>Doctor name</th>
              <th>Consultation fee</th>
              <th>Payment mode</th>
              <th>Workspace</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredContacts.map((contact) => (
              <tr key={contact.patient_id}>
                <td>{contact.patient_id}</td>
                <td>{contact.name}</td>
                <td>{contact.booking_date}</td>
                <td>{contact.slot_time}</td>
                <td>{contact.doctor_name}</td>
                <td>{contact.consultation_fee}</td>
                <td>{contact.paymentMode}</td>
                <td>{contact.clinic_name}</td>
                <td>{contact.status}</td>
                <td>
                  <button className="doctorbtn doctorbtn-edit" onClick={() => handleOpenPopup(contact)}>
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <Dialog open={openPopup} onClose={handleClosePopup} style={{ color: "#333" }}>
        <DialogTitle>More Details</DialogTitle>
        <DialogContent>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Mobile:</strong>
            {selectedContact && selectedContact.contact}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Email:</strong>
            {selectedContact && selectedContact.email}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Height:</strong>
            {selectedContact && selectedContact.height}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Weight:</strong>
            {selectedContact && selectedContact.weight}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Temperature:</strong>
            {selectedContact && selectedContact.temperature}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Blood Pressure:</strong>
            {selectedContact && selectedContact.blood_pressure}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Clinic Name:</strong>
            {selectedContact && selectedContact.clinic_name}
          </div>
          <div style={{ marginBottom: "10px" }}>
            <strong style={{ marginRight: "10px" }}>Clinic Address:</strong>
            {selectedContact && selectedContact.clinic_address}
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClosePopup} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Contacts;
