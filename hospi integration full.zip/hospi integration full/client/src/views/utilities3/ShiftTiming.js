import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './calendar.css';
import { Select, MenuItem } from '@mui/material';
 
function Calendar() {
  const [clinicTimings, setClinicTimings] = useState([]);
  const [clinicDetails, setClinicDetails] = useState(null);
  const [hospitalTimings, setHospitalTimings] = useState([]);
  const [opTimings, setOpTimings] = useState([]);
  const [currentTable, setCurrentTable] = useState('clinic');
  const [clinicSubTable, setClinicSubTable] = useState('shift');
  const [hospitalSubTable, setHospitalSubTable] = useState('shift');
 
  // useEffect(() => {
  //   if (currentTable === 'clinic') {
  //     fetchClinicDetails();
  //   } else if (currentTable === 'hospital') {
  //     fetchHospitalTimings();
  //   }
  // }, [currentTable]);
 
  // const fetchClinicDetails = async () => {
  //   try {
  //     const username = localStorage.getItem('username'); 
  //     const clinicDetailsResponse = await axios.get(`http://localhost:5000/api/doctor-details/shifttiming/${username}`);
  //     setClinicDetails(clinicDetailsResponse.data[0]);
  //     fetchClinicTimings();
  //     fetchClinicOpTimings();
  //   } catch (error) {
  //     console.error('Error fetching clinic details:', error);
  //   }
  // };
 
  // const fetchClinicTimings = async () => {
  //   try {
  //     const username = localStorage.getItem('username'); 
  //     const clinicTimingsResponse = await axios.get(`http://localhost:5000/api/doctor-details/shift1/${username}`);
  //     setClinicTimings(clinicTimingsResponse.data);
  //   } catch (error) {
  //     console.error('Error fetching clinic timings:', error);
  //   }
  // };

  useEffect(() => {
    if (currentTable === 'clinic') {
      fetchClinicData();
    } else if (currentTable === 'hospital') {
      fetchHospitalTimings();
      fetchHospitalTimings();
    }
  }, [currentTable]);
  


  const fetchClinicData = async () => {
    try {
      const username = localStorage.getItem('username');
      
      // Fetch clinic details
      const clinicDetailsResponse = await axios.get(`http://localhost:5000/api/doctor-details/shifttiming/${username}`);
      setClinicDetails(clinicDetailsResponse.data[0]);
      
      // Fetch clinic timings
      const clinicTimingsResponse = await axios.get(`http://localhost:5000/api/doctor-details/shift1/${username}`);
      setClinicTimings(clinicTimingsResponse.data);
      
      // Fetch clinic OP timings if needed
      fetchClinicOpTimings();
    } catch (error) {
      console.error('Error fetching clinic data:', error);
    }
  };
  
 
  const fetchHospitalTimings = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const hospitalTimingsResponse = await axios.get(`http://localhost:5000/api/doctor-details/appointmentclinic/${username}`);
      setHospitalTimings(hospitalTimingsResponse.data);
    } catch (error) {
      console.error('Error fetching hospital timings:', error);
    }
  };
 
  const fetchClinicOpTimings = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const opTimingsResponse = await axios.get(`http://localhost:5000/api/doctor-details/shifttime/${username}`);
      setOpTimings(opTimingsResponse.data);
    } catch (error) {
      console.error('Error fetching clinic OP timings:', error);
    }
  };
 
  const handleTableChange = (event) => {
    setCurrentTable(event.target.value);
  };
 
  const handleClinicSubTableChange = (event) => {
    setClinicSubTable(event.target.value);
  };
 
  const handleHospitalSubTableChange = (event) => {
    setHospitalSubTable(event.target.value);
  };
  const calculateTimeDuration = (startTime, endTime) => {
        const start = new Date(`2022-01-01T${startTime}`);
        const end = new Date(`2022-01-01T${endTime}`);
       
        const timeDiff = end - start;
   
        const hours = Math.floor(timeDiff / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
   
        return `${hours} hours ${minutes} minutes`;
      };
   
  return (
    <div className="doctorcalendar-container">
      <h2 style={{ color: 'black' }}>Shift Timings</h2>
      <Select
        value={currentTable}
        onChange={handleTableChange}
        style={{ width:'150px', height:'50px', marginBottom: '20px', backgroundColor:'black'}}
      >
        <MenuItem value="clinic">Clinic</MenuItem>
        <MenuItem value="hospital">Hospital</MenuItem>
      </Select>
 
      {currentTable === 'clinic' && (
        <Select
          value={clinicSubTable}
          onChange={handleClinicSubTableChange}
          style={{ width:'150px', height:'50px', marginBottom: '20px', backgroundColor:'black'}}
        >
          <MenuItem value="shift">Shift Timing</MenuItem>
          <MenuItem value="op">OP Timing</MenuItem>
        </Select>
      )}
 
      {currentTable === 'hospital' && (
        <Select
          value={hospitalSubTable}
          onChange={handleHospitalSubTableChange}
          style={{ width:'150px', height:'50px', marginBottom: '20px', backgroundColor:'black'}}
        >
          <MenuItem value="shift">Hospital Shift Timing</MenuItem>
          <MenuItem value="op">Hospital OP Timing</MenuItem>
        </Select>
      )}
 
      {currentTable === 'clinic' && clinicDetails && clinicSubTable === 'shift' && (
        <div>
          <h3 style={{ color: 'black' }}>Clinic Shift Timings</h3>
          <table className="doctorcalendar-table">
            <thead>
              <tr>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Clinic name</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Start Time</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>End Time</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Time Duration</th>
              </tr>
            </thead>
            <tbody>
              {clinicTimings.map((timing, index) => (
                <tr key={index}>
                  <td>{clinicDetails.clinic_name}</td>
                  <td>{timing.shift_start_time}</td>
                  <td>{timing.shift_end_time}</td>
                  <td>{calculateTimeDuration(timing.shift_start_time, timing.shift_end_time)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
 
      {currentTable === 'hospital' && hospitalSubTable === 'shift' && (
        <div>
          <h3 style={{ color: 'black' }}>Hospital Shift Timings</h3>
          <table className="doctorcalendar-table">
            <thead>
              <tr>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Hospital</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Day</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Start Time</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>End Time</th>
              </tr>
            </thead>
            <tbody>
              {opTimings.map((timing, index) => (
                <tr key={index}>
                  <td>{hospitalTimings.HospitalFullName}</td>
                  <td>{timing.days}</td>
                  <td>{timing.from_time}</td>
                  <td>{timing.to_time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
 {currentTable === 'clinic' && clinicSubTable === 'op' && (
        <div>
          <h3 style={{ color: 'black' }}>Clinic OP Timings</h3>
          <table className="doctorcalendar-table">
            <thead>
              <tr>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Day</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Start Time</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>End Time</th>
              </tr>
            </thead>
            <tbody>
              {opTimings.map((timing, index) => (
                <tr key={index}>
                  <td>{timing.days}</td>
                  <td>{timing.from_time}</td>
                  <td>{timing.to_time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
 
      {currentTable === 'hospital' && hospitalSubTable === 'op' && (
        <div>
          <h3 style={{ color: 'black' }}>Hospital OP Timings</h3>
          <table className="doctorcalendar-table">
            <thead>
              <tr>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Day</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>Start Time</th>
                <th style={{ backgroundColor: '#131313', color: '#ffffff' }}>End Time</th>
              </tr>
            </thead>
            <tbody>
              {opTimings.map((timing, index) => (
                <tr key={index}>
                  <td>{timing.days}</td>
                  <td>{timing.from_time}</td>
                  <td>{timing.to_time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
 
    </div>
  );
}
 
export default Calendar;
 
 
 
 