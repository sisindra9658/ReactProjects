import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const UserDashboard = () => {
  const { username } = useParams(); // Extract userId from route parameters
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:5002/api/userdetails/${username}`);
        setUserData(response.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserDetails();
  }, [username]);

  return (
    <div>
      <h2>Welcome to User Dashboard</h2>
      {userData && (
        <div>
          <p>User ID: {userData.adminID}</p>
          <p>Username: {userData.username}</p>
          <p>Additional Field 1: {userData.additional_field_1}</p>
          <p>Additional Field 2: {userData.additional_field_2}</p>
          <p>Additional Field 3: {userData.additional_field_3}</p>
          <p>Additional Field 4: {userData.additional_field_4}</p>
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
