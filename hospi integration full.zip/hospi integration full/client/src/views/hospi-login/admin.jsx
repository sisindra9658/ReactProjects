import React from 'react';
import { useLocation } from 'react-router-dom';

const Admin = () => {
  const location = useLocation();
  const username = location.state ? location.state.username : 'Guest';

  return (
    <div>
      <h2>Welcome, {username}!</h2>
      {/* Add admin-specific content here */}
    </div>
  );
};

export default Admin;
