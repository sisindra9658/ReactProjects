// StudentPage.js
import React from 'react';

export const Student = () => {
  return (
    <div>
      <h2>Welcome to the Student Page!</h2>
      <h2>Hello upi</h2>
      {/* Add student-specific content here */}
    </div>
  );
};

 