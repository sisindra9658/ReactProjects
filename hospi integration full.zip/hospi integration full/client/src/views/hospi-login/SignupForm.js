import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import './signup.css';
import Grid from '@mui/material/Grid';

export const SignupForm = () => {
  const [username, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [Primary_name, setPrimary_name] = useState('');
  const [Secondary_name, setSecondary_name] = useState('');
  const [managing_admin, setManaging_admin] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [contact_number, setContact_number] = useState('');
  const [role, setRole] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [contactNumberError, setContactNumberError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  const navigate = useNavigate();

  const isUsernameEmailFilled = username.trim() !== '' && email.trim() !== '';

  const emailRegex = /^[^\s@]+@[^\s@]+\.[gmail.com]+$/;
  const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  const contactNumberRegex = /^\d{10}$/;

  const handleSendOTP = async (e) => {
    e.preventDefault();

    if (!isUsernameEmailFilled) {
      toast.error('Username and email are required.');
      return;
    }

    if (!emailRegex.test(email)) {
      setEmailError('Invalid email format.');
      return;
    } else {
      setEmailError('');
    }

    try {
      const response = await axios.post('http://localhost:5000/send-otp', { email });
      console.log(response.data);
      setOtpSent(true);
      setVerificationStatus('OTP sent successfully. Please check your email.');
    } catch (error) {
      console.error(error);
      setVerificationStatus('Failed to send OTP. Please try again.');
    }
  };

  const handleSubmits = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/verify-otp', { email, otp });
      setVerificationStatus(response.data.message);
      if (response.data.message === 'OTP verified successfully') {
        // Allow user to fill in other fields
        setOtpSent(false);
      }
    } catch (error) {
      console.error(error);
      setVerificationStatus('Failed to verify OTP. Please try again.');
    }
  };

  const signupUser = async (e) => {
    e.preventDefault();

    if (!passwordRegex.test(password)) {
      setPasswordError('Password must be at least 8 characters long, include an uppercase letter, a number, and a special character.');
      return;
    } else {
      setPasswordError('');
    }

    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match.');
      return;
    } else {
      setConfirmPasswordError('');
    }

    if (!contactNumberRegex.test(contact_number)) {
      setContactNumberError('Contact number must be 10 digits.');
      return;
    } else {
      setContactNumberError('');
    }

    try {
      const response = await axios.post('http://localhost:5000/users', {
        username,
        password,
        Primary_name,
        Secondary_name,
        email,
        role,
        contact_number,
        managing_admin,
      });
      if (response.status === 201) {
        toast.success('Signup successful!');
        navigate('/');
      } else {
        toast.error('Signup failed. Please try again later.');
      }
    } catch (error) {
      console.error('Error during signup:', error);
      toast.error('Signup failed. Please try again later.');
    }
  };

  return (
    <div className="signup-container">
      <div className="signup-form" style={{ border: '1px solid #ccc', borderRadius: '8px' }}>
        <h2>Signup</h2>
        <form>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <label>
                User Name:
                <input type="text" placeholder='User Name' value={username} onChange={(e) => setUserName(e.target.value)} required />
              </label>
            </Grid>
            <Grid item xs={12} sm={6}>
              <label>
                Email:
                <input type="text" placeholder='Email' value={email} onChange={(e) => setEmail(e.target.value)} required />
              </label>
              {emailError && <p className="error">{emailError}</p>}
            </Grid>

            {otpSent ? (
              <>
                <Grid item xs={12} sm={6}>
                  <label>
                    <input type="text" value={otp} placeholder='Enter OTP' onChange={(e) => setOtp(e.target.value)} />
                  </label>
                </Grid>
                <Grid item xs={12} sm={6} style={{ display: 'flex', justifyContent: 'center' }}>
                  <button style={{ marginTop: '15px', display: 'flex', justifyContent: 'center' }} onClick={handleSubmits}>Verify OTP</button>
                </Grid>
              </>
            ) : (
              <button style={{ marginLeft: '5%' }} onClick={handleSendOTP}>Get OTP for Email</button>
            )}
            <Grid item xs={12} sm={12}>
              {verificationStatus && <p>{verificationStatus}</p>}
            </Grid>

            {!otpSent && verificationStatus === 'OTP verified successfully' && (
              <>
                <Grid item xs={12} sm={6}>
                  <label>
                    Password:
                    <input type="password" placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} />
                  </label>
                  {passwordError && <p className="error">{passwordError}</p>}
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label>
                    Confirm Password:
                    <input type="password" placeholder='Confirm Password' value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                  </label>
                  {confirmPasswordError && <p className="error">{confirmPasswordError}</p>}
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label>
                    Contact Number:
                    <input type="text" placeholder='Contact Number' value={contact_number} onChange={(e) => setContact_number(e.target.value)} />
                  </label>
                  {contactNumberError && <p className="error">{contactNumberError}</p>}
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label>
                    Primary Name:
                    <input type="text" placeholder='Primary Name' value={Primary_name} onChange={(e) => setPrimary_name(e.target.value)} />
                  </label>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label>
                    Secondary Name:
                    <input type="text" placeholder='Secondary Name' value={Secondary_name} onChange={(e) => setSecondary_name(e.target.value)} />
                  </label>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label>
                    Admin Name:
                    <input type="text" placeholder='Admin Name' value={managing_admin} onChange={(e) => setManaging_admin(e.target.value)} />
                  </label>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      style={{ width: '100%' }}
                    >
                      <option value="">Select Role</option>
                      <option value="Hospital Admin">Hospital Admin</option>
                      <option value="Doctor Admin">Doctor Admin</option>
                      <option value="Clinic Admin">Clinic Admin</option>
                      <option value="Diagnostic Admin">Diagnostic Admin</option>
                      <option value="Ambulance Admin">Ambulance Admin</option>
                      <option value="Super Admin">Super Admin</option>
                      <option value="user">User</option>
                    </select>
                  </label>
                </Grid>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop: '30%' }}>
                  <button onClick={signupUser}>Signup</button>
                </div>
              </>
            )}
          </Grid>
        </form>
      </div>
    </div>
  );
};

export default SignupForm;
