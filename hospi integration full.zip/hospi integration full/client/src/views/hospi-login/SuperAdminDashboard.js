// In your SuperAdminDashboard component
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const SuperAdminDashboard = () => {
  const { userId } = useParams(); // Extract userId from route parameters
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchSuperAdminUserDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:5002/api/superadminuserdetails/${userId}`);
        setUserData(response.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchSuperAdminUserDetails();
  }, [userId]);

  return (
    <div>
      <h2>Welcome to Super Admin Dashboard</h2>
      {userData && (
        <div>
          <p>Super Admin ID: {userData.adminID}</p>
          <p>Username: {userData.username}</p>
          <p>Email: {userData.email}</p>
          <p>Phone Number: {userData.contact_number}</p>
        </div>
      )}
    </div>
  );
};

export default SuperAdminDashboard;
