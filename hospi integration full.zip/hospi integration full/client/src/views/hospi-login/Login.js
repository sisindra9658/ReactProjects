import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom'; // Import Link and useNavigate
import { toast } from 'react-toastify';

import './Loginm.css';

export const Login = () => {
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.get('http://localhost:5002/api/users');
      const users = response.data;

      const user = users.find(user => user.username === loginUsername && user.password === loginPassword);
      if (user) {
        const role = user.role;
        const userId = user.user_id;

        alert(`Welcome, ${loginUsername}!`);

        switch (role) {
          case 'Super Admin':
            navigate(`/api/superadminuserdetails/${userId}`);
            break;
          case 'admin':
            navigate(`/api/adminuserdetails/${userId}`);
            break;
          default:
            navigate(`/api/userdetails/${userId}`);
            break;
        }
      } else {
        toast.error('Invalid credentials');
      }
    } catch (error) {
      console.error('Error during login:', error);
    }
  };

  return (
    <div className="form-login">
      <div className="login-form">
        <h2 className="lead">Login Form</h2>
        <input type="text" placeholder="Username" value={loginUsername} onChange={(e) => setLoginUsername(e.target.value)} />
        <br />
        <input type="password" placeholder="Password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} />
        <br />
        <button id="dot" onClick={handleLogin}>Login</button>
        <br />
        {/* Add Link to Signup page */}
        <div style={{display:'flex', justifyContent:'space-around'}}>
        <Link to="/SignupFrom" className="signup-link">Signup</Link>
        <Link to="/Sign" className="signup-link">forget Password</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
