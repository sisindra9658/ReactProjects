import React, { useState } from 'react';
import { FaUser } from 'react-icons/fa'; // Importing Font Awesome user icon
import './login.css';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom'; // Import Link and useNavigate
import { toast } from 'react-toastify';

export const Login = () => {

  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.get('http://localhost:5002/api/users');
      const users = response.data;

      const user = users.find(user => user.username === loginUsername && user.password === loginPassword);
      if (user) {
        const role = user.role;
        const userId = user.user_id;
        console.log('User ID:', userId);
        console.log('Role:', role);


        alert(`Welcome, ${loginUsername}!`);

        switch (role) {
          case 'Super Admin':
            navigate(`/api/superadminuserdetails/${userId}`);
            break;
          case 'admin':
            navigate(`/api/adminuserdetails/${userId}`);
            break;
          default:
            navigate(`/api/userdetails/${userId}`);
            break;
        }
      } else {
        toast.error('Invalid credentials');
      }
    } catch (error) {
      console.error('Error during login:', error);
    }
  };
  return (
    <div className="wrapper">
      <form>
        <div className="icon" >
          <FaUser className="user-icon"/>
        </div>
        <p className="form-login">Login</p>
        <div className="input-box">
        <input type="text" placeholder="User Name" value={loginUsername} onChange={(e) => setLoginUsername(e.target.value)} />
        </div>
        <div className="input-box">
        <input type="password" placeholder="Password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} />
        </div>
        <div className="remember-forgot">
          {/* <label><input type="checkbox" />Remember Me</label> */}
          <Link to="" className="signup-link">forget Password</Link>
        </div>
        <button className="btn" onClick={handleLogin}>Login</button>
        <div className="register-link">
          <p>Dont have an account? <Link to="/SignupFrom" >Register</Link></p>
        </div>
      </form>
    </div>
  );
}
 
export default Login;
 