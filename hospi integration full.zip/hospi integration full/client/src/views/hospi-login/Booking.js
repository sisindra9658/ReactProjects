import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Booking.css'

const Booking = () => {
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [availableSlots, setAvailableSlots] = useState([]);
  const [patientName, setPatientName] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    // Fetch list of doctors when component mounts
    axios.get('http://localhost:5000/doctors')
      .then(response => {
        const doctorsData = response.data;
        setDoctors(doctorsData);
      })
      .catch(error => {
        console.error('Error fetching doctors', error);
      });
  }, []);

  const handlePatientNameChange = (e) => {
    setPatientName(e.target.value);
  };

  const handleDoctorChange = (e) => {
    setSelectedDoctor(e.target.value);
    setSelectedDate(''); // Reset selected date when doctor changes
    setMessage(''); // Reset message when doctor changes
    setAvailableSlots([]); // Reset available slots when doctor changes
  };

  const handleDateChange = (e) => {
    setSelectedDate(e.target.value);
    setMessage(''); // Reset message when date changes
    setSelectedSlot(''); // Reset selected slot when date changes

    // Fetch available slots for selected doctor and date
    fetchAvailableSlots(selectedDoctor, e.target.value);
  };

  const handleSlotSelection = (slot) => {
    setSelectedSlot(slot);
  };

  const handleBookAppointment = () => {
    if (!selectedDoctor || !selectedDate || !patientName || !selectedSlot) {
      setMessage('Please fill in all fields');
      return;
    }

    // Check if the selected slot is available
    if (!availableSlots.includes(selectedSlot)) {
      setMessage('Selected slot is not available');
      return;
    }

    // Proceed with booking the appointment
    axios.post('http://localhost:5000/bookings', {
      doctorId: selectedDoctor,
      patientName: patientName,
      bookingDate: selectedDate,
      bookingTime: selectedSlot
    })
    .then(response => {
      setMessage('Appointment booked successfully');
      // Update available slots after booking
      fetchAvailableSlots(selectedDoctor, selectedDate);
    })
    .catch(error => {
      console.error('Error booking appointment', error);
      setMessage('Error booking appointment');
    });
  };

  const fetchAvailableSlots = (doctorId, date) => {
    axios.get(`http://localhost:5000/slots?doctorId=${doctorId}&date=${date}`)
      .then(response => {
        const slots = response.data;
        setAvailableSlots(slots);
        if (slots.length === 0) {
          setMessage(`No available slots for ${date}.`);
        } else {
          setMessage('');
        }
      })
      .catch(error => {
        console.error('Error fetching available slots', error);
        setMessage('Error fetching available slots');
      });
  };

  return (
    <div className='container'>
      <div className='d-flex flex-column gap-4 mb-3 mt-3'>
        <input type='text' placeholder='Your Name' onChange={handlePatientNameChange} />
        <select onChange={handleDoctorChange}>
          <option value="">Select Doctor</option>
          {doctors.map(doctor => (
            <option key={doctor.doctor_id} value={doctor.doctor_id}>{doctor.doctor_name}</option>
          ))}
        </select>
        {selectedDoctor && (
          <input type='date' onChange={handleDateChange} />
        )}
        <div>
          <h3>Available Slots</h3>
          {availableSlots.map(slot => (
            <div key={slot} className={selectedSlot === slot ? 'selected-slot' : 'available-slot'} onClick={() => handleSlotSelection(slot)}>
              <p>{slot}</p>
            </div>
          ))}
          {message && <p>{message}</p>}
          <button onClick={handleBookAppointment}>Book Now</button>
        </div>
      </div>
    </div>
  );
};

export default Booking;