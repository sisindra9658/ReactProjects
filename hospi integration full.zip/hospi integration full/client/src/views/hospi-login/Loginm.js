import React, {useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
// import { toast } from 'react-toastify';
import { FaUser, FaEye, FaEyeSlash } from 'react-icons/fa'; // Import eye icons
import { useUser } from '.././context/Usercontext'; 

import './Loginm.css';

export const Login = () => {
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showPassword, setShowPassword] = useState(false); 
  const navigate = useNavigate();
  const { fetchUserDataByUsername } = useUser();
  const [setManagingAdminDetails] = useState(null);

  // const dispatch = useDispatch(); // Redux dispatch function


  // const handleLogin = async () => {
  //   try {
  //     const response = await axios.post('http://localhost:5000/api/login', {
  //       username: loginUsername,
  //       password: loginPassword
  //     });

  //     const { token, user } = response.data;

  //     if (token) {
  //       localStorage.setItem('token', token);
  //       // Redirect to dashboard or profile page based on user role
  //       navigateToDashboard(user.role, user.adminID);
  //     } else {
  //       setLoginError('Invalid credentials');
  //     }
  //   } catch (error) {
  //     console.error('Error during login:', error);
  //     setLoginError('Username or password incorrect. Please check once.');
  //   }
  // };


  useEffect(() => {
    const storedUsername = localStorage.getItem('rememberedUsername');
    const storedPassword = localStorage.getItem('rememberedPassword');
    const storedPasswordExpiration = localStorage.getItem('rememberedPasswordExpiration');

    if (storedUsername && storedPassword && storedPasswordExpiration) {
      const expirationDate = new Date(storedPasswordExpiration);
      const now = new Date();

      if (now < expirationDate) {
        setLoginUsername(storedUsername);
        setLoginPassword(storedPassword);
      } else {
        localStorage.removeItem('rememberedUsername');
        localStorage.removeItem('rememberedPassword');
        localStorage.removeItem('rememberedPasswordExpiration');
      }
    }
  }, []);



  const handleLogin = async () => {
    try {
      const loginTime = new Date().toLocaleString(); // Get current time in a human-readable format
      const sessionDuration = calculateSessionDuration(); // Calculate session duration
      localStorage.setItem('sessionStart', new Date().getTime()); // Store session start time
      // const loginTime = new Date().toISOString(); // Get current time in ISO format
      const response = await axios.post('http://localhost:5000/api/login', { username: loginUsername, password: loginPassword, loginTime: loginTime, sessionDuration: sessionDuration  });
      const user = response.data;

      if (user) {
        const role = user.role;
        const userId = user.adminID; // Assuming the user ID is stored in the 'adminID' property
        alert(`Welcome, ${loginUsername}!`);
        fetchUserDataByUsername(loginUsername);
        const rememberMeCheckbox = document.getElementById('rememberMeCheckbox');
        if (rememberMeCheckbox.checked) {
          const expirationDate = new Date();
          expirationDate.setDate(expirationDate.getDate() + 7); // Set expiration date to 7 days from now
          localStorage.setItem('rememberedUsername', loginUsername);
          localStorage.setItem('rememberedPassword', loginPassword);
          localStorage.setItem('rememberedPasswordExpiration', expirationDate);
        } else {
          localStorage.removeItem('rememberedUsername');
          localStorage.removeItem('rememberedPassword');
          localStorage.removeItem('rememberedPasswordExpiration');
        }


        // toast.success(`Welcome, ${loginUsername}!`);
        // dispatch(setUser(loginUsername));
        // handleLoginSuccess(loginUsername); // Pass the username to the parent component
        // navigate(`/dashboard?${loginUsername}`);
        // const username = 'sisindra'; 
        // sessionStorage.setItem('loggedInUsername', username);
        // dispatch(setUser(username)); // Set the user in Redux store
        // const username = user.username;
        // console.log('Login username:', username); // Add this line
        // sessionStorage.setItem('username', user.username);
        // console.log('Login username:', user.username); // Add this line
        localStorage.setItem('username', loginUsername);
        console.log('Username stored in localStorage:', loginUsername); // Add this console log
        // localStorage.setItem('loggedInUsername', loginUsername);
        // console.log('loggedInUsername'); // Add this line
        localStorage.setItem('loginTime', new Date().getTime());
        localStorage.setItem('sessionDuration', calculateSessionDuration());
        localStorage.setItem('userData', JSON.stringify(user));
        // Store session duration
        // const loginTime = new Date().getTime(); // Get current time in milliseconds
        // localStorage.setItem('loginTime', loginTime);
        // const sessionDuration = calculateSessionDuration(); // Calculate session duration
        // localStorage.setItem('sessionDuration', sessionDuration); // Store 

        // navigate(`/dashboard`, { state: { username } });
        axios.get(`http://localhost:5000/api/hospital-details/${loginUsername}`)
        .then(res => {
            console.log('Managing Admin Details:', res.data);
            setManagingAdminDetails(res.data);
        })
        .catch(err => {
            console.error('Error fetching managing admin details:', err);
        });


        switch (role) {
          case 'Super Admin':
            navigate(`/api/superadminuserdetails/${userId}`);
            break;
            case 'Hospital Admin':
              navigate(`/api/adminuserdetails/${userId}`);
              break;
            case 'Doctor Admin':
              navigate(`/api/adminuserdetails/${userId}`);
              break;
            case 'Clinic Admin':
              navigate(`/api/adminuserdetails/${userId}`);
              break;
            case 'Diagnostic Admin':
              navigate(`/api/adminuserdetails/${userId}`);
              break;
            case 'Ambulance Admin':
              navigate(`/api/adminuserdetails/${userId}`);
              break;
          default:
            navigate(`/api/userdetails/${userId}`);
            break;
        }

        navigateToDashboard(role);
      } else {
        setLoginError('Invalid credentials');
      }
    } catch (error) {
      console.error('Error during login:', error);
      setLoginError('UserName OR Password Incorrect. Please check once..');

    }
  };
    
  const navigateToDashboard = (role) => {
    switch (role) {
      case 'Super Admin':
        // Redirect to Super Admin Dashboard
        window.location.replace('http://localhost:3000/SuperAdmin');
        break;
      case 'Hospital Admin':
        // Redirect to Admin Dashboard
        window.location.replace('http://localhost:3000/Admin');
        break;
        case 'Clinic Admin':
          // Redirect to Admin Dashboard
          window.location.replace('http://localhost:3000/Admin');
          break;
          case 'Ambulance Admin':
            // Redirect to Admin Dashboard
            window.location.replace('http://localhost:3000/Admin');
            break;
            case 'Diagnostic Admin':
              // Redirect to Admin Dashboard
              window.location.replace('http://localhost:3000/Admin');
              break;
              case 'Doctor Admin':
                // Redirect to Admin Dashboard
                window.location.replace('http://localhost:3000/Doctor');
                break;
      default:
        // Redirect to User Dashboard
        window.location.replace('http://localhost:3000/User');
        break;
    }
  };

  const calculateSessionDuration = () => {
    const sessionStart = localStorage.getItem('sessionStart');
    if (sessionStart) {
      const currentTime = new Date().getTime();
      const sessionDuration = (currentTime - parseInt(sessionStart)) / (1000 * 60); // Convert milliseconds to minutes
      return sessionDuration.toFixed(2);
    }
    return 0;
  };

  // const calculateSessionDuration = () => {
  //   const loginTime = localStorage.getItem('loginTime');
  //   const storedSessionDuration = localStorage.getItem('sessionDuration'); // Retrieve stored session duration
  //   if (loginTime && storedSessionDuration) {
  //     const currentTime = new Date().getTime();
  //     const sessionDuration = (currentTime - parseInt(loginTime)) / (1000 * 60); // Convert milliseconds to minutes
  //     return sessionDuration.toFixed(2); // Return session duration in minutes with 2 decimal places
  //   }
  //   return 0;
  // };

  // const calculateSessionDuration = () => {
  //   const loginTime = localStorage.getItem('loginTime');
  //   const storedSessionDuration = localStorage.getItem('sessionDuration'); // Retrieve stored session duration
  //   console.log('Login time:', loginTime);
  //   console.log('Stored session duration:', storedSessionDuration);
  //   if (loginTime && storedSessionDuration) {
  //     // Parse the stored session duration to a float
  //     const sessionDuration = parseFloat(storedSessionDuration);
  //     console.log('Parsed session duration:', sessionDuration);
  //     return sessionDuration.toFixed(2); // Return session duration in minutes with 2 decimal places
  //   }
  //   return 0;
  // };
  
  

  

  return (
    <div className="form-login">
      <div className="login-form">
        <div className="icon-container">
          <FaUser className="user-icon"/>
        </div>
        <h2 className="lead">Login</h2>
        <div className="logininput-box">
          <input type="text" className="logininput" placeholder="Username" value={loginUsername} onChange={(e) => setLoginUsername(e.target.value)} />
        </div>
        <div className="logininput-box">
          <input className="logininput" type={showPassword ? 'text' : 'password'} placeholder="Password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} />
          <label className="password-icon" style={{color:'black'}} >
            {showPassword ? <FaEyeSlash onClick={() => setShowPassword(false)} /> : <FaEye onClick={() => setShowPassword(true)} />}
          </label>
        </div>
        {loginError && <p className="error-message">{loginError}</p>}
        <div className="remember-forgot">
          <label style={{color:'black'}}><input type="checkbox" id="rememberMeCheckbox" />Remember Me</label>
          {/* <Link to="/ForgotPassword" className="signup-link">Forget Password</Link> */}
          <Link to="/ForgotPassword" className="signup-link">Forget Password</Link>

        </div>
        <button className="btn" onClick={handleLogin}>Login</button>
        <br />
        <div className="register-link">
          {/* <p>Dont have an account? <Link to="/SignupFrom">Register</Link></p> */}
          <p>Dont have an account? <Link to="/SignupFrom">Register</Link></p>

        </div>
        <div>
          Session Duration: {calculateSessionDuration()} minutes
        </div>

      </div>
    </div>
  );
};

export default Login;
