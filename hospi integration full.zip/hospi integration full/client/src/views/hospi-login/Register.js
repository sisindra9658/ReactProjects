import React from 'react';
// import './register.css';

 const Register = () => {
  return (
    <div>
        This is Register Page
       <a href='/login'> To Login </a> 
    </div>
  )
 }

 export default Register