// ParentPage.js
import React from 'react';

export const Parent = () => {
  return (
    <div>
      <h2>Welcome to the Parent Page!</h2>
      {/* Add parent-specific content here */}
    </div>
  );
};

