// TeacherPage.js
import React from 'react';

export const Teacher = () => {
  return (
    <div>
      <h2>Welcome to the Teacher Page!</h2>
      {/* Add teacher-specific content here */}
    </div>
  );
};

