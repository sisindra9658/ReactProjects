import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const AdminUserDetails = () => {
  const [adminUserDetails, setAdminUserDetails] = useState(null);
  const { userId } = useParams();

  useEffect(() => {
    console.log("UserID:", userId); // Add this line to check the value of userId
    const fetchAdminUserDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:5002/api/adminuserdetails/${userId}`);
        setAdminUserDetails(response.data);
      } catch (error) {
        console.error('Error fetching admin user details:', error);
      }
    };

    fetchAdminUserDetails();
  }, [userId]);

  return (
    <div>
      <h2>Admin User Details</h2>
      {adminUserDetails && (
        <div>
          <p>Admin ID: {adminUserDetails.adminID}</p>
          <p>Username: {adminUserDetails.username}</p>
          <p>phone Number: {adminUserDetails.contact_number}</p>
          <p>Email: {adminUserDetails.email}</p>
        </div>
      )}
    </div>
  );
};

export default AdminUserDetails;
