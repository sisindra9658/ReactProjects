import { useEffect, useState } from 'react';
import { Grid } from '@mui/material';
import { gridSpacing } from 'store/constant';
import React from 'react';
import { styled, useTheme } from '@mui/material/styles';
import { Avatar, Box, Typography } from '@mui/material';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import SkeletonEarningCard from 'ui-component/cards/Skeleton/EarningCard';
import ApartmentIcon from '@mui/icons-material/Apartment';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import MinorCrashIcon from '@mui/icons-material/MinorCrash';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import { FaUserMd } from 'react-icons/fa';
import { FaFlask } from 'react-icons/fa';
import { FaUserCog } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom'; // Import useNavigate



const CardWrapper = styled(MainCard)(({ theme }) => ({
  backgroundColor: '#4edcd8',
  color: '#fff',
  overflow: 'hidden',
  position: 'relative',
  '&:after': {
    content: '""',
    position: 'absolute',
    width: 210,
    height: 210,
    background: '#4edcd8',
    borderRadius: '50%',
    top: -85,
    right: -95,
    [theme.breakpoints.down('sm')]: {
      top: -105,
      right: -140
    }
  },
  '&:before': {
    content: '""',
    position: 'absolute',
    width: 210,
    height: 210,
    background: '#4edcd8',
    borderRadius: '50%',
    top: -125,
    right: -15,
    opacity: 0.5,
    [theme.breakpoints.down('sm')]: {
      top: -155,
      right: -70
    }
  },
  width: '100%',
}));

const Dashboard = () => {
  const theme = useTheme();
  const navigate = useNavigate();

  const [isLoading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(false);
  }, []);
   
    const handleHospitals = () => {
      navigate('../../SuperAdmin/util-Hospitals');
    };
    const handleClinics = () => {
      navigate('../../SuperAdmin/util-Clinics');
    };
    const handleAmbulance = () => {
      navigate('../../SuperAdmin/util-Ambulance');
    };
    const handleDoctors = () => {
      navigate('../../SuperAdmin/util-Doctors');
    };
    const handleLabs = () => {
      navigate('../../SuperAdmin/util-Diagnosticlabs');
    };
    const handleAdmin = () => {
      navigate('../../SuperAdmin/util-Manageadmin');
    };

    const [roleCounts, setRoleCounts] = React.useState({
      'Doctor Admin': 0,
      'Hospital Admin': 0,
      'Ambulance Admin': 0,
      'Clinic Admin': 0,
      'Diagnostic Admin': 0,
      'Total Admins': 0,
    });
    
    // ...
    
    React.useEffect(() => {
      // Replace 'http://localhost:5000/api/admins' with the actual endpoint URL
      fetch('http://localhost:5000/api/admins')
        .then((response) => response.json())
        .then((data) => {
          // Calculate role counts
          const counts = data.reduce((acc, row) => {
            acc[row.role] = (acc[row.role] || 0) + 1;
            acc['Total Admins'] += 1; // Increment Total Admins count
            return acc;
          }, {});
    
          // Update state with the counts
          setRoleCounts(counts);
        })
        .catch((error) => console.error('Error fetching data:', error));
    }, []);

    const [totalAdminsCount, setTotalAdminsCount] = useState(0);
  
    useEffect(() => {
      // Replace 'http://localhost:5000/api/admins' with the actual endpoint URL
      fetch('http://localhost:5000/api/admins')
        .then((response) => response.json())
        .then((data) => {
          setTotalAdminsCount(data.length); // Update state with the total count
          setLoading(false);
        })
        .catch((error) => console.error('Error fetching data:', error));
    }, []);
    
    

  return (
    <Grid container spacing={gridSpacing}>
     <Grid item xs={12}>
        <h1 style={{ marginTop: "20px" }}>Super Admin</h1>
        <Grid container spacing={gridSpacing}>
          <Grid item xs={12} sm={6} md={4} lg={4}>
            {isLoading ? (
              <SkeletonEarningCard />
            ) : (
              <div>
                <CardWrapper border={false} content={false} onClick={handleHospitals}>
                  <Box sx={{ p: 2.25 }}>
                    <Grid container direction="column">
                      <Grid item>
                        <Grid container justifyContent="space-between">
                          <Grid item>
                            <Avatar
                              variant="rounded"
                              sx={{
                                ...theme.typography.commonAvatar,
                                ...theme.typography.largeAvatar,
                                backgroundColor: "white",
                                mt: 1
                              }}
                            >
                              <ApartmentIcon/>
                            </Avatar>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item>
                        <Grid container alignItems="center">
                          <Grid item>
                            <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                            {roleCounts['Hospital Admin']}
                            </Typography>
                          </Grid>
                          <Grid item>
                            <Avatar
                              sx={{
                                cursor: 'pointer',
                                ...theme.typography.smallAvatar,
                                backgroundColor: theme.palette.secondary[200],
                                color: theme.palette.secondary.dark
                              }}
                            >
                              <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                            </Avatar>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item sx={{ mb: 1.25 }}>
                        <Typography
                          sx={{
                            fontSize: '1rem',
                            fontWeight: 500,
                            color: "white"
                          }}
                        >
                   Total No of Hospitals
                        </Typography>
                      </Grid>
                    </Grid>
                  </Box>
                </CardWrapper>
              </div>
            )}
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
            {isLoading ? (
              <SkeletonEarningCard />
            ) : (
              <CardWrapper border={false} content={false} onClick={handleClinics}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            < LocalHospitalIcon />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {roleCounts['Clinic Admin']}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        Total Clinics
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
            )}
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
            {isLoading ? (
              <SkeletonEarningCard />
            ) : (
              <CardWrapper border={false} content={false} onClick={handleAmbulance}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            < MinorCrashIcon />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {roleCounts['Ambulance Admin']}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        Ambulance Avaliable
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
            )}
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Grid container spacing={gridSpacing}>
          <Grid item xs={12} sm={6} md={4} lg={4}>
            {isLoading ? (
              <SkeletonEarningCard />
            ) : (
              <CardWrapper border={false} content={false} onClick={handleDoctors}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            < FaUserMd />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {roleCounts['Doctor Admin']}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        Doctors Avalable
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
            )}
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
            {isLoading ? (
              <SkeletonEarningCard />
            ) : (
              <CardWrapper border={false} content={false} onClick={handleLabs}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            < FaFlask />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {roleCounts['Diagnostic Admin']}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        Total lab Results
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
            )}
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
            {isLoading ? (
              <SkeletonEarningCard />
            ) : (
              <CardWrapper border={false} content={false} onClick={handleAdmin}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            < FaUserCog />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                        {totalAdminsCount}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        Total Admins
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
            )}
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Dashboard;
