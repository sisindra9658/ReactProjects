import React from 'react'

function FAQ1() {
  return (
    <div>
      <h1>FAQ</h1>
    </div>
  )
}

export default FAQ1
