import React, { useState, useEffect, Suspense } from 'react';
import {
  List,
  Button,
  TextField,
  IconButton,
  Grid,
  Typography,
  Paper,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

const HospitalDropdown = () => {
  const [selectedHospital, setSelectedHospital] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [hospitals, setHospitals] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState(null);
  const [renderedComponent, setRenderedComponent] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [editedDetails, setEditedDetails] = useState({
    LabName: '',
    Location: '',
    ContactNumber: '',
    Email: '',
    WorkingHours: '',
    Website: '',
    Accreditations: '',
    TechnologiesUsed: '',
    BookingAppAvailable: '',
    EmergencyServices: '',
    HomeCollectionServices: '',
    ReportsDeliveryTime: '',
    PaymentModesAccepted: '',
    LabSpecialty: '',
    LabCapacity: '',
    StaffCount: '',
    LabCertifications: '',
    LabBranches: '',
    LabAffiliations: '',
    LabRating: '',
    LabComments: '',
    ServicesOffered: ''
  });

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/Diagnostics/list');
        if (!response.ok) {
          throw new Error(`Failed to fetch Diagnostic names. Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Fetched Diagnostics:', data);

        setHospitals(data);

        if (data.length > 0) {
          handleHospitalClick(data[0]);
        }
      } catch (error) {
        console.error('Error fetching Diagnostics names:', error);
      }
    };

    fetchHospitals();
  }, []);

  const fetchHospitalDetails = async (LabName) => {
    try {
      const response = await fetch(`http://localhost:5000/api/DiagnosticDetails?name=${encodeURIComponent(LabName)}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch Diagnostic details. Status: ${response.status}`);
      }
      const data = await response.json();

      return data.DiagnosticDetails;
    } catch (error) {
      console.error('Error fetching Diagnostic details:', error);
      throw error;
    }
  };

  const handleHospitalClick = async (hospital) => {
    console.log('Selected Hospital:', hospital);
    setSelectedHospital(hospital);
    setRenderedComponent(null);

    try {
      const details = await fetchHospitalDetails(hospital.LabName);
      setHospitalDetails(details);
    } catch (error) {
      console.error('Error in handleHospitalClick:', error);
    }
  };

  const performSearch = () => {
    return hospitals
      ? hospitals.filter(
          (hospital) =>
            hospital &&
            hospital.LabName &&
            searchTerm &&
            hospital.LabName.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : [];
  };

  const handleSearch = () => {
    const filteredHospitals = performSearch();
    console.log('Filtered Hospitals:', filteredHospitals);
  };

  const handleEnterKey = (event) => {
    if (event.key === 'Enter') {
      const filteredHospitals = performSearch();
      console.log('Filtered Diagnostic on Enter:', filteredHospitals);
    }
  };

  const handleEditClick = async () => {
    setIsEditing(true);
  
    try {
      // Fetch detailed information for the selected hospital
      const details = await fetchHospitalDetails(selectedHospital.LabName);
  
      // Set the editedDetails with both the selectedHospital and detailed information
      setEditedDetails({
        ...selectedHospital,
        ...details,
      });
    } catch (error) {
      console.error('Error in handleEditClick:', error);
    }
  };
  

  const handleSaveEdit = async () => {
    try {
      // Send a request to update the hospital details
      const response = await fetch(`http://localhost:5000/api/Diagnostics/${selectedHospital.LabName}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedDetails),
      });

      if (!response.ok) {
        throw new Error(`Failed to update Diagnostics details. Status: ${response.status}`);
      }

      // If the update is successful, refresh the hospital details
      const updatedDetails = await fetchHospitalDetails(selectedHospital.LabName);
      setHospitalDetails(updatedDetails);

      setIsEditing(false);
    } catch (error) {
      console.error('Error updating hospital details:', error);
    }
  };

  // const handleDelete = async () => {
  //   try {
  //     // Send a request to delete the hospital
  //     const response = await fetch(`http://localhost:5000/api/hospitals/${selectedHospital.HospitalFullName}`, {
  //       method: 'DELETE',
  //     });

  //     if (!response.ok) {
  //       throw new Error(`Failed to delete hospital. Status: ${response.status}`);
  //     }

  //     // After successful deletion, reset selectedHospital and hospitalDetails
  //     setSelectedHospital(null);
  //     setHospitalDetails(null);
  //   } catch (error) {
  //     console.error('Error deleting hospital:', error);
  //   }
  // };

  return (
  <>
    {hospitals.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <div>
      <h1 style={{ display: 'flex', justifyContent: 'center', color: '#00ab9f', marginTop: '20px', marginBottom: '30px' }}>
        Select Lab For Details
      </h1>
      <Grid container spacing={2}>
        <Grid item xs={2}>
          <TextField
            label="Search Diagnostics"
            placeholder="Search Diagnostics"
            variant="outlined"
            fullWidth
            margin="normal"
            size="small"
            style={{ width: '100%' }}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              ),
            }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleEnterKey}
          />
          <List>
            {performSearch().map((hospital, index) => (
              <Button
                key={index}
                onClick={() => handleHospitalClick(hospital)}
                variant="outlined"
                style={{
                  display: 'block',
                  width: '100%',
                  padding: '8px',
                  marginBottom: '8px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  background: 'white',
                  textAlign: 'left',
                  cursor: 'pointer',
                }}
              >
                {hospital.LabName}
              </Button>
            ))}
          </List>
          <div  style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <List>
              {hospitals.map((hospital, index) => (
                <Button
                  key={index}
                  onClick={() => handleHospitalClick(hospital)}
                  variant="outlined"
                  style={{
                    display: 'block',
                    width: '100%',
                    fontSize:'10px',
                    padding: '8px',
                    marginBottom: '8px',
                    background: 'white',
                    textAlign: 'left',
                    cursor: 'pointer',
                    backgroundColor: selectedHospital === hospital ? '#00ab9f' : 'transparent',
                    color: selectedHospital === hospital ? 'white' : 'black',
                  }}
                >
                  {hospital.LabName}
                </Button>
              ))}
            </List>
          </div>
        </Grid>
        <Grid item xs={10}>
          {selectedHospital && (
            <div>
              <Suspense fallback={<div>Loading...</div>}>
                <Paper elevation={3} style={{ padding: '20px', marginBottom: '20px' }}>
                  <div>
                  <Typography variant={isEditing ? "h4" : "h6"} style={{ fontSize: isEditing ? "24px" : "inherit", marginBottom: "20px"  }}>
                    {isEditing ? 'Edit Lab Details' : ''}
                  </Typography>

                    {isEditing ? (
                      <div>
                           <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                  <TextField label="LabName" name="LabName" value={editedDetails.LabName} onChange={(e) => setEditedDetails({ ...editedDetails, LabName: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Location" name="Location" value={editedDetails.Location} onChange={(e) => setEditedDetails({ ...editedDetails, Location: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="ContactNumber" name="ContactNumber" value={editedDetails.ContactNumber} onChange={(e) => setEditedDetails({ ...editedDetails, ContactNumber: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Email" name="Email" value={editedDetails.Email} onChange={(e) => setEditedDetails({ ...editedDetails, Email: e.target.value })} fullWidth />
              </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="WorkingHours" name="WorkingHours" value={editedDetails.WorkingHours} onChange={(e) => setEditedDetails({ ...editedDetails, WorkingHours: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Website" name="Website" value={editedDetails.Website} onChange={(e) => setEditedDetails({ ...editedDetails, Website: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Accreditations" name="Accreditations" value={editedDetails.Accreditations} onChange={(e) => setEditedDetails({ ...editedDetails, Accreditations: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="TechnologiesUsed" name="TechnologiesUsed" value={editedDetails.TechnologiesUsed} onChange={(e) => setEditedDetails({ ...editedDetails, TechnologiesUsed: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="BookingAppAvailable" name="BookingAppAvailable" value={editedDetails.BookingAppAvailable} onChange={(e) => setEditedDetails({ ...editedDetails, BookingAppAvailable: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="EmergencyServices" name="EmergencyServices" value={editedDetails.EmergencyServices} onChange={(e) => setEditedDetails({ ...editedDetails, EmergencyServices: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="HomeCollectionServices" name="HomeCollectionServices" value={editedDetails.HomeCollectionServices} onChange={(e) => setEditedDetails({ ...editedDetails, HomeCollectionServices: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="ReportsDeliveryTime" name="ReportsDeliveryTime" value={editedDetails.ReportsDeliveryTime} onChange={(e) => setEditedDetails({ ...editedDetails, ReportsDeliveryTime: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="PaymentModesAccepted" name="PaymentModesAccepted" value={editedDetails.PaymentModesAccepted} onChange={(e) => setEditedDetails({ ...editedDetails, PaymentModesAccepted: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="LabSpecialty" name="LabSpecialty" value={editedDetails.LabSpecialty} onChange={(e) => setEditedDetails({ ...editedDetails, LabSpecialty: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="LabCapacity" name="LabCapacity" value={editedDetails.LabCapacity} onChange={(e) => setEditedDetails({ ...editedDetails, LabCapacity: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="StaffCount" name="StaffCount" value={editedDetails.StaffCount} onChange={(e) => setEditedDetails({ ...editedDetails, StaffCount: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="LabCertifications" name="LabCertifications" value={editedDetails.LabCertifications} onChange={(e) => setEditedDetails({ ...editedDetails, LabCertifications: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="LabBranches" name="LabBranches" value={editedDetails.LabBranches} onChange={(e) => setEditedDetails({ ...editedDetails, LabBranches: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="LabAffiliations" name="LabAffiliations" value={editedDetails.LabAffiliations} onChange={(e) => setEditedDetails({ ...editedDetails, LabAffiliations: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="LabRating" name="LabRating" value={editedDetails.LabRating} onChange={(e) => setEditedDetails({ ...editedDetails, LabRating: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="LabComments" name="LabComments" value={editedDetails.LabComments} onChange={(e) => setEditedDetails({ ...editedDetails, LabComments: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="ServicesOffered" name="ServicesOffered" value={editedDetails.ServicesOffered} onChange={(e) => setEditedDetails({ ...editedDetails, ServicesOffered: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                </Grid>
 
                <Grid item xs={12} sm={6}>
                </Grid>
                </Grid>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop:'25px', marginBottom:'25px'}}>
                <Button onClick={handleSaveEdit} variant="contained" color="primary">
                  Save Changes
                </Button>
              </div>

                        {/* <Button onClick={handleDelete} variant="contained" color="secondary">
                          Delete
                        </Button> */}
                      </div>
                    ) : (
                      <>
                        {/* ... (Your existing JSX) */}
                        <Button onClick={handleEditClick} variant="contained" color="primary" style={{marginLeft:'auto', display:'flex'}}>
                          Edit Lab Details
                        </Button>
                      </>
                    )}
                    {hospitalDetails && (
                      <div>
                        <Grid container spacing={2}>
                          {Object.entries(hospitalDetails).map(([key, value]) => (
                            <>
                              <Grid item xs={5} key={key}>
                                <Typography variant="h6"> <h3 style={{color:'black'}}>{key} :</h3></Typography>
                              </Grid>
                              <Grid item xs={7} key={key}>
                                <Typography><h5>{value}</h5></Typography>
                              </Grid>
                            </>
                          ))}
                        </Grid>
                      </div>
                    )}
                    {renderedComponent}
                  </div>
                </Paper>
              </Suspense>
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  )}
  </>
  );
};

export default HospitalDropdown;
