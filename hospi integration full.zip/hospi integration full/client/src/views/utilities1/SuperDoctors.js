import React, { useState, useEffect, Suspense } from 'react';
import {
  List,
  Button,
  TextField,
  IconButton,
  Grid,
  Select,
  Typography,
  MenuItem,
  FormControl,
  InputLabel,
  Paper,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

const HospitalDropdown = () => {
  const [selectedHospital, setSelectedHospital] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [hospitals, setHospitals] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState(null);
  const [renderedComponent, setRenderedComponent] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [editedDetails, setEditedDetails] = useState({
  DoctorName: '',
  RegistrationNo: '',
  Email: '',
  ContactNo: '',
  Designation: '',
  Degree: '',
  CollegeName: '',
  CompletionYear: '',
  TreatmentsOffered: '',
  ConsultationFee: '',
  YearsOfExperience: '',
  Awards: '',
  Department: '',
  Memberships: '',
  PublicationsLink: '',
  Monday: '',
  Tuesday: '',
  Wednesday: '',
  Thursday: '',
  Friday: '',
  Saturday: '',
  Sunday: '',
  OrganisationName: '',
  Tenure: '',
  Role: '',
  Council: '',
  CouncilRegistrationNo: '',
  filename: '',
  Specializations: '',
  Languages: '',
  });

  const [specializationOptions] = useState([
    'Cardiology',
    'Dermatologist',
    'Endocrinologist',
    'Gastroenterologist',
    'Pediatrics',
    'Dermatology',
    'Orthopedics',

  ]);

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/Doctors/list');
        if (!response.ok) {
          throw new Error(`Failed to fetch hospital names. Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Fetched Hospitals:', data);

        setHospitals(data);

        if (data.length > 0) {
          handleHospitalClick(data[0]);
        }
      } catch (error) {
        console.error('Error fetching hospital names:', error);
      }
    };

    fetchHospitals();
  }, []);

  const fetchHospitalDetails = async (DoctorName) => {
    try {
      const response = await fetch(`http://localhost:5000/api/DoctorsDetails?name=${encodeURIComponent(DoctorName)}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch hospital details. Status: ${response.status}`);
      }
      const data = await response.json();

      return data.DoctorDetails;
    } catch (error) {
      console.error('Error fetching hospital details:', error);
      throw error;
    }
  };

  const handleHospitalClick = async (hospital) => {
    console.log('Selected Hospital:', hospital);
    setSelectedHospital(hospital);
    setRenderedComponent(null);

    try {
      const details = await fetchHospitalDetails(hospital.DoctorName);
      setHospitalDetails(details);
    } catch (error) {
      console.error('Error in handleHospitalClick:', error);
    }
  };

  const performSearch = () => {
    return hospitals
      ? hospitals.filter(
          (hospital) =>
            hospital &&
            hospital.DoctorName &&
            searchTerm &&
            hospital.DoctorName.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : [];
  };

  const handleSearch = () => {
    const filteredHospitals = performSearch();
    console.log('Filtered Hospitals:', filteredHospitals);
  };

  const handleEnterKey = (event) => {
    if (event.key === 'Enter') {
      const filteredHospitals = performSearch();
      console.log('Filtered Hospitals on Enter:', filteredHospitals);
    }
  };

  const handleEditClick = async () => {
    setIsEditing(true);
  
    try {
      // Fetch detailed information for the selected hospital
      const details = await fetchHospitalDetails(selectedHospital.DoctorName);
  
      // Set the editedDetails with both the selectedHospital and detailed information
      setEditedDetails({
        ...selectedHospital,
        ...details,
      });
    } catch (error) {
      console.error('Error in handleEditClick:', error);
    }
  };
  

  const handleSaveEdit = async () => {
    try {
      // Send a request to update the hospital details
      const response = await fetch(`http://localhost:5000/api/Doctors/${selectedHospital.DoctorName}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedDetails),
      });

      if (!response.ok) {
        throw new Error(`Failed to update hospital details. Status: ${response.status}`);
      }

      // If the update is successful, refresh the hospital details
      const updatedDetails = await fetchHospitalDetails(selectedHospital.DoctorName);
      setHospitalDetails(updatedDetails);

      setIsEditing(false);
    } catch (error) {
      console.error('Error updating hospital details:', error);
    }
  };

  // const handleDelete = async () => {
  //   try {
  //     // Send a request to delete the hospital
  //     const response = await fetch(`http://localhost:5000/api/hospitals/${selectedHospital.HospitalFullName}`, {
  //       method: 'DELETE',
  //     });

  //     if (!response.ok) {
  //       throw new Error(`Failed to delete hospital. Status: ${response.status}`);
  //     }

  //     // After successful deletion, reset selectedHospital and hospitalDetails
  //     setSelectedHospital(null);
  //     setHospitalDetails(null);
  //   } catch (error) {
  //     console.error('Error deleting hospital:', error);
  //   }
  // };

  return (
    <>
    {hospitals.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <div>
      <h1 style={{ display: 'flex', justifyContent: 'center', color: '#00ab9f', marginTop: '20px', marginBottom: '30px' }}>
        Select Doctor For Details
      </h1>
      <Grid container spacing={2}>
        <Grid item xs={2}>
          <TextField
            label="Search Doctor"
            placeholder="Search Doctor"
            variant="outlined"
            fullWidth
            margin="normal"
            size="small"
            style={{ width: '100%' }}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              ),
            }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleEnterKey}
          />
          <List>
            {performSearch().map((hospital, index) => (
              <Button
                key={index}
                onClick={() => handleHospitalClick(hospital)}
                variant="outlined"
                style={{
                  display: 'block',
                  width: '100%',
                  padding: '8px',
                  marginBottom: '8px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  background: 'white',
                  textAlign: 'left',
                  cursor: 'pointer',
                }}
              >
                {hospital.DoctorName}
              </Button>
            ))}
          </List>
          <div  style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <List>
              {hospitals.map((hospital, index) => (
                <Button
                  key={index}
                  onClick={() => handleHospitalClick(hospital)}
                  variant="outlined"
                  style={{
                    display: 'block',
                    width: '100%',
                    padding: '8px',
                    marginBottom: '8px',
                    fontSize:'10px',
                    background: 'white',
                    textAlign: 'left',
                    cursor: 'pointer',
                    backgroundColor: selectedHospital === hospital ? '#00ab9f' : 'transparent',
                    color: selectedHospital === hospital ? 'white' : 'black',
                  }}
                >
                  {hospital.DoctorName}
                </Button>
              ))}
            </List>
          </div>
        </Grid>
        <Grid item xs={10}>
          {selectedHospital && (
            <div>
              <Suspense fallback={<div>Loading...</div>}>
                <Paper elevation={3} style={{ padding: '20px', marginBottom: '20px' }}>
                  <div>
                  <Typography variant={isEditing ? "h4" : "h6"} style={{ fontSize: isEditing ? "24px" : "inherit", marginBottom: "20px"  }}>
                    {isEditing ? 'Edit Doctor Details' : ''}
                  </Typography>

                    {isEditing ? (
                      <div>
              <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                  <TextField label="Doctor Name" name="DoctorName" value={editedDetails.DoctorName} onChange={(e) => setEditedDetails({ ...editedDetails, DoctorName: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Registration No" name="RegistrationNo" value={editedDetails.RegistrationNo} onChange={(e) => setEditedDetails({ ...editedDetails, RegistrationNo: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Email" name="Email" value={editedDetails.Email} onChange={(e) => setEditedDetails({ ...editedDetails, Email: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Contact No" name="ContactNo" value={editedDetails.ContactNo} onChange={(e) => setEditedDetails({ ...editedDetails, ContactNo: e.target.value })} fullWidth />
              </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Designation" name="Designation" value={editedDetails.Designation} onChange={(e) => setEditedDetails({ ...editedDetails, Designation: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Degree" name="Degree" value={editedDetails.Degree} onChange={(e) => setEditedDetails({ ...editedDetails, Degree: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="CollegeName" name="CollegeName" value={editedDetails.CollegeName} onChange={(e) => setEditedDetails({ ...editedDetails, CollegeName: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="CompletionYear" name="CompletionYear" value={editedDetails.CompletionYear} onChange={(e) => setEditedDetails({ ...editedDetails, CompletionYear: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Treatments Offered" name="TreatmentsOffered" value={editedDetails.TreatmentsOffered} onChange={(e) => setEditedDetails({ ...editedDetails, TreatmentsOffered: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Consultation Fee" name="ConsultationFee" value={editedDetails.ConsultationFee} onChange={(e) => setEditedDetails({ ...editedDetails, ConsultationFee: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="YearsOfExperience" name="YearsOfExperience" value={editedDetails.YearsOfExperience} onChange={(e) => setEditedDetails({ ...editedDetails, YearsOfExperience: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="Awards" name="Awards" value={editedDetails.Awards} onChange={(e) => setEditedDetails({ ...editedDetails, Awards: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Department" name="Department" value={editedDetails.Department} onChange={(e) => setEditedDetails({ ...editedDetails, Department: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Memberships" name="Memberships" value={editedDetails.Memberships} onChange={(e) => setEditedDetails({ ...editedDetails, Memberships: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Publications Link" name="PublicationsLink" value={editedDetails.PublicationsLink} onChange={(e) => setEditedDetails({ ...editedDetails, PublicationsLink: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="Monday" name="Monday" value={editedDetails.Monday} onChange={(e) => setEditedDetails({ ...editedDetails, Monday: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Tuesday" name="Tuesday" value={editedDetails.Tuesday} onChange={(e) => setEditedDetails({ ...editedDetails, Tuesday: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Wednesday" name="Wednesday" value={editedDetails.Wednesday} onChange={(e) => setEditedDetails({ ...editedDetails, Wednesday: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Thursday" name="Thursday" value={editedDetails.Thursday} onChange={(e) => setEditedDetails({ ...editedDetails, Thursday: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="Friday" name="Friday" value={editedDetails.Friday} onChange={(e) => setEditedDetails({ ...editedDetails, Friday: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Saturday" name="Saturday" value={editedDetails.Saturday} onChange={(e) => setEditedDetails({ ...editedDetails, Saturday: e.target.value })} fullWidth />       
               </Grid>
                {/* <Grid item xs={12} sm={6}>
                <TextField
                    label="StartTime"
                    type="Time"
                    name='StartTime'
                    value={editedDetails.StartTime}
                    onChange={(e) => setEditedDetails({ ...editedDetails, StartTime: e.target.value })}
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{
                      step: 300
                    }}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField
                    label="EndTime"
                    type="Time"
                    name='EndTime'
                    value={editedDetails.EndTime}
                    onChange={(e) => setEditedDetails({ ...editedDetails, EndTime: e.target.value })}
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{
                      step: 300
                    }}
                    fullWidth
                  />  
                  </Grid> */}
                <Grid item xs={12} sm={6}>
                  <TextField label="Sunday" name="Sunday" value={editedDetails.Sunday} onChange={(e) => setEditedDetails({ ...editedDetails, Sunday: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Organisation Name" name="OrganisationName" value={editedDetails.OrganisationName} onChange={(e) => setEditedDetails({ ...editedDetails, OrganisationName: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Tenure" name="Tenure" value={editedDetails.Tenure} onChange={(e) => setEditedDetails({ ...editedDetails, Tenure: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Role" name="Role" value={editedDetails.Role} onChange={(e) => setEditedDetails({ ...editedDetails, Role: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="Council" name="Council" value={editedDetails.Council} onChange={(e) => setEditedDetails({ ...editedDetails, Council: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Council Registration No" name="CouncilRegistrationNo" value={editedDetails.CouncilRegistrationNo} onChange={(e) => setEditedDetails({ ...editedDetails, CouncilRegistrationNo: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Filename" name="filename" value={editedDetails.filename} onChange={(e) => setEditedDetails({ ...editedDetails, filename: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="Specialities-label">Specializations</InputLabel>
                  <Select
                    labelId="Specialities-label"
                    id="Specializations"
                    name="Specializations"
                    value={editedDetails.Specializations}
                    onChange={(e) => setEditedDetails({ ...editedDetails, Specializations: e.target.value })}
                    label="Specializations"
                  >
                    {specializationOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                </Grid>

              <Grid item xs={12} sm={6}>
              <TextField label="Languages" name="Languages" value={editedDetails.Languages} onChange={(e) => setEditedDetails({ ...editedDetails, Languages: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                </Grid>
 
                <Grid item xs={12} sm={6}>
                </Grid>
                </Grid>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop:'25px', marginBottom:'25px'}}>
                <Button onClick={handleSaveEdit} variant="contained" color="primary">
                  Save Changes
                </Button>
              </div>

                        {/* <Button onClick={handleDelete} variant="contained" color="secondary">
                          Delete
                        </Button> */}
                      </div>
                    ) : (
                      <>
                        {/* ... (Your existing JSX) */}
                        <Button onClick={handleEditClick} variant="contained" color="primary" style={{marginLeft:'auto', display:'flex'}}>
                          Edit Doctor Details
                        </Button>
                      </>
                    )}
                    {hospitalDetails && (
                      <div>
                        <Grid container spacing={2}>
                          {Object.entries(hospitalDetails).map(([key, value]) => (
                            <>
                               <Grid item xs={5} key={key}>
                                <Typography variant="h6"> <h3 style={{color:'black'}}>{key} :</h3></Typography>
                              </Grid>
                              <Grid item xs={7} key={key}>
                                <Typography><h5>{value}</h5></Typography>
                              </Grid>
                            </>
                          ))}
                        </Grid>
                      </div>
                    )}
                    {renderedComponent}
                  </div>
                </Paper>
              </Suspense>
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  )}
  </>
  );
};

export default HospitalDropdown;
