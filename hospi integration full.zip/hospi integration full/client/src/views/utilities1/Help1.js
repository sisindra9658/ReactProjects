import React from 'react'

function Help1() {
  return (
    <div>
     <h1>help</h1> 
    </div>
  )
}

export default Help1
