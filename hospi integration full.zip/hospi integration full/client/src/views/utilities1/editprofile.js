import * as React from 'react';


export default function UseFormControl() {
  return (
    <h1>EDIT PROFILE</h1>
  );
}
