import React, { useState, useEffect, Suspense } from 'react';
import {
  List,
  Button,
  TextField,
  IconButton,
  Grid,
  Typography,
  Paper,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

const HospitalDropdown = () => {
  const [selectedHospital, setSelectedHospital] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [hospitals, setHospitals] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState(null);
  const [renderedComponent, setRenderedComponent] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [editedDetails, setEditedDetails] = useState({
    AmbulanceID: '',
    AmbulanceFullName: '',
    RegistrationNumber: '',
    VehicleType: '',
    VehicleCondition: '',
    AdditionalEquipment: '',
    Model: '',
    Manufacturer: '',
    YearOfManufacture: '',
    CurrentMileage: '',
    Status: '',
    EquipmentAvailability: '',
    OxygenSupply: '',  
    DefibrillatorAvailability: '',
    MedicalSuppliesAvailability: '',
    MedicalTeamAvailability:'',
    LastMaintenanceDate: '',
    InsuranceExpirationDate: '',
    CommunicationSystem: '',
    ServiceHistory: ''
  });

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/Ambulance/list');
        if (!response.ok) {
          throw new Error(`Failed to fetch Ambulance names. Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Fetched Ambulance:', data);

        setHospitals(data);

        if (data.length > 0) {
          handleHospitalClick(data[0]);
        }
      } catch (error) {
        console.error('Error fetching Ambulance names:', error);
      }
    };

    fetchHospitals();
  }, []);

  const fetchHospitalDetails = async (AmbulanceName) => {
    try {
      const response = await fetch(`http://localhost:5000/api/AmbulanceDetails?name=${encodeURIComponent(AmbulanceName)}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch Ambulance details. Status: ${response.status}`);
      }
      const data = await response.json();

      return data.AmbulanceDetails;
    } catch (error) {
      console.error('Error fetching Ambulance details:', error);
      throw error;
    }
  };

  const handleHospitalClick = async (hospital) => {
    console.log('Selected Hospital:', hospital);
    setSelectedHospital(hospital);
    setRenderedComponent(null);

    try {
      const details = await fetchHospitalDetails(hospital.AmbulanceFullName);
      setHospitalDetails(details);
    } catch (error) {
      console.error('Error in handleHospitalClick:', error);
    }
  };

  const performSearch = () => {
    return hospitals
      ? hospitals.filter(
          (hospital) =>
            hospital &&
            hospital.AmbulanceFullName &&
            searchTerm &&
            hospital.AmbulanceFullName.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : [];
  };

  const handleSearch = () => {
    const filteredHospitals = performSearch();
    console.log('Filtered Ambulance:', filteredHospitals);
  };

  const handleEnterKey = (event) => {
    if (event.key === 'Enter') {
      const filteredHospitals = performSearch();
      console.log('Filtered Ambulance on Enter:', filteredHospitals);
    }
  };

  const handleEditClick = async () => {
    setIsEditing(true);
  
    try {
      // Fetch detailed information for the selected hospital
      const details = await fetchHospitalDetails(selectedHospital.AmbulanceFullName);
  
      // Set the editedDetails with both the selectedHospital and detailed information
      setEditedDetails({
        ...selectedHospital,
        ...details,
      });
    } catch (error) {
      console.error('Error in handleEditClick:', error);
    }
  };
  

  const handleSaveEdit = async () => {
    try {
      // Send a request to update the hospital details
      const response = await fetch(`http://localhost:5000/api/Ambulance/${selectedHospital.AmbulanceFullName}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedDetails),
      });

      if (!response.ok) {
        throw new Error(`Failed to update Ambulance details. Status: ${response.status}`);
      }

      // If the update is successful, refresh the hospital details
      const updatedDetails = await fetchHospitalDetails(selectedHospital.AmbulanceFullName);
      setHospitalDetails(updatedDetails);

      setIsEditing(false);
    } catch (error) {
      console.error('Error updating Ambulance details:', error);
    }
  };

  // const handleDelete = async () => {
  //   try {
  //     // Send a request to delete the hospital
  //     const response = await fetch(`http://localhost:5000/api/hospitals/${selectedHospital.HospitalFullName}`, {
  //       method: 'DELETE',
  //     });

  //     if (!response.ok) {
  //       throw new Error(`Failed to delete hospital. Status: ${response.status}`);
  //     }

  //     // After successful deletion, reset selectedHospital and hospitalDetails
  //     setSelectedHospital(null);
  //     setHospitalDetails(null);
  //   } catch (error) {
  //     console.error('Error deleting hospital:', error);
  //   }
  // };

  return (
    <>
    {hospitals.length === 0 ? (
    <Typography variant="h6" align="center" mt={4}>
      No data available
    </Typography>
  ) : (
    <div>
      <h1 style={{ display: 'flex', justifyContent: 'center', color: '#00ab9f', marginTop: '20px', marginBottom: '30px' }}>
        Select Ambulance For Details
      </h1>
      <Grid container spacing={2}>
        <Grid item xs={2}>
          <TextField
            label="Search Ambulance"
            placeholder="Search Ambulance"
            variant="outlined"
            fullWidth
            margin="normal"
            size="small"
            style={{ width: '100%' }}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              ),
            }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleEnterKey}
          />
          <List>
            {performSearch().map((hospital, index) => (
              <Button
                key={index}
                onClick={() => handleHospitalClick(hospital)}
                variant="outlined"
                style={{
                  display: 'block',
                  width: '100%',
                  padding: '8px',
                  marginBottom: '8px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  background: 'white',
                  textAlign: 'left',
                  cursor: 'pointer',
                }}
              >
                {hospital.AmbulanceFullName}
              </Button>
            ))}
          </List>
          <div  style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <List>
              {hospitals.map((hospital, index) => (
                <Button
                  key={index}
                  onClick={() => handleHospitalClick(hospital)}
                  variant="outlined"
                  style={{
                    display: 'block',
                    width: '100%',
                    padding: '8px',
                    fontSize:'10px',
                    marginBottom: '8px',
                    background: 'white',
                    textAlign: 'left',
                    cursor: 'pointer',
                    backgroundColor: selectedHospital === hospital ? '#00ab9f' : 'transparent',
                    color: selectedHospital === hospital ? 'white' : 'black',
                  }}
                >
                  {hospital.AmbulanceFullName}
                </Button>
              ))}
            </List>
          </div>
        </Grid>
        <Grid item xs={10}>
          {selectedHospital && (
            <div>
              <Suspense fallback={<div>Loading...</div>}>
                <Paper elevation={3} style={{ padding: '20px', marginBottom: '20px' }}>
                  <div>
                  <Typography variant={isEditing ? "h4" : "h6"} style={{ fontSize: isEditing ? "24px" : "inherit", marginBottom: "20px"  }}>
                    {isEditing ? 'Edit Ambulance Details' : ''}
                  </Typography>

                    {isEditing ? (
                      <div>
                           <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                  <TextField label="AmbulanceID" name="AmbulanceID" value={editedDetails.AmbulanceID} onChange={(e) => setEditedDetails({ ...editedDetails, AmbulanceID: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="AmbulanceFullName" name="AmbulanceFullName" value={editedDetails.AmbulanceFullName} onChange={(e) => setEditedDetails({ ...editedDetails, AmbulanceFullName: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="RegistrationNumber" name="RegistrationNumber" value={editedDetails.RegistrationNumber} onChange={(e) => setEditedDetails({ ...editedDetails, RegistrationNumber: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="VehicleType" name="VehicleType" value={editedDetails.VehicleType} onChange={(e) => setEditedDetails({ ...editedDetails, VehicleType: e.target.value })} fullWidth />
              </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="VehicleCondition" name="VehicleCondition" value={editedDetails.VehicleCondition} onChange={(e) => setEditedDetails({ ...editedDetails, VehicleCondition: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="AdditionalEquipment" name="AdditionalEquipment" value={editedDetails.AdditionalEquipment} onChange={(e) => setEditedDetails({ ...editedDetails, AdditionalEquipment: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Model" name="Model" value={editedDetails.Model} onChange={(e) => setEditedDetails({ ...editedDetails, Model: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Manufacturer" name="Manufacturer" value={editedDetails.Manufacturer} onChange={(e) => setEditedDetails({ ...editedDetails, Manufacturer: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="YearOfManufacture" name="YearOfManufacture" value={editedDetails.YearOfManufacture} onChange={(e) => setEditedDetails({ ...editedDetails, YearOfManufacture: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="CurrentMileage" name="CurrentMileage" value={editedDetails.CurrentMileage} onChange={(e) => setEditedDetails({ ...editedDetails, CurrentMileage: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Status" name="Status" value={editedDetails.Status} onChange={(e) => setEditedDetails({ ...editedDetails, Status: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="EquipmentAvailability" name="EquipmentAvailability" value={editedDetails.EquipmentAvailability} onChange={(e) => setEditedDetails({ ...editedDetails, EquipmentAvailability: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="OxygenSupply" name="OxygenSupply" value={editedDetails.OxygenSupply} onChange={(e) => setEditedDetails({ ...editedDetails, OxygenSupply: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="DefibrillatorAvailability" name="DefibrillatorAvailability" value={editedDetails.DefibrillatorAvailability} onChange={(e) => setEditedDetails({ ...editedDetails, DefibrillatorAvailability: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="MedicalSuppliesAvailability" name="MedicalSuppliesAvailability" value={editedDetails.MedicalSuppliesAvailability} onChange={(e) => setEditedDetails({ ...editedDetails, MedicalSuppliesAvailability: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="LastMaintenanceDate" name="LastMaintenanceDate" value={editedDetails.LastMaintenanceDate} onChange={(e) => setEditedDetails({ ...editedDetails, LastMaintenanceDate: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="InsuranceExpirationDate" name="InsuranceExpirationDate" value={editedDetails.InsuranceExpirationDate} onChange={(e) => setEditedDetails({ ...editedDetails, InsuranceExpirationDate: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="CommunicationSystem" name="CommunicationSystem" value={editedDetails.CommunicationSystem} onChange={(e) => setEditedDetails({ ...editedDetails, CommunicationSystem: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="ServiceHistory" name="ServiceHistory" value={editedDetails.ServiceHistory} onChange={(e) => setEditedDetails({ ...editedDetails, ServiceHistory: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                </Grid>
 
                <Grid item xs={12} sm={6}>
                </Grid>
                </Grid>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop:'25px', marginBottom:'25px'}}>
                <Button onClick={handleSaveEdit} variant="contained" color="primary">
                  Save Changes
                </Button>
              </div>
                      </div>
                    ) : (
                      <>
                        {/* ... (Your existing JSX) */}
                        <Button onClick={handleEditClick} variant="contained" color="primary" style={{marginLeft:'auto', display:'flex'}}>
                          Edit Ambulance Details
                        </Button>
                      </>
                    )}
                    {hospitalDetails && (
                      <div>
                        <Grid container spacing={2}>
                        {Object.entries(hospitalDetails).map(([key, value], index) => (
                        <React.Fragment key={index}>
                              <Grid item xs={5} key={key}>
                                <Typography variant="h6"> <h3 style={{color:'black'}}>{key} :</h3></Typography>
                              </Grid>
                              <Grid item xs={7} key={key}>
                                <Typography><h5>{value}</h5></Typography>
                              </Grid>
                        </React.Fragment>
                      ))}
                        </Grid>
                      </div>
                    )}
                    {renderedComponent}
                  </div>
                </Paper>
              </Suspense>
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  )}
  </>
  );
};

export default HospitalDropdown;
