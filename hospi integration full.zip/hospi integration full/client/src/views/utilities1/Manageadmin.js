import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Grid';
import SearchIcon from '@mui/icons-material/Search';
import Menu from '@mui/material/Menu';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import { FaEdit, FaTrash } from 'react-icons/fa';
import Typography from '@mui/material/Typography';



const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

export default function CustomizedTables() {
  // const formRef = React.useRef(null);
  const [isEditing, setIsEditing] = React.useState(false);
  const [showForm, setShowForm] = React.useState(false);
  const [currentadminID, setCurrentadminID] = React.useState(null);
  const [rows, setRows] = React.useState([]); // State to hold the fetched data
  const [formData, setFormData] = React.useState({
    username: '',
    password: '',
    Primary_name: '',
    Secondary_name: '',
    email: '',
    contact_number: '', 
    role: '', 
    managing_admin: '',    
  });


  // const handleCloseButtonClick = () => {
  //   setShowForm(false);
  // };

  const [anchorElMap, setAnchorElMap] = React.useState({});

  const handleMenuClick = (event, adminID) => {
    setAnchorElMap((prevMap) => ({
      ...prevMap,
      [adminID]: event.currentTarget,
    }));
    setCurrentadminID(adminID);
  };

  const handleMenuClose = (adminID) => {
    setAnchorElMap((prevMap) => ({
      ...prevMap,
      [adminID]: null,
    }));
  };
 
  const handleEdit = (adminID, username, password, Primary_name, Secondary_name, email, contact_number, role, managing_admin) => {
    setFormData({
      username: username,
      password: password,
      Primary_name: Primary_name,
      Secondary_name: Secondary_name,
      email: email,
      contact_number: contact_number,
      role: role,
      managing_admin: managing_admin,
    });
    setCurrentadminID(adminID);
    setShowForm(true);
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      let apiUrl;

      if (isEditing && currentadminID) {
        apiUrl = `http://localhost:5000/api/admins/${currentadminID}`;
      } else {
        apiUrl = 'http://localhost:5000/api/admins';
      }

      const response = await fetch(apiUrl, {
        method: isEditing ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error(
          isEditing
            ? `Failed to update Admins with ID ${currentadminID}`
            : 'Failed to add a new Admin'
        );
      }

      const updatedadmin = await response.json();

      if (isEditing) {
        setRows((prevRows) =>
          prevRows.map((row) =>
            row.adminID === currentadminID ? { ...row, ...updatedadmin } : row
          )
        );
        console.log(`Admin with ID ${currentadminID} updated successfully`);
      } else {
        setRows((prevRows) => [...prevRows, updatedDriver]);
        console.log('New Admin added successfully:', updatedadmin);
      }

      setFormData({
        username: '',
        password: '',
        Primary_name: '',
        Secondary_name: '',
        email: '',
        contact_number: '',
        role: '',
        managing_admin :'',  
      });
      setCurrentadminID(null);
      setIsEditing(false);
      setShowForm(false);
    } catch (error) {
      console.error('Error saving data:', error.message);
    }
  };

 
  const removeRow = (adminID) => {
    setRows((prevRows) => prevRows.filter((row) => row.adminID !== adminID));
  };

  const handleRemove = async () => {
    try {
      // Make a DELETE request to your backend API to delete the driver
      const response = await fetch(`http://localhost:5000/api/admins/${currentadminID}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error(`Failed to delete driver with ID ${currentadminID}`);
      }
      // If the request is successful, remove the row from the frontend
      removeRow(currentadminID);
      handleMenuClose();

      console.log(`Admin with ID ${currentadminID} deleted successfully`);
    } catch (error) {
      console.error('Error deleting driver:', error.message);
    }
  };

  const [searchTerm, setSearchTerm] = React.useState('');

  const handleSearch = () => {
    const filtered = rows.filter((row) => row.username.toLowerCase().includes(searchTerm.toLowerCase()));
    setFilteredRows(filtered);
  };

  const StyledFormControl = styled(FormControl)({
    minWidth: 150,
  });

  const [selectedValues, setSelectedValues] = React.useState({
    select1: '',
  });

  const handleChange = (event, selectId) => {
    setSelectedValues((prevValues) => ({
      ...prevValues,
      [selectId]: event.target.value,
    }));
  };

  const [filteredRows, setFilteredRows] = React.useState(rows);

  // Update the filtered rows when any of the select values change
  React.useEffect(() => {
    const filtered = rows.filter((row) => {
      return (
        (selectedValues.select1 === '' || row.role === selectedValues.select1)
      );
    });
    setFilteredRows(filtered);
  }, [selectedValues, rows]);

  React.useEffect(() => {
    // Replace 'http://localhost:5000/api/Drivers' with the actual endpoint URL
    fetch('http://localhost:5000/api/admins')
      .then((response) => response.json())
      .then((data) => {
        setRows(data); // Update state with fetched data
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  const handleFormChange = (field, value) => {
    setFormData({
      ...formData,
      [field]: value,
    });
  };

  const handleAddAdmin = async () => {
    try {
      const apiUrl = currentadminID
        ? `http://localhost:5000/api/admins/${currentadminID}`
        : 'http://localhost:5000/api/admins';
  
      const method = currentadminID ? 'PUT' : 'POST';
  
      const response = await fetch(apiUrl, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
  
      if (!response.ok) {
        throw new Error(
          currentadminID ? `Failed to update admin with ID ${currentadminID}` : 'Failed to add a new admin'
        );
      }
  
      const updatedData = await response.json();
  
      if (currentadminID) {
        // Update the state with the edited data
        setRows((prevRows) =>
          prevRows.map((row) => (row.adminID === currentadminID ? { ...row, ...updatedData } : row))
        );
        console.log(`Admin with ID ${currentadminID} updated successfully`);
      } else {
        // Update the state with the new admin
        setRows((prevRows) => [...prevRows, updatedData]);
        console.log('New admin added successfully:', updatedData);
      }
  
      // Reset the form data, close the menu, and clear the currentadminID
      setFormData({
        username: '',
        password: '',
        Primary_name: '',
        Secondary_name: '',
        email: '',
        contact_number: '',
        role: '',
        managing_admin: '',
      });
      setCurrentadminID(null);
      handleMenuClose();
      setShowForm(false); // Hide the form after saving
    } catch (error) {
      console.error('Error adding/updating admin:', error.message);
    }
  };
  
  
  
  return (
    <>
            {rows.length === 0 ? (
            <Typography variant="h6" align="center" mt={4}>
              No data available
            </Typography>
          ) : (
            <>
      <Stack direction="row" spacing={2} justifyContent="flex-end" mt={2}>
      <Button
        variant="contained"
        startIcon={<PersonAddAlt1Icon />}
        sx={{ ml: 'auto' }}
        onClick={() => {
          setShowForm(true);
          setIsEditing(false);
        }}
      >
        Add Admin
      </Button>
      </Stack>
      <Dialog open={showForm} onClose={() => setShowForm(false)}>
        <DialogTitle>{currentadminID ? 'EDIT ADMIN' : 'ADD ADMIN'}</DialogTitle>
        <DialogContent>
          <form>
            <TextField
              label="username"
              placeholder="username"
              fullWidth
              margin="normal"
              value={formData.username}
              onChange={(e) => handleFormChange('username', e.target.value)}
            />
            <TextField
              label="password"
              placeholder="password"
              fullWidth
              margin="normal"
              value={formData.password}
              onChange={(e) => handleFormChange('password', e.target.value)}
            />
            <TextField
              label="primary name"
              placeholder="primary name"
              fullWidth
              margin="normal"
              value={formData.Primary_name}
              onChange={(e) => handleFormChange('Primary_name', e.target.value)}
            />
                <TextField
              label="secondary name"
              placeholder="secondary name"
              fullWidth
              margin="normal"
              value={formData.Secondary_name}
              onChange={(e) => handleFormChange('Secondary_name', e.target.value)}
            />
            <TextField
              label="email"
              placeholder="email"
              fullWidth
              margin="normal"
              value={formData.email}
              onChange={(e) => handleFormChange('email', e.target.value)}
            />
            <TextField
              label="contact number"
              placeholder="contact number"
              fullWidth
              margin="normal"
              value={formData.contact_number}
              onChange={(e) => handleFormChange('contact_number', e.target.value)}
            />
              <FormControl fullWidth margin="normal">
            <InputLabel id="role-label">Role</InputLabel>
            <Select
              labelId="role-label"
              id="role"
              value={formData.role}
              onChange={(e) => handleFormChange('role', e.target.value)}
              label="Role"
            >
              <MenuItem value="Doctor Admin">Doctor Admin</MenuItem>
              <MenuItem value="Hospital Admin">Hospital Admin</MenuItem>
              <MenuItem value="Ambulance Admin">Ambulance Admin</MenuItem>
              <MenuItem value="Clinic Admin">Clinic Admin</MenuItem>
              <MenuItem value="Diagnostic Admin">Diagnostic Admin</MenuItem>
              <MenuItem value="User">User</MenuItem>

            </Select>
          </FormControl>
          <TextField
          label="Managing Admin"
          placeholder="Managing Admin"
          fullWidth
          margin="normal"
          value={formData.managing_admin}
          onChange={(e) => handleFormChange('managing_admin', e.target.value)}
          />
          </form>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowForm(false)} color="primary">
            Close
          </Button>
          <Button variant="contained" startIcon={<PersonAddAlt1Icon />} onClick={isEditing ? handleSave : handleAddAdmin}>
            {isEditing ? 'Save Changes' : 'Add Admin'}
          </Button>
        </DialogActions>
      </Dialog>


      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center',justifyContent: 'space-around' }} mt={2} mb={5}>
        <Grid item xs={3}>
          <StyledFormControl>
            <InputLabel id="select-label-1">Role</InputLabel>
            <Select
              labelId="select-label-1"
              id="select-1"
              value={selectedValues.select1}
              label="Status"
              onChange={(event) => handleChange(event, 'select1')}
            > 
              <MenuItem value="">All</MenuItem>
              <MenuItem value="Doctor Admin">Doctor Admin</MenuItem>
              <MenuItem value="Hospital Admin">Hospital Admin</MenuItem>
              <MenuItem value="Ambulance Admin">Ambulance Admin</MenuItem>
              <MenuItem value="Clinic Admin">Clinic Admin</MenuItem>
              <MenuItem value="Diagnostic Admin">Diagnostic Admin</MenuItem>
              <MenuItem value="User">User</MenuItem>
            </Select>
          </StyledFormControl>
        </Grid>

        <Grid item xs={2}>
          {/* You can add additional Select components here if needed */}
        </Grid>

        <Grid item xs={4}>
          <TextField
            label="Search UserName"
            placeholder="Search UserName"
            variant="outlined"
            fullWidth
            margin="normal"
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              )
            }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Grid>
      </Grid>

      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell align="center">Admin ID</StyledTableCell>
              <StyledTableCell align="center">User Name</StyledTableCell>
              <StyledTableCell align="center">password</StyledTableCell>
              <StyledTableCell align="center"> Primary Name</StyledTableCell>
              <StyledTableCell align="center">Secondary Name</StyledTableCell>
              <StyledTableCell align="center">Email</StyledTableCell>
              <StyledTableCell align="center">Contact Number</StyledTableCell>
              <StyledTableCell align="center">role</StyledTableCell>
              <StyledTableCell align="center">Managing Admin</StyledTableCell>
              <StyledTableCell align="center">Action</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.length > 0 ? (
              filteredRows.map((row) => (
                <StyledTableRow key={row.adminID}>
                  <StyledTableCell align="center" component="th" scope="row">
                    {row.adminID}
                  </StyledTableCell>
                  <StyledTableCell align="center">{row.username}</StyledTableCell>
                  <StyledTableCell align="center">{row.password}</StyledTableCell>
                  <StyledTableCell align="center">{row.Primary_name}</StyledTableCell>
                  <StyledTableCell align="center">{row.Secondary_name}</StyledTableCell>
                  <StyledTableCell align="center">{row.email}</StyledTableCell>
                  <StyledTableCell align="center">{row.contact_number}</StyledTableCell>
                  <StyledTableCell align="center">{row.role}</StyledTableCell>
                  <StyledTableCell align="center">{row.managing_admin}</StyledTableCell>

                  <StyledTableCell>
                  <IconButton
                    aria-label="actions"
                    aria-controls={`actions-menu-${row.adminID}`}
                    aria-haspopup="true"
                    onClick={(event) => handleMenuClick(event, row.adminID)}
                  >
                    <MenuItem onClick={() => handleEdit(row.adminID, row.username, row.password, row.Primary_name, row.Secondary_name, row.email, row.contact_number, row.role, row.managing_admin)}>
                      <FaEdit style={{ color: 'blue' }} />
                    </MenuItem>
                    <Menu
                    id={`actions-menu-${row.adminID}`}
                    anchorEl={anchorElMap[row.adminID]}
                    keepMounted
                    open={Boolean(anchorElMap[row.adminID])}
                    onClose={() => handleMenuClose(row.adminID)}
                  >
                  </Menu>
                    <MenuItem onClick={() => handleRemove(row.adminID)}>
                      <FaTrash style={{ color: 'red' }} />
                    </MenuItem>
                  </IconButton>
                </StyledTableCell>

                </StyledTableRow>
              ))
            ) : (
              <StyledTableRow>
                <StyledTableCell colSpan={6} align="center">
                  No matching records found.
                </StyledTableCell>
              </StyledTableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      
    </>
          )}
          </>
  );
}
