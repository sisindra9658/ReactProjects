import React, { useState, useEffect, Suspense } from 'react';
import {
  List,
  Button,
  TextField,
  IconButton,
  Grid,
  Typography,
  Paper,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { FormControl, InputLabel, Select, MenuItem} from '@mui/material';

const HospitalDropdown = () => {
  const [selectedHospital, setSelectedHospital] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [hospitals, setHospitals] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState(null);
  const [renderedComponent, setRenderedComponent] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [editedDetails, setEditedDetails] = useState({
    clinic_name: '',
    city: '',
    country: '',
    clinic_address: '',
    website: '',
    contact_number: '',
    email: '',
    tagline: '',
    year_establishment_branch: '',
    appointment_booking_facility: '',
    mode_of_payment_cash: '',
    mode_of_payment_credit_card: '',
    mode_of_payment_cheque: '',
    mode_of_payment_debit_card: '',
    mode_of_payment_online: '',
    about_the_clinic: '',
    timings: '',
    insurance_providers_associated: '',
    emergency_phone_number: '',
    emergency_procedures: '',
    rating: '',
    Specialities: '',
    services: '',
    filename: '',
    video_filename: '',
    Op_Timings: '',
    Services_1: '' 
  });

  const [specializationOptions] = useState([
    'Cardiologist',
    'Dermatologist',
    'Endocrinologist',
    'Gastroenterologist',
  ]);

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/Clinics/list');
        if (!response.ok) {
          throw new Error(`Failed to fetch hospital names. Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Fetched clinic:', data);

        setHospitals(data);

        if (data.length > 0) {
          handleHospitalClick(data[0]);
        }
      } catch (error) {
        console.error('Error fetching hospital names:', error);
      }
    };

    fetchHospitals();
  }, []);

  const fetchHospitalDetails = async (clinicName) => {
  try {
    const response = await fetch(`http://localhost:5000/api/clinicDetails?name=${encodeURIComponent(clinicName)}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch clinic details. Status: ${response.status}`);
    }
    const data = await response.json();

    return data.clinicDetails; // Assuming the server response has a 'hospitalDetails' property
  } catch (error) {
    console.error('Error fetching clinic details:', error);
    throw error; // Re-throw the error to handle it in the calling function if needed
  }
};

const handleHospitalClick = async (hospital) => {
  console.log('Selected Hospital:', hospital);
  setSelectedHospital(hospital);
  setRenderedComponent(null);

  try {
    const details = await fetchHospitalDetails(hospital.clinic_name);
    setHospitalDetails(details);
  } catch (error) {
    console.error('Error in handleHospitalClick:', error);
  }
};

const performSearch = () => {
  return hospitals
    ? hospitals.filter(
        (hospital) =>
          hospital &&
          hospital.clinic_name &&
          searchTerm &&
          hospital.clinic_name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];
};

  const handleSearch = () => {
    const filteredHospitals = performSearch();
    console.log('Filtered Hospitals:', filteredHospitals);
  };

  const handleEnterKey = (event) => {
    if (event.key === 'Enter') {
      const filteredHospitals = performSearch();
      console.log('Filtered Hospitals on Enter:', filteredHospitals);
    }
  };

  const handleEditClick = async () => {
    setIsEditing(true);
  
    try {
      // Fetch detailed information for the selected hospital
      const details = await fetchHospitalDetails(selectedHospital.clinic_name);
  
      // Set the editedDetails with both the selectedHospital and detailed information
      setEditedDetails({
        ...selectedHospital,
        ...details,
      });
    } catch (error) {
      console.error('Error in handleEditClick:', error);
    }
  };
  

  const handleSaveEdit = async () => {
    try {
      // Send a request to update the hospital details
      const response = await fetch(`http://localhost:5000/api/clinics/${selectedHospital.clinic_name}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedDetails),
      });

      if (!response.ok) {
        throw new Error(`Failed to update clinic details. Status: ${response.status}`);
      }

      // If the update is successful, refresh the hospital details
      const updatedDetails = await fetchHospitalDetails(selectedHospital.clinic_name);
      setHospitalDetails(updatedDetails);

      setIsEditing(false);
    } catch (error) {
      console.error('Error updating clinic details:', error);
    }
  };

  // const handleDelete = async () => {
  //   try {
  //     // Send a request to delete the hospital
  //     const response = await fetch(`http://localhost:5000/api/hospitals/${selectedHospital.HospitalFullName}`, {
  //       method: 'DELETE',
  //     });

  //     if (!response.ok) {
  //       throw new Error(`Failed to delete hospital. Status: ${response.status}`);
  //     }

  //     // After successful deletion, reset selectedHospital and hospitalDetails
  //     setSelectedHospital(null);
  //     setHospitalDetails(null);
  //   } catch (error) {
  //     console.error('Error deleting hospital:', error);
  //   }
  // };

  return (
    <>
    {hospitals.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <div>
      <h1 style={{ display: 'flex', justifyContent: 'center', color: '#00ab9f', marginTop: '20px', marginBottom: '30px' }}>
        Select Clinic For Details
      </h1>
      <Grid container spacing={2}>
        <Grid item xs={2}>
          <TextField
            label="Search Clinic"
            placeholder="Search Clinic"
            variant="outlined"
            fullWidth
            margin="normal"
            size="small"
            style={{ width: '100%' }}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              ),
            }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleEnterKey}
          />
          <List>
            {performSearch().map((hospital, index) => (
              <Button
                key={index}
                onClick={() => handleHospitalClick(hospital)}
                variant="outlined"
                style={{
                  display: 'block',
                  width: '100%',
                  padding: '8px',
                  marginBottom: '8px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  background: 'white',
                  textAlign: 'left',
                  cursor: 'pointer',
                }}
              >
                {hospital.clinic_name}
              </Button>
            ))}
          </List>
          <div  style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <List>
              {hospitals.map((hospital, index) => (
                <Button
                  key={index}
                  onClick={() => handleHospitalClick(hospital)}
                  variant="outlined"
                  style={{
                    display: 'block',
                    width: '100%',
                    padding: '8px',
                    marginBottom: '8px',
                    background: 'white',
                    fontSize:'10px',
                    textAlign: 'left',
                    cursor: 'pointer',
                    backgroundColor: selectedHospital === hospital ? '#00ab9f' : 'transparent',
                    color: selectedHospital === hospital ? 'white' : 'black',
                  }}
                >
                  {hospital.clinic_name}
                </Button>
              ))}
            </List>
          </div>
        </Grid>
        <Grid item xs={10}>
          {selectedHospital && (
            <div>
              <Suspense fallback={<div>Loading...</div>}>
                <Paper elevation={3} style={{ padding: '20px', marginBottom: '20px' }}>
                  <div>
                  <Typography variant={isEditing ? "h4" : "h6"} style={{ fontSize: isEditing ? "24px" : "inherit", marginBottom: "20px"  }}>
                    {isEditing ? 'Edit Clinic Details' : ''}
                  </Typography>

                    {isEditing ? (
                      <div>
              <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
              <TextField label="Clinic Name" name="clinic_name" value={editedDetails.clinic_name} onChange={(e) => setEditedDetails({ ...editedDetails, clinic_name: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="City" name="city" value={editedDetails.city} onChange={(e) => setEditedDetails({ ...editedDetails, city: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Country" name="country" value={editedDetails.country} onChange={(e) => setEditedDetails({ ...editedDetails, country: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="clinic_address" name="clinic_address" value={editedDetails.clinic_address} onChange={(e) => setEditedDetails({ ...editedDetails, clinic_address: e.target.value })} fullWidth />
              </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Website" name="website" value={editedDetails.website} onChange={(e) => setEditedDetails({ ...editedDetails, Website: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="contact_number" name="contact_number" value={editedDetails.contact_number} onChange={(e) => setEditedDetails({ ...editedDetails, contact_number: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="email" name="email" value={editedDetails.email} onChange={(e) => setEditedDetails({ ...editedDetails, email: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="tagline" name="tagline" value={editedDetails.tagline} onChange={(e) => setEditedDetails({ ...editedDetails, tagline: e.target.value })} fullWidth />
                </Grid> 
                <Grid item xs={12} sm={6}>
                  <TextField label="YearOfEstablishmentBranch" name="year_establishment_branch" value={editedDetails.year_establishment_branch} onChange={(e) => setEditedDetails({ ...editedDetails, year_establishment_branch: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="appointment-booking-facility-label">Appointment Booking Facility</InputLabel>
                  <Select
                    labelId="appointment-booking-facility-label"
                    id="appointment-booking-facility"
                    name="appointment_booking_facility"
                    value={editedDetails.appointment_booking_facility} 
                    onChange={(e) => setEditedDetails({ ...editedDetails, appointment_booking_facility: e.target.value })}
                    fullWidth
                  >
                    <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="mode-of-payment-cash-label">mode of payment cash</InputLabel>
                  <Select
                    labelId="mode-of-payment-cash-label"
                    id="mode-of-payment-cash"
                    name="mode_of_payment_cash"
                    value={editedDetails.mode_of_payment_cash} 
                    onChange={(e) => setEditedDetails({ ...editedDetails, mode_of_payment_cash: e.target.value })}
                    fullWidth
                  >
                    <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="mode-of-payment-credit-card-label">mode of payment credit card</InputLabel>
                  <Select
                    labelId="mode-of-payment-credit-card-label"                  
                    id="mode-of-payment-credit-card"
                    name="mode_of_payment_credit_card"
                    value={editedDetails.mode_of_payment_credit_card} 
                    onChange={(e) => setEditedDetails({ ...editedDetails, mode_of_payment_credit_card: e.target.value })}
                    fullWidth
                  >
                    <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="mode-of-payment-cheque-label">Appointment Booking Facility</InputLabel>
                  <Select
                    labelId="mode-of-payment-cheque-label"
                    id="mode-of-payment-cheque"
                    name="mode_of_payment_cheque"
                    value={editedDetails.mode_of_payment_cheque} 
                    onChange={(e) => setEditedDetails({ ...editedDetails, mode_of_payment_cheque: e.target.value })}
                    fullWidth
                  >
                    <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="mode-of-payment-debit-card-label">mode of payment debit card</InputLabel>
                  <Select
                    labelId="mode-of-payment-debit-card-label"
                    id="mode-of-payment-debit-card"
                    name="mode_of_payment_debit_card"
                    value={editedDetails.mode_of_payment_debit_card} 
                    onChange={(e) => setEditedDetails({ ...editedDetails, mode_of_payment_debit_card: e.target.value })}
                    fullWidth
                  >
                    <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="mode-of-payment-online-label">mode of payment online</InputLabel>
                  <Select
                    labelId="mode-of-payment-online-label"
                    id="mode-of-payment-online"
                    name="mode_of_payment_online"
                    value={editedDetails.mode_of_payment_online} 
                    onChange={(e) => setEditedDetails({ ...editedDetails, mode_of_payment_online: e.target.value })}
                    fullWidth
                  >
                    <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Insurance Providers Associated" name="insurance_providers_associated" value={editedDetails.insurance_providers_associated} onChange={(e) => setEditedDetails({ ...editedDetails, insurance_providers_associated: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="EmergencyPhoneNumber" name="emergency_phone_number" value={editedDetails.emergency_phone_number} onChange={(e) => setEditedDetails({ ...editedDetails, emergency_phone_number: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="emergency_procedures" name="emergency_procedures" value={editedDetails.emergency_procedures} onChange={(e) => setEditedDetails({ ...editedDetails, emergency_procedures: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="rating" name="rating" value={editedDetails.rating} onChange={(e) => setEditedDetails({ ...editedDetails, rating: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel id="Specialities-label">Specialities</InputLabel>
                  <Select
                    labelId="Specialities-label"
                    id="Specialities"
                    name="Specialities"
                    value={editedDetails.Specialities}
                    onChange={(e) => setEditedDetails({ ...editedDetails, Specialities: e.target.value })}
                    label="Specialities"
                  >
                    {specializationOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="services" name="services" value={editedDetails.services} onChange={(e) => setEditedDetails({ ...editedDetails, services: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="Services_1" name="Services_1" value={editedDetails.Services_1} onChange={(e) => setEditedDetails({ ...editedDetails, Services_1: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="about_the_clinic" name="about_the_clinic" value={editedDetails.about_the_clinic} onChange={(e) => setEditedDetails({ ...editedDetails, about_the_clinic: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="Op_Timings" name="Op_Timings" value={editedDetails.Op_Timings} onChange={(e) => setEditedDetails({ ...editedDetails, Op_Timings: e.target.value })} fullWidth />       
               </Grid>
               <Grid item xs={12} sm={6}>
              <TextField label="Shift Timing" name="timings" value={editedDetails.timings} onChange={(e) => setEditedDetails({ ...editedDetails, timings: e.target.value })} fullWidth />       
               </Grid>   
               {/* <h2>Upload Photo</h2> */}
              <Grid container spacing={2} alignItems="center">
                {/* <Grid item xs={6} sm={3}>
                  <input type="file" name="filename"  onChange={(e)=>{handleUpload(e),handleChange(e)}} accept="uploads/*" />
                </Grid> */}
                {/* <Grid item xs={6} sm={3}>
                  {editedDetails.filename && (
                    <Box display="flex" alignItems="center">
                      <img
                        src={URL.createObjectURL(editedDetails.filename)}
                        alt="Doctor"
                        style={{ width: '50px', height: '50px', borderRadius: '10%', marginRight: '8px' }}
                      />
                      <Button variant="outlined" color="error" onClick={handleRemovePhoto}>
                        Remove
                      </Button>
                    </Box>
                  )}
                </Grid> */}
              </Grid>        
              <Grid item xs={12} sm={6}>
                </Grid>
              </Grid>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop:'25px', marginBottom:'25px'}}>
                <Button onClick={handleSaveEdit} variant="contained" color="primary">
                  Save Changes
                </Button>
              </div>

                        {/* <Button onClick={handleDelete} variant="contained" color="secondary">
                          Delete
                        </Button> */}
                      </div>
                    ) : (
                      <>
                        {/* ... (Your existing JSX) */}
                        <Button onClick={handleEditClick} variant="contained" color="primary" style={{marginLeft:'auto', display:'flex'}}>
                          Edit Clinic Details
                        </Button>
                      </>
                    )}
                    {hospitalDetails && (
                      <div>
                        <Grid container spacing={2}>
                        {Object.entries(hospitalDetails).map(([key, value], index) => (
                        <React.Fragment key={index}>
                                <Grid item xs={5} key={key}>
                                <Typography variant="h6"> <h3 style={{color:'black'}}>{key} :</h3></Typography>
                              </Grid>
                              <Grid item xs={7} key={key}>
                                <Typography><h5>{value}</h5></Typography>
                              </Grid>
                        </React.Fragment>
                      ))}

                        </Grid>
                      </div>
                    )}
                    {renderedComponent}
                  </div>
                </Paper>
              </Suspense>
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  )}
  </>
  );
};

export default HospitalDropdown;
