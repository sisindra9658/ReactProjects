import React, { useState, useEffect, Suspense } from 'react';
import {
  List,
  Button,
  TextField,
  IconButton,
  Grid,
  Typography,
  Paper,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

const HospitalDropdown = () => {
  const [selectedHospital, setSelectedHospital] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [hospitals, setHospitals] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState(null);
  const [renderedComponent, setRenderedComponent] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [editedDetails, setEditedDetails] = useState({
    HospitalFullName: '',
    AuthorisedPerson: '',
    PrimaryAppointmentContactNumber: '',
    SecondaryAppointmentContactNumber: '',
    PrimaryEmail: '',
    SecondaryEmail: '',
    City: '',
    Country: '',
    Address: '',
    Website: '',
    Tagline: '',
    YearOfEstablishmentBranch: '',  
    YearOfEstablishmentGroup: '',
    AppointmentBookingFacility: '',
    Cash:'',
    CreditCard: '',
    Cheque: '',
    DebitCard: '',
    OnlinePayment: '',
    AboutTheHospital: '',
    Days: '',
    StartTime: '',
    EndTime: '',
    NameOfInsuranceProvidersAssociated: '',
    EmergencyPhoneNumber: '',
    NumberOfAmbulances: '',
    Bloodbank: '',
    AwardName: '',
    AwardingYear: '',
    CouncilName: '',
    ValidUpto: '',
    Type: '',
    NumberOfDoctors: '',
    NoOfBeds: '',
    Facilities: '',
    Specialities: '',
    EmergencyProcedures: '',
    AboutEmergencyServices: ''  
  });

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/Hospitals/list');
        if (!response.ok) {
          throw new Error(`Failed to fetch hospital names. Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Fetched Hospitals:', data);

        setHospitals(data);

        if (data.length > 0) {
          handleHospitalClick(data[0]);
        }
      } catch (error) {
        console.error('Error fetching hospital names:', error);
      }
    };

    fetchHospitals();
  }, []);

  const fetchHospitalDetails = async (hospitalName) => {
    try {
      const response = await fetch(`http://localhost:5000/api/hospitalDetails?name=${encodeURIComponent(hospitalName)}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch hospital details. Status: ${response.status}`);
      }
      const data = await response.json();

      return data.hospitalDetails;
    } catch (error) {
      console.error('Error fetching hospital details:', error);
      throw error;
    }
  };

  const handleHospitalClick = async (hospital) => {
    console.log('Selected Hospital:', hospital);
    setSelectedHospital(hospital);
    setRenderedComponent(null);

    try {
      const details = await fetchHospitalDetails(hospital.HospitalFullName);
      setHospitalDetails(details);
    } catch (error) {
      console.error('Error in handleHospitalClick:', error);
    }
  };

  const performSearch = () => {
    return hospitals
      ? hospitals.filter(
          (hospital) =>
            hospital &&
            hospital.HospitalFullName &&
            searchTerm &&
            hospital.HospitalFullName.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : [];
  };

  const handleSearch = () => {
    const filteredHospitals = performSearch();
    console.log('Filtered Hospitals:', filteredHospitals);
  };

  const handleEnterKey = (event) => {
    if (event.key === 'Enter') {
      const filteredHospitals = performSearch();
      console.log('Filtered Hospitals on Enter:', filteredHospitals);
    }
  };

  const handleEditClick = async () => {
    setIsEditing(true);
  
    try {
      // Fetch detailed information for the selected hospital
      const details = await fetchHospitalDetails(selectedHospital.HospitalFullName);
  
      // Set the editedDetails with both the selectedHospital and detailed information
      setEditedDetails({
        ...selectedHospital,
        ...details,
      });
    } catch (error) {
      console.error('Error in handleEditClick:', error);
    }
  };
  

  const handleSaveEdit = async () => {
    try {
      // Send a request to update the hospital details
      const response = await fetch(`http://localhost:5000/api/hospitals/${selectedHospital.HospitalFullName}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedDetails),
      });

      if (!response.ok) {
        throw new Error(`Failed to update hospital details. Status: ${response.status}`);
      }

      // If the update is successful, refresh the hospital details
      const updatedDetails = await fetchHospitalDetails(selectedHospital.HospitalFullName);
      setHospitalDetails(updatedDetails);

      setIsEditing(false);
    } catch (error) {
      console.error('Error updating hospital details:', error);
    }
  };

  // const handleDelete = async () => {
  //   try {
  //     // Send a request to delete the hospital
  //     const response = await fetch(`http://localhost:5000/api/hospitals/${selectedHospital.HospitalFullName}`, {
  //       method: 'DELETE',
  //     });

  //     if (!response.ok) {
  //       throw new Error(`Failed to delete hospital. Status: ${response.status}`);
  //     }

  //     // After successful deletion, reset selectedHospital and hospitalDetails
  //     setSelectedHospital(null);
  //     setHospitalDetails(null);
  //   } catch (error) {
  //     console.error('Error deleting hospital:', error);
  //   }
  // };

  return (
    <>
    {hospitals.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <div>
      <h1 style={{ display: 'flex', justifyContent: 'center', color: '#00ab9f', marginTop: '20px', marginBottom: '30px' }}>
        Select Hospital For Details
      </h1>
      <Grid container spacing={2}>
        <Grid item xs={2}>
          <TextField
            label="Search Hospital"
            placeholder="Search Hospital"
            variant="outlined"
            fullWidth
            margin="normal"
            size="small"
            style={{ width: '100%' }}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              ),
            }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleEnterKey}
          />
          <List>
            {performSearch().map((hospital, index) => (
              <Button
                key={index}
                onClick={() => handleHospitalClick(hospital)}
                variant="outlined"
                style={{
                  display: 'block',
                  width: '100%',
                  padding: '8px',
                  marginBottom: '8px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  background: 'white',
                  textAlign: 'left',
                  cursor: 'pointer',
                }}
              >
                {hospital.HospitalFullName}
              </Button>
            ))}
          </List>
          <div  style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <List>
              {hospitals.map((hospital, index) => (
                <Button
                  key={index}
                  onClick={() => handleHospitalClick(hospital)}
                  variant="outlined"
                  style={{
                    display: 'block',
                    width: '100%',
                    fontSize:'10px',
                    padding: '8px',
                    marginBottom: '8px',
                    background: 'white',
                    textAlign: 'left',
                    cursor: 'pointer',
                    backgroundColor: selectedHospital === hospital ? '#00ab9f' : 'transparent',
                    color: selectedHospital === hospital ? 'white' : 'black',
                  }}
                >
                  {hospital.HospitalFullName}
                </Button>
              ))}
            </List>
          </div>
        </Grid>
        <Grid item xs={10}>
          {selectedHospital && (
            <div>
              <Suspense fallback={<div>Loading...</div>}>
                <Paper elevation={3} style={{ padding: '20px', marginBottom: '20px' }}>
                  <div>
                  <Typography variant={isEditing ? "h4" : "h6"} style={{ fontSize: isEditing ? "24px" : "inherit", marginBottom: "20px"  }}>
                    {isEditing ? 'Edit Hospital Details' : ''}
                  </Typography>

                    {isEditing ? (
                      <div>
                           <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                  <TextField label="HospitalFullName" name="HospitalFullName" value={editedDetails.HospitalFullName} onChange={(e) => setEditedDetails({ ...editedDetails, HospitalFullName: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="AuthorisedPerson" name="AuthorisedPerson" value={editedDetails.AuthorisedPerson} onChange={(e) => setEditedDetails({ ...editedDetails, AuthorisedPerson: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="PrimaryAppointmentContactNumber" name="PrimaryAppointmentContactNumber" value={editedDetails.PrimaryAppointmentContactNumber} onChange={(e) => setEditedDetails({ ...editedDetails, PrimaryAppointmentContactNumber: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="SecondaryAppointmentContactNumber" name="SecondaryAppointmentContactNumber" value={editedDetails.SecondaryAppointmentContactNumber} onChange={(e) => setEditedDetails({ ...editedDetails, SecondaryAppointmentContactNumber: e.target.value })} fullWidth />
              </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="PrimaryEmail" name="PrimaryEmail" value={editedDetails.PrimaryEmail} onChange={(e) => setEditedDetails({ ...editedDetails, PrimaryEmail: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="SecondaryEmail" name="SecondaryEmail" value={editedDetails.SecondaryEmail} onChange={(e) => setEditedDetails({ ...editedDetails, SecondaryEmail: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="City" name="City" value={editedDetails.City} onChange={(e) => setEditedDetails({ ...editedDetails, City: e.target.value })} fullWidth />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Country" name="Country" value={editedDetails.Country} onChange={(e) => setEditedDetails({ ...editedDetails, Country: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Address" name="Address" value={editedDetails.Address} onChange={(e) => setEditedDetails({ ...editedDetails, Address: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Website" name="Website" value={editedDetails.Website} onChange={(e) => setEditedDetails({ ...editedDetails, Website: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Tagline" name="Tagline" value={editedDetails.Tagline} onChange={(e) => setEditedDetails({ ...editedDetails, Tagline: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="YearOfEstablishmentBranch" name="YearOfEstablishmentBranch" value={editedDetails.YearOfEstablishmentBranch} onChange={(e) => setEditedDetails({ ...editedDetails, YearOfEstablishmentBranch: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="YearOfEstablishmentGroup" name="YearOfEstablishmentGroup" value={editedDetails.YearOfEstablishmentGroup} onChange={(e) => setEditedDetails({ ...editedDetails, YearOfEstablishmentGroup: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="AppointmentBookingFacility" name="AppointmentBookingFacility" value={editedDetails.AppointmentBookingFacility} onChange={(e) => setEditedDetails({ ...editedDetails, AppointmentBookingFacility: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Cash" name="Cash" value={editedDetails.Cash} onChange={(e) => setEditedDetails({ ...editedDetails, Cash: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="CreditCard" name="CreditCard" value={editedDetails.CreditCard} onChange={(e) => setEditedDetails({ ...editedDetails, CreditCard: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Cheque" name="Cheque" value={editedDetails.Cheque} onChange={(e) => setEditedDetails({ ...editedDetails, Cheque: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="DebitCard" name="DebitCard" value={editedDetails.DebitCard} onChange={(e) => setEditedDetails({ ...editedDetails, DebitCard: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="OnlinePayment" name="OnlinePayment" value={editedDetails.OnlinePayment} onChange={(e) => setEditedDetails({ ...editedDetails, OnlinePayment: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="AboutTheHospital" name="AboutTheHospital" value={editedDetails.AboutTheHospital} onChange={(e) => setEditedDetails({ ...editedDetails, AboutTheHospital: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="Days" name="Days" value={editedDetails.Days} onChange={(e) => setEditedDetails({ ...editedDetails, Days: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField
                    label="StartTime"
                    type="Time"
                    name='StartTime'
                    value={editedDetails.StartTime}
                    onChange={(e) => setEditedDetails({ ...editedDetails, StartTime: e.target.value })}
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{
                      step: 300
                    }}
                    fullWidth
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField
                    label="EndTime"
                    type="Time"
                    name='EndTime'
                    value={editedDetails.EndTime}
                    onChange={(e) => setEditedDetails({ ...editedDetails, EndTime: e.target.value })}
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{
                      step: 300
                    }}
                    fullWidth
                  />  
                  </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="NameOfInsuranceProvidersAssociated" name="NameOfInsuranceProvidersAssociated" value={editedDetails.NameOfInsuranceProvidersAssociated} onChange={(e) => setEditedDetails({ ...editedDetails, HospitalFullName: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="EmergencyPhoneNumber" name="EmergencyPhoneNumber" value={editedDetails.EmergencyPhoneNumber} onChange={(e) => setEditedDetails({ ...editedDetails, EmergencyPhoneNumber: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="NumberOfAmbulances" name="NumberOfAmbulances" value={editedDetails.NumberOfAmbulances} onChange={(e) => setEditedDetails({ ...editedDetails, NumberOfAmbulances: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Bloodbank" name="Bloodbank" value={editedDetails.Bloodbank} onChange={(e) => setEditedDetails({ ...editedDetails, Bloodbank: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="AwardName" name="AwardName" value={editedDetails.AwardName} onChange={(e) => setEditedDetails({ ...editedDetails, AwardName: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="AwardingYear" name="AwardingYear" value={editedDetails.AwardingYear} onChange={(e) => setEditedDetails({ ...editedDetails, AwardingYear: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="CouncilName" name="CouncilName" value={editedDetails.CouncilName} onChange={(e) => setEditedDetails({ ...editedDetails, CouncilName: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="ValidUpto" name="ValidUpto" value={editedDetails.ValidUpto} onChange={(e) => setEditedDetails({ ...editedDetails, ValidUpto: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                  <TextField label="Type" name="Type" value={editedDetails.Type} onChange={(e) => setEditedDetails({ ...editedDetails, Type: e.target.value })} fullWidth />
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="NumberOfDoctors" name="NumberOfDoctors" value={editedDetails.NumberOfDoctors} onChange={(e) => setEditedDetails({ ...editedDetails, NumberOfDoctors: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="NoOfBeds" name="NoOfBeds" value={editedDetails.NoOfBeds} onChange={(e) => setEditedDetails({ ...editedDetails, NoOfBeds: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="Facilities" name="Facilities" value={editedDetails.Facilities} onChange={(e) => setEditedDetails({ ...editedDetails, Facilities: e.target.value })} fullWidth />       
                </Grid>
 
                <Grid item xs={12} sm={6}>
                <TextField label="Specialities" name="Specialities" value={editedDetails.Specialities} onChange={(e) => setEditedDetails({ ...editedDetails, Specialities: e.target.value })} fullWidth />       
                </Grid>
              <Grid item xs={12} sm={6}>
              <TextField label="EmergencyProcedures" name="EmergencyProcedures" value={editedDetails.EmergencyProcedures} onChange={(e) => setEditedDetails({ ...editedDetails, EmergencyProcedures: e.target.value })} fullWidth />       
               </Grid>
                <Grid item xs={12} sm={6}>
                <TextField label="AboutEmergencyServices" name="AboutEmergencyServices" value={editedDetails.AboutEmergencyServices} onChange={(e) => setEditedDetails({ ...editedDetails, AboutEmergencyServices: e.target.value })} fullWidth />       
                </Grid>
                <Grid item xs={12} sm={6}>
                </Grid>
 
                <Grid item xs={12} sm={6}>
                </Grid>
                </Grid>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop:'25px', marginBottom:'25px'}}>
                <Button onClick={handleSaveEdit} variant="contained" color="primary">
                  Save Changes
                </Button>
              </div>

                        {/* <Button onClick={handleDelete} variant="contained" color="secondary">
                          Delete
                        </Button> */}
                      </div>
                    ) : (
                      <>
                        {/* ... (Your existing JSX) */}
                        <Button onClick={handleEditClick} variant="contained" color="primary" style={{marginLeft:'auto', display:'flex'}}>
                          Edit Hospital Details
                        </Button>
                      </>
                    )}
                    {hospitalDetails && (
                      <div>
                        <Grid container spacing={2}>
                          {Object.entries(hospitalDetails).map(([key, value]) => (
                            <>
                              <Grid item xs={5} key={key}>
                                <Typography variant="h6"> <h3 style={{color:'black'}}>{key} :</h3></Typography>
                              </Grid>
                              <Grid item xs={7} key={key}>
                                <Typography><h5>{value}</h5></Typography>
                              </Grid>
                            </>
                          ))}
                        </Grid>
                      </div>
                    )}
                    {renderedComponent}
                  </div>
                </Paper>
              </Suspense>
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  )}
  </>
  );
};

export default HospitalDropdown;
