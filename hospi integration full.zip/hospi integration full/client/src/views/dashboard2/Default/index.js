 import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import {Box,IconButton,Typography,Button, Popover} from '@mui/material';
import axios from 'axios'; 
import { Calendar, momentLocalizer } from 'react-big-calendar';
import "./index1.css"

import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import GroupIcon from '@mui/icons-material/Group';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import EditIcon from '@mui/icons-material/Edit';
import React, { useState, useEffect } from 'react';
import {Grid} from '@mui/material';
const localizer = momentLocalizer(moment);


// const fetchDoctorImage = async (doctorName) => {
//   try {
//     const response = await axios.get(`http://localhost:5000/api/get-image/${doctorName}`);
//     return response.data.imageUrl;
//   } catch (error) {
//     console.error('Error fetching doctor image:', error);
//     return null;
//   }
// };

const Dashboard = () => {
  const [anchorEl, setAnchorEl] = useState(null);
 
  const today = new Date();
  const customDayPropGetter = (date) => {
    if (moment(date).isSame(today, 'day')) {
      return {
        style: {
          backgroundColor: '#00ff00', // Green color for today's date
        },
      };
    }
    return {};
  };
 
 
   const [doctorInfo] = useState({
        name: '',
        email: '',
        contact: '',
        specialization: '',
        appointments: ''
    });
 
  const handleLogout = () => {
    console.log('Logged out');
    handleProfileClose();
  };
 
  const handleProfileClose = () => {
    setAnchorEl(null);
  };
 
  const open = Boolean(anchorEl);
  const id = open ? 'profile-popover' : undefined;
 
  const [totalPatients1, setTotalPatients1] = useState(null);
  const [bookingDatesByMonth, setBookingDatesByMonth] = useState([]);

  useEffect(() => {
    fetchBookingDatesByMonth();
  }, []);

  const fetchBookingDatesByMonth = async () => {
    try {
      const username = localStorage.getItem('username');
      const response = await axios.get(`http://localhost:5000/api/hospital-details/get-booking-dates-by-month/${username}`);
      
      if (response.data && response.data.bookingDatesByMonth) {
        setBookingDatesByMonth(response.data.bookingDatesByMonth);
      }
    } catch (error) {
      console.error('Error fetching booking dates by month:', error);
    }
  };
 
  const [genderData, setGenderData] = useState([]);

  useEffect(() => {
    fetchGenderData();
  }, []);

  const fetchGenderData = async () => {
      try {
        const username = localStorage.getItem('username');
        const response = await axios.get(`http://localhost:5000/api/hospital-details/gender-count/${username}`);
        
        if (response.data && response.data.genderData) {
          setGenderData(response.data.genderData);
        }
      } catch (error) {
        console.error('Error fetching gerder count:', error);
      }
    };

  // const [managingAdminDetails, setManagingAdminDetails] = useState(null);

  // useEffect(() => {
  //   fetchManagingAdminDetails();
  // }, []);

  // const fetchManagingAdminDetails = async () => {
  //   try {
  //     const username = localStorage.getItem('username');
  //     const response = await axios.get(`http://localhost:5000/api/hospital-details/doctoradmin/${username}`);
  //     setManagingAdminDetails(response.data);
  //   } catch (error) {
  //     console.error('Error fetching managing admin details:', error);
  //   }
  // };


  const [managingAdminDetails, setManagingAdminDetails] = useState([]);

  useEffect(() => {
    fetchManagingAdminDetails();
  }, []);

  const fetchManagingAdminDetails = async () => {
    try {
      const username = localStorage.getItem('username');
      const response = await axios.get(`http://localhost:5000/api/hospital-details/doctoradmin/${username}`);
      setManagingAdminDetails(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };


  const [managingAdminDetails1, setManagingAdminDetails1] = useState(null);

  useEffect(() => {
    fetchManagingAdminDoctor();
  }, []);

  const fetchManagingAdminDoctor = async () => {
    try {
      const username = localStorage.getItem('username'); // Assuming the username is stored in localStorage upon login
      const response = await axios.get(`http://localhost:5000/api/hospital-details/doctorname/${username}`);
      setManagingAdminDetails1(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };

  useEffect(() => {
    fetchManagingtotalpatients();
  }, []);

  const fetchManagingtotalpatients = async () => {
    try {
      const username = localStorage.getItem('username'); // Assuming the username is stored in localStorage upon login
      const response = await axios.get(`http://localhost:5000/api/hospital-details/totalpatients/${username}`);
      setTotalPatients1(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };

  
const [totalConfirmedPatients, setTotalConfirmedPatients] = useState(null);
 
 
useEffect(() => {
  fetchManagingconformed();
}, []);

const fetchManagingconformed = async () => {
  try {
    const username = localStorage.getItem('username'); // Assuming the username is stored in localStorage upon login
    const response = await axios.get(`http://localhost:5000/api/hospital-details/conformedstatus/${username}`);
    setTotalConfirmedPatients(response.data);
  } catch (error) {
    console.error('Error fetching managing admin details:', error);
  }
};
 
const [recent, setrecent] = useState(null);
 
 
useEffect(() => {
  fetchRecent();
}, []);

const fetchRecent = async () => {
  try {
    const username = localStorage.getItem('username'); // Assuming the username is stored in localStorage upon login
    const response = await axios.get(`http://localhost:5000/api/hospital-details/recentapt/${username}`);
    setrecent(response.data);
  } catch (error) {
    console.error('Error fetching managing admin details:', error);
  }
};



  return (
    <div style={{ marginLeft:'2%'}}>
    <Box   >
      <Box display="flex" justifyContent="space-between" alignItems="center" style={{ backgroundColor: '#F0F0F0', padding: '10px' }}>
      <Popover
  id={id}
  open={open}
  anchorEl={anchorEl}
  onClose={() => setAnchorEl(null)}
  anchorOrigin={{
    vertical: 'top',
    horizontal: 'center',
  }}
  transformOrigin={{
    vertical: 'bottom',
    horizontal: 'center',
  }}
>
  <Box p={2} display="flex" flexDirection="column" alignItems="center" bgcolor="white" color="black">
    <Box display="flex" alignItems="center" marginBottom="10px">
    <img
                    src={`http://localhost:5000/api/get-image/${doctorInfo.doctor_id}`}
                    alt={`Profile of ${doctorInfo.name}`}
                    style={{ width: "100%", maxWidth: "100px", height: "100px", marginLeft: "30px",borderRadius:'50%' }}
                    className="image-zoom"
                />
      <Box flexGrow={1} /> {/* Add flexible space to push the IconButton to the right */}
      <IconButton>
        <EditIcon />
      </IconButton>
    </Box>
    <Typography variant="h6" align="center" gutterBottom style={{ color: 'Black' }}>
      {doctorInfo.doctor_name}
    </Typography>
    <Typography variant="body1" gutterBottom style={{ color: 'Black' }}>
      <strong>Email:</strong> {doctorInfo.email}
    </Typography>
    <Typography variant="body1" gutterBottom style={{ color: 'Black' }}>
      <strong>Contact:</strong> {doctorInfo.mobile}
    </Typography>
    <Typography variant="body1" gutterBottom style={{ color: 'Black' }}>
      <strong>Specialization:</strong> {doctorInfo.specialization}
    </Typography>
    {/* <Typography variant="body1" gutterBottom style={{ color: 'Black' }}>
      <strong>Appointments:</strong> {doctorInfo.appointments}
    </Typography> */}
    <Button onClick={handleLogout} color="primary" variant="contained">
      Logout
    </Button>
  </Box>
</Popover>
 
</Box>
 
 
      {/* GRID & CHARTS */}
      <Box
        display="grid"
        gridTemplateColumns="repeat(12, 1fr)"
        gridAutoRows="140px"
        gap="10px"
     
      >
 
       
        {/* ROW 1 */}
       
        <Box
  gridColumn="span 8"
  gridRow="span 2"
  style={{
    backgroundColor: "#77bdf2",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    padding: "40px",
    display: "flex",
    alignItems: "center",
    width:"700px"
  }}
>
  <Box flex="1">
  {managingAdminDetails && managingAdminDetails.map((detail, index) => (
    <Grid key={index} >
      <div style={{ color: "#ffffff", textAlign: "left" }}>
        <h3 className='doctorh5'><p style={{ margin: 0 }}>Welcome Back,</p></h3>
        <h4 className='doctorh5' style={{ margin: 0 }}>{detail.doctor_name}</h4>
        <br />
        <h5 className='doctorh4' style={{ margin: 0 }}>{detail.specialization}</h5>
      </div>
      </Grid>
    ))}
      {managingAdminDetails1 && managingAdminDetails1.map((detail, index) => (
    <Grid key={index} >
        <h5 className='doctorh5'><p style={{ margin: 0 }}>You have total <span style={{ color: "#ffcc00" }}>{detail.count}</span> appointments today</p></h5>
      </Grid>
    ))}
  </Box>
  <div>
  {managingAdminDetails.map((doctor, index) => (
          <div key={index}>
            <h2>{doctor.doctor_name}</h2>
            <DoctorImage doctorName={doctor.filename} />
          </div>
        ))}
    </div>


</Box>
 
 
<Box
      gridColumn="span 4"
      gridRow="span 2"
      backgroundColor="#77bdf2"
      borderRadius="10px"
      boxShadow="0 4px 8px rgba(0, 0, 0, 0.1)"
      padding="20px"
     
    >
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Typography color="#ffffff" variant="h5" fontWeight="600" margin={"0 0 0 38%"}>
        Calendar
        </Typography>
      </Box>
      <Calendar
        localizer={localizer}
        events={[]}
        startAccessor="start"
        endAccessor="end"
        style={{ height: 250, padding: '5px' }}
        views={['month']}
        drilldownView={null}
        selectable={false}
        step={60}
        showMultiDayTimes
        dayPropGetter={customDayPropGetter}
      />
    </Box>
 
{/* {row2} */}  
<Box
  gridColumn="span 3"
  className="doctora1"
  display="flex"
  alignItems="center"
  justifyContent="center"
  flexDirection="column"
  borderRadius="12px"
  padding="20px"
  boxShadow="0px 4px 8px rgba(0, 0, 0, 0.1)"
>
  <GroupIcon  sx={{color: "#4caf50", fontSize: "40px", marginBottom: "10px",marginRight:"80%"}}/>
  {totalPatients1 && totalPatients1.map((detail, index) => (
    <div key={index} >
  <Typography color="#f5f5f5" variant="h4" fontWeight="600" marginBottom="10px">
        Total Patients
    </Typography>
        <h5 className='doctorh5'><p style={{ margin: 0 }}>{detail.total}</p></h5>
      </div>
    ))}
</Box>
    <Box
      gridColumn="span 3"
      className="doctora1"
      display="flex"
      alignItems="center"
      justifyContent="center"
      flexDirection="column"
      borderRadius="12px"
      padding="20px"
      boxShadow="0px 4px 8px rgba(0, 0, 0, 0.1)"
    >
      <MedicalServicesIcon sx={{ color: "#4caf50", fontSize: "40px", marginBottom: "10px",marginRight:"80%" }} />
      {totalConfirmedPatients && totalConfirmedPatients.map((detail, index) => (
    <div key={index} >
      <Typography color="#f5f5f5" variant="h4" fontWeight="600" marginBottom="10px">
        Consultations
      </Typography>
     <strong> <Typography color="#222831" variant="h3" fontWeight="600" fontSize={30}>
        {detail.confirmedPatientsCount}
      </Typography></strong>
      </div>
      ))}
    </Box>
 
         <Box
     gridColumn="span 3"
     className="doctora1"
     display="flex"
     alignItems="center"
     justifyContent="center"
     flexDirection="column"
     borderRadius="12px"
     padding="20px"
     boxShadow="0px 4px 8px rgba(0, 0, 0, 0.1)"
    >
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
       
        <CalendarTodayIcon sx={{ color: "#4caf50", fontSize: "40px", marginBottom: "10px",marginRight:"80%" }} />
        {managingAdminDetails1 && managingAdminDetails1.map((detail, index) => (
              <Grid key={index} >
        <Typography color="#f5f5f5" variant="h4" fontWeight="600" marginBottom="5px">
    Today Appointments
  </Typography>
  <Typography color="#222831" variant="h3" fontWeight="600" fontSize={30}>
   {detail.count}
  </Typography>
  </Grid>
        ))}
      </div>
    </Box>
    <Box gridColumn="span 3" gridRow="span 3" backgroundColor="#A79277">
      <Box display="flex" className="doctora3" justifyContent="space-between" alignItems="center" p="15px">
        <Typography variant="h5" fontWeight="600">
          Recent Appointments
        </Typography>
      </Box>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          p="15px"
          className="doctora2"
        >
          
          <Box>
          {recent && recent.map((detail, index) => (
          <div key={index} style={{ display: "flex", alignItems: "center" }}>
            <Typography variant="h5" fontWeight="600" style={{ marginRight: "10px" }}>
              {detail.name}
            </Typography>
            <Typography>
              {detail.booking_date}
            </Typography>
          </div>
        ))}

          </Box>    
        </Box>
    </Box>
 
        {/* ROW 3 */}
 
        <Box
  gridColumn="span 4"
  gridRow="span 1"
  borderTop={10}
  // borderRadius={5}
>
  <Typography
    variant="h5"
    fontWeight="600"
  >
    Gender Count
  </Typography>
  <Box style={{ width: '100%', height: 300 }}>
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={genderData}
        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="gender" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="count" fill="#8884d8" />
      </BarChart>
    </ResponsiveContainer>
  </Box>
</Box>

{/* Bar graph */}
<Box
  gridColumn="span 5"
  gridRow="span 1"
  borderTop={10}
  // borderRadius={5}
>
  <Typography
    variant="h5"
    fontWeight="600"
    // sx={{ padding: "30px 30px 0 30px" }}
  >
    Appointments
  </Typography>
  <Box style={{ width: '100%', height: 300 }}>
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={bookingDatesByMonth}
        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="count" fill="#8884d8" />
      </BarChart>
    </ResponsiveContainer>
  </Box>
</Box>

    </Box>
    </Box>
    </div>
   
  );
};

const DoctorImage = ({ doctorName }) => {
  const [imageUrl, setImageUrl] = useState(null);

  useEffect(() => {
    const fetchImage = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/get-image/${doctorName}`);
        setImageUrl(response.data.imageUrl);
      } catch (error) {
        console.error('Error fetching doctor image:', error);
      }
    };
    fetchImage();
  }, [doctorName]);

  return imageUrl ? <img src={imageUrl} alt={`Profile of ${doctorName}`} /> : null;
};
 
export default Dashboard;
