import React, { useState, useEffect } from 'react';
import { GoogleMap, Marker, LoadScript, InfoWindow, Circle } from '@react-google-maps/api';
import axios from 'axios';
import './MapStyles.css';
import { DirectionsRenderer} from '@react-google-maps/api';
import { FaMapMarkerAlt } from 'react-icons/fa';
import { FaDirections } from 'react-icons/fa';
import { BsRecordCircle } from "react-icons/bs";
 
function Map7() {
  // const [destination, setDestination] = useState(null);
  const [uniqueCategories, setUniqueCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [locations, setLocations] = useState([]);
  const [selectedLocality, setSelectedLocality] = useState('');
  const [highlightedLocation, setHighlightedLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: 15.385, lng: 78.486 });
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedHospital, setSelectedHospital] = useState('');
  const [selectedRange, setSelectedRange] = useState(5001);
  const [currentPosition, setCurrentPosition] = useState(null);
  const [directions, setDirections] = useState(null);
  const [nearbyOptions, setNearbyOptions] = useState([]);
const [selectedNearby, setSelectedNearby] = useState('');
 
  const [showDirectionsDashboard, setShowDirectionsDashboard] = useState(false);
  
  const [selectedNearBy, setSelectedNearBy] = useState(''); 
  const handleNearByChange = (event) => {
    const selected = event.target.value;
    setSelectedNearBy(selected);
  };
  
  const [inputValue, setInputValue] = useState('');
 
  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };
 
 
  useEffect(() => {
    axios.get('http://localhost:5001/locationss')
      .then((response) => {
        const data = response.data;
        setLocations(data);
 
        if (data.length > 0) {
          setMapCenter({
            lat: data[0].latitude,
            lng: data[0].longitude,
          });
          setHighlightedLocation(data[0]);
        }
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);
 
  const uniqueCities = [...new Set(locations.map(location => location.city))];
 
  const handleCityChange = (event) => {
    const selected = event.target.value;
    setSelectedCity(selected);
    setSelectedHospital('');
 
    const selectedCityLocation = locations.find(location => location.city === selected);
    if (selectedCityLocation) {
      setMapCenter({
        lat: parseFloat(selectedCityLocation.latitude),
        lng: parseFloat(selectedCityLocation.longitude),
      });
    }
  };
 
  
  const handleCategoryChange = (event) => {
    const selected = event.target.value;
    setSelectedCategory(selected);
  };
  const handleLocalityChange = (event) => {
    const selectedLocality = event.target.value;
    setSelectedLocality(selectedLocality);
    setSelectedCategory(''); 
    setSelectedNearby(''); 
 
    // Filter locations based on the selected locality
    const filteredLocations = locations.filter(location => location.locality === selectedLocality);
 
    // Extract unique categories and nearby options for the selected locality
    const uniqueCategoriesForLocality = [...new Set(filteredLocations.map(location => location.category))];
    const uniqueNearbyForLocality = [...new Set(filteredLocations.map(location => location.nearby))];
 
    // Update the state variables with the new category and nearby options for the selected locality
    setUniqueCategories(uniqueCategoriesForLocality);
    setNearbyOptions(uniqueNearbyForLocality);
 
    // If needed, set the map center to the coordinates of the selected locality
    const selectedLocalityCoordinates = filteredLocations[0]; // Assuming the first location in the filtered list represents the selected locality
    if (selectedLocalityCoordinates) {
      setMapCenter({
        lat: parseFloat(selectedLocalityCoordinates.latitude),
        lng: parseFloat(selectedLocalityCoordinates.longitude),
      });
    }
    // Other logic as per your requirements
  };
 
  const handleRangeChange = (event) => {
    const selected = parseInt(event.target.value);
    setSelectedRange(selected);
  };
 
  const handleCurrentLocationClick = (location) => {
    setMapCenter({
      lat: parseFloat(location.latitude),
      lng: parseFloat(location.longitude),
    });
    setSelectedCity(location.city);
    setSelectedLocality(location.locality);
  };
 
  const filteredLocations = locations.filter(location => {
    return (
      (!selectedCity || location.city === selectedCity) &&
      (!selectedLocality || location.locality === selectedLocality) &&
      (!selectedCategory || location.category === selectedCategory)
    );
  });
 
  const uniqueLocalities = [...new Set(locations.filter(location => location.city === selectedCity).map(location => location.locality))];
  const handleNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedNearby(selected);
 
     const destinationLatLng = {
      lat: parseFloat(locations.find(loc => loc.nearby === selected)?.latitude || 0),
      lng: parseFloat(locations.find(loc => loc.nearby === selected)?.longitude || 0),
    };
 
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const origin = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          const directionsService = new window.google.maps.DirectionsService();
          directionsService.route(
            {
              origin: origin,
              destination: destinationLatLng,
              travelMode: window.google.maps.TravelMode.DRIVING,
            },
            (result, status) => {
              if (status === window.google.maps.DirectionsStatus.OK) {
                setDirections(result);
                setShowDirectionsDashboard(true);
              } else {
                console.error('Directions request failed due to ' + status);
              }
            }
          );
        },
        (error) => {
          console.error('Error getting user location:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  };
 
  return (
    <div>

      <div className="a">
        <div className='a2'>
      <select value={selectedCity} onChange={handleCityChange} className=' my-3'>
        <option value="">Select a city</option>
        {uniqueCities.map((city, index) => (
          <option key={index} value={city}>
            {city}
          </option>
        ))}
      </select>
 
      <select value={selectedLocality} onChange={handleLocalityChange} className=' my-3'>
        <option value="">Select a Locality</option>
        {uniqueLocalities.map((locality, index) => (
          <option key={index} value={locality}>
            {locality}
          </option>
        ))}
      </select>
 
      <select value={selectedCategory} onChange={handleCategoryChange}className=' my-3'>
        <option value="">Select a Category</option>
        {uniqueCategories.map((category, index) => (
          <option key={index} value={category}>
            {category}
          </option>
        ))}
      </select>

      </div>
      </div>
      <div className="b1 my-3">
  <h4 className='Near'>Select Nearby:</h4>
  <div className="mx-4">
    {nearbyOptions.map((nearby, index) => (
      <div key={index} className="option">
        <label htmlFor={`nearby_${index}`}>
          <input 
            type="radio"
            id={`nearby_${index}`}
            name="nearbyOptions"
            value={nearby}
            checked={selectedNearby === nearby}
            onChange={handleNearbyChange}
          />
          {nearby}
        </label>
      </div>
    ))}
  </div>

</div>

    </div>
  );
}
 
export default Map7;
