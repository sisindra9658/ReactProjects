import React, { useState, useEffect, } from 'react';
import { useNavigate } from 'react-router-dom';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { Button } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Gpay from './GPay_Logo.png';
import Master from './Master.png';
import Master1 from './master1.png';
import Visa from './visa.png';
import Icici from './icici.png';
import Sbi from './SBI.png';
import Hdfc from './HDFCbank.png';
import City from './citibank.png';
import Axis from './axisbank.png';
import Rupee from './rupee.png';
import Navbar from './navbar';
import Navbar1 from './navbar1';
import Subscribe from './subscribe';
import Footer from './footer';
import Footer1 from './footer1';
import axios from 'axios';
import GooglePayButton from "@google-pay/button-react";
 
function Pay() {
 
 
  const paymentRequest = {
    apiVersion: 2,
    apiVersionMinor: 0,
    allowedPaymentMethods: [
      {
        type: "CARD",
        parameters: {
          allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
          allowedCardNetworks: ["MASTERCARD", "VISA"]
        },
        tokenizationSpecification: {
          type: "PAYMENT_GATEWAY",
          parameters: {
            gateway: "example"
          }
        }
      }
    ],
    merchantInfo: {
      merchantId: "12345678901234567890",
      merchantName: "Demo Merchant"
    },
    transactionInfo: {
      totalPriceStatus: "FINAL",
      totalPriceLabel: "Total",
      totalPrice: "100.00",
      currencyCode: "USD",
      countryCode: "US"
    }
  };
 
  const [buttonColor, setButtonColor] = useState("white");
  const [buttonType, setButtonType] = useState("plain");
  const [buttonSizeMode, setButtonSizeMode] = useState("static");
  const [buttonWidth, setButtonWidth] = useState(240);
  const [buttonHeight, setButtonHeight] = useState(40);
 
  const isTop = window === window.top;
 
    const handlePayment = () => {
      // Replace 'YOUR_PHONEPE_PAYMENT_URL' with the actual PhonePe payment URL
      const phonePePaymentUrl = 'https://www.phonepe.com/business-solutions/payment-gateway/register/';
 
      // Redirect the user to the PhonePe payment page
      window.location.href = phonePePaymentUrl;
   
    };
 
    const [transactionComplete, setTransactionComplete] = useState(false);
 
    const handleNetBankingPayment = () => {
      // Assume you have logic to initiate the net banking payment
      // After the payment is initiated, set the state to indicate completion
      // This is where you might want to make API calls, etc.
      setTransactionComplete(true);
    };
 
    useEffect(() => {
      // Simulate redirect after a delay when the transaction is complete
      if (transactionComplete) {
        const timeoutId = setTimeout(() => {
          // Redirect logic here (e.g., window.location.href)
          window.location.href = '/confirmation';
        }, 2000);
 
        // Clear the timeout on component unmount
        return () => clearTimeout(timeoutId);
      }
    }, [transactionComplete]);
 
 
 
  return (
    <>
     <Navbar />
    <Navbar1 />
    <div className='row'>
        <div className='column' style={{ boxShadow: '0 0 10px grey', width: '90%', margin: '20px auto' , border: "none"}}>
 
          <h2 style={{ textAlign: 'center' }}>Payment Section</h2>
 
          <div className="column" style={{ marginBottom: '20px', border: "none" }}>
            <button
              style={{ backgroundColor: "#6739b7", color: "white", border: "none", boxShadow: " 0px 0px 5px grey", borderRadius: "5px" }}
              onClick={handlePayment}
            >
              Pay with PhonePe
            </button>
          </div>
 
          <div className="column" style={{ marginBottom: '20px', border: "none", marginLeft: '-9%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
  <div className="demo">
    <GooglePayButton
      environment="TEST"
      buttonColor="white"
      buttonType="plain"
      buttonSizeMode="static"
      paymentRequest={paymentRequest}
      onLoadPaymentData={paymentRequest => {
        console.log("load payment data", paymentRequest);
      }}
      style={{ width: '100%', maxWidth: '300px' }} 
    />
  </div>
</div>
 
 
          <div className="column" style={{ marginBottom: '20px', border: "none" }}>
            {transactionComplete ? (
              <div>
                <p>Processing Your Net Banking Transaction...</p>
              </div>
            ) : (
              <button
                style={{ backgroundColor: "#00ab9f", color: "white", border: "none", boxShadow: " 0px 0px 5px grey", borderRadius: "5px" }}
                onClick={handleNetBankingPayment}
              >
                Pay with NetBanking
              </button>
            )}
          </div>
 
          <div className="privacy-terms" style={{ textAlign: 'center' }}>
            <p>By clicking on PAY you agree to our <a href="/">Terms of Service</a> & <a href="/">Privacy Policy</a></p>
          </div>
        </div>
      </div>
 
   
    <Subscribe />
    <Footer />
    <Footer1 />
 
 
</>
  );
}
 
export default Pay;