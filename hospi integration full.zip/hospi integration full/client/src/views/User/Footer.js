import React from 'react';
import './Footer.css'; 
import { Nav } from 'react-bootstrap';
import img2  from './Images/image2.png'; 

const Footer = () => {
  return (
    <footer className='footer'>

      <div className="footer-top">
        <div className="container">
          <div className="footer-day-time">
           
          </div>
          <div className="row">
            <div className="col-md-3">
            <img src={img2} alt=""/>
              <p id='us'>Lorem Ipsum ist einfach Dummy-Text der Druck- und Satzindustrie. Lorem Ipsum war der Standard der Branche Lorem Ipsum ist einfach Dummy-Text der Druck- und Satzindustrie. Lorem Ipsum war der Standard der Branche  </p>
            </div>

            <div className="col-md-3" id='act'>
            <h4 id='act'><u>Hospiapp</u></h4>
            <Nav.Link href="Hospital" id='act' active> Hospitals</Nav.Link> 
            <Nav.Link href="Clinic" id='act' active> Clinics</Nav.Link>
            <Nav.Link href="Ambulance" id='act' active> Ambulance </Nav.Link>
            <Nav.Link href="Labs" id='act' active> Diagnostic Labs </Nav.Link>
            <Nav.Link href="Checkups" id='act' active> Health CheckUp </Nav.Link>
            </div>

            <div className="col-md-3" id='act'>
              <h4 id='act'><u>Legal</u></h4>
              <p id='act'>Privacy Policy<br></br> Teams & Conditions<br></br> Disclaimer</p>
            </div>

            <div className="col-md-3" id='act'>
              <h4 id='us'><u>Need Help ?</u></h4>
              <p id='us'>Plot No.34, Chinna Thokatta, Bowenpally Behind Sweet Heart Hotel Secunderabad-500011. Telangana, INDIA.</p>
            </div>

          </div>
        </div>
        <hr />

        <div className="row">
      <div className="col-sm-6">
        <p className="copyright" id='act'>Copyright © 2015. HospiApp. All Rights Reserved</p>
      </div>
      <div className="col-sm-6 text-right">
        <p id='uppi'>Designed and Developed by:</p>
      </div>
    </div>
  </div>
    </footer>
  );
};
 
export default Footer;