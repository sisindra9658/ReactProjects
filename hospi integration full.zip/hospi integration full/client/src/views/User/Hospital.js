import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'react-bootstrap';
import axios from 'axios';
import './Home.css';
import Modal from 'react-modal';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { IoInformation } from 'react-icons/io5';
import { IoMdImages } from 'react-icons/io';
import { FiVideo } from 'react-icons/fi';
import { FaAmbulance } from 'react-icons/fa';
import { FaStethoscope } from 'react-icons/fa';
import { GiMicroscope } from 'react-icons/gi';
import { FaHandHoldingMedical } from 'react-icons/fa';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar, faStarHalf } from '@fortawesome/free-solid-svg-icons';
// import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import img2 from './Images/Map1.png';
import './MapStyles.css';
 
const Hospital = () => {
  // const [destination, setDestination] = useState(null);
  const [uniqueCategories, setUniqueCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [locations, setLocations] = useState([]);
  const [selectedLocality, setSelectedLocality] = useState('');
  const [highlightedLocation, setHighlightedLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: 15.385, lng: 78.486 });
  // const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedHospital, setSelectedHospital] = useState('');
  // const [selectedRange, setSelectedRange] = useState(5000);
  // const [currentPosition, setCurrentPosition] = useState(null);
  const [directions, setDirections] = useState(null);
  const [nearbyOptions, setNearbyOptions] = useState([]);
  // const [typesOptions, setTypesOptions] = useState([]);
  const [selectedNearby, setSelectedNearby] = useState('');
  const [showDirectionsDashboard, setShowDirectionsDashboard] = useState(false);
  // const [selectedNearBy, setSelectedNearBy] = useState('');
  const [clinics, setClinics] = useState([]);
  const [selectedClinic, setSelectedClinic] = useState(null);
  const [specialties, setSpecialties] = useState([]);
  const [SelectedSpecialty, setSelectedSpecialty] = useState(null);
  const [doctorDetails, setDoctorDetails] = useState(null);
  const [popupContent, setPopupContent] = useState('');
  const [filteredClinics, setFilteredClinics] = useState([]);
  // const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  // const [availableTimeSlots, setAvailableTimeSlots] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  // const [selectedDate, setSelectedDate] = useState(new Date());
  // const [availableSlots, setAvailableSlots] = useState([]);
  // const [patientName, setPatientName] = useState('');
  // const [selectedSlot, setSelectedSlot] = useState('');
  // const [message, setMessage] = useState('');
  const [showProfile, setShowProfile] = useState(false);
  const [searchText, setSearchText] = useState('');
  // const [selectedTime, setSelectedTime] = useState(null);
  // const [selectedType, setSelectedType] = useState([]);
  // const [filteredLocations, setFilteredLocations] = useState([]);
 
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    email: '',
    address: '',
    booking_date: '',
    slot_time: '',
    HospitalFullName: '',
    locality: '',
    doctor_name: '',
    doctor_id: '',
    consultation_fee: ''
  });
 
  const navigate = useNavigate();
 
  // const getTodayDate = () => {
  //   const today = new Date();
  //   const year = today.getFullYear();
  //   let month = today.getMonth() + 1;
  //   let day = today.getDate();
  //   month = month < 10 ? `0${month}` : month;
  //   day = day < 10 ? `0${day}` : day;
  //   return `${year}-${month}-${day}`;
  // };
 
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/hospital');
        setClinics(response.data);
        setFilteredClinics(response.data);
      } catch (error) {
        console.error('Error fetching hospital details:', error);
      }
    };
    fetchData();
  }, []);
 
  // const handleTimeChange = (time) => {
  //   setSelectedTime(time);
  // };
 
  // const handleDateChange = async (doctorId,date) => {
  //   try {
  //       console.log(date);
  //       setSelectedDate(date);
  //       setMessage('');
  //       setSelectedSlot('');
  //       setAvailableTimeSlots([]);
 
  //       const formattedDate = format(date, 'yyyy/MM/dd');
  //       const response = await fetchAvailableSlots(doctorId, formattedDate);
 
  //       if (response && response.data && response.data.length > 0) {
  //         setAvailableTimeSlots(response.data);
  //       } else {
  //         setAvailableTimeSlots([]);
  //       }
 
  //   } catch (error) {
  //     console.error('Error fetching available slots', error);
  //   }
  // };
 
  // const handleDateChange = async (doctorId, date) => {
  //   try {
  //     // Log the selected date for debugging
  //     console.log('Selected date:', date);
 
  //     // Set selected date and reset message, selected slot, and available slots
  //     setSelectedDate(date);
  //     setMessage('');
  //     setSelectedSlot('');
  //     setAvailableTimeSlots([]);
 
  //     // Format the date as 'yyyy-MM-dd' for consistency
  //     const formattedDate = format(new Date(date), 'yyyy-MM-dd');
 
  //     // Fetch available slots for the selected doctor and date
  //     const response = await fetchAvailableSlots(doctorId, formattedDate);
 
  //     // Check if the response contains data and update state accordingly
  //     if (response && response.data && response.data.length > 0) {
  //       setAvailableTimeSlots(response.data);
  //     } else {
  //       // If no slots are available, update state and display a message
  //       setAvailableTimeSlots([]);
  //       setMessage('No available slots for this date.');
  //     }
  //   } catch (error) {
  //     // Handle any errors that occur during the fetch operation
  //     console.error('Error fetching available slots:', error);
  //     setMessage('Error fetching available slots. Please try again later.');
  //   }
  // };
 
  // const handleSlotSelection = (slot) => {
  //   setSelectedSlot(slot);
  //   setFormData({
  //     ...formData,
  //     slot_time: format(parse(slot, 'HH:mm:ss', new Date()), 'HH:mm:ss'),
  //   });
  // };
 
  // const handleSearchInputChange = (event) => {
  //   const query = event.target.value.toLowerCase();
  //   console.log('Search Query:', query);
  //   setSearchQuery(query);
  //   const filtered = clinics.filter(
  //     (clinic) =>
  //       clinic.clinic_name.toLowerCase().includes(query) ||
  //       clinic.city.toLowerCase().includes(query) ||
  //       clinic.address.toLowerCase().includes(query) ||
  //       clinic.timings.toLowerCase().includes(query) ||
  //       clinic.rating.toString().includes(query)
  //   );
  //   setFilteredClinics(filtered);
  // };
  // const handlePatientNameChange = (e) => {
  //   setPatientName(e.target.value);
  // };
 
  const handleIconClick = (iconType, clinic) => {
    setSelectedClinic(clinic);
 
    switch (iconType) {
      case 'info':
        setPopupContent(
          <div className="popup">
            <p>{clinic.about_the_hospital}</p>
            <br></br>
 
            <p>
              <b>Timings</b>
              <br />
              <br />
              <b>Mon - Sun</b>
              <br />
              {clinic.timings}
            </p>
            <br></br>
            <p id="from1">
              <b>
                Services<br></br>
              </b>
              {clinic.Services_1}
            </p>
            <br />
            <button onClick={() => setPopupContent(null)}>Close</button>
          </div>
        );
        break;
 
      case 'video':{
        const clinicIdForVideo = clinic.hospi_id;
 
        fetch(`http://localhost:5000/api/get-video1/${clinicIdForVideo}`)
          .then((response) => {
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.blob();
          })
          .then((videoBlob) => {
            const videoUrl = URL.createObjectURL(videoBlob);
 
            setPopupContent(
              <div className="popup">
                <video controls width="100%" height="auto">
                  <source src={videoUrl} type="video/mp4" />
                  <track kind="captions" src="path_to_your_captions.vtt" label="English" />
                  Your browser does not support the video tag.
                </video>
                <br />
                <button onClick={() => setPopupContent(null)}>Close</button>
              </div>
            );
          })
          .catch((error) => {
            console.error('Error fetching video:', error);
            setPopupContent(<div>Error fetching video</div>);
          });
 
        break;
        }
      case 'image':
      default:
        setPopupContent(
          <div className="popup">
            <img
              src={`http://localhost:5000/api/get-clinic-image1/${clinic.hospi_id}`}
              alt={`Profile of ${clinic.HospitalFullName}`}
              style={{ width: '100%', height: '20vh' }}
            />
            <br />
            <button onClick={() => setPopupContent(null)}>Close</button>
          </div>
        );
        break;
    }
  };
 
  const fetchSpecialties = async (hospiId) => {
    try {
      const response = await axios.get(`http://localhost:5000/hospital-specialties/${hospiId}`);
      if (Array.isArray(response.data)) {
        setSpecialties(response.data);
      } else {
        throw new Error('Invalid response format for hospital specialties');
      }
    } catch (error) {
      console.error('Error fetching hospital specialties:', error);
      setSpecialties([]);
    }
  };
 
  const fetchDoctors = async (hospiId, specialtyId) => {
    try {
      const response = await axios.get(`http://localhost:5000/hospi-doctors/${hospiId}/${specialtyId}`);
      if (Array.isArray(response.data)) {
        setDoctors(response.data);
        if (response.data.length > 0) {
          await fetchDoctorDetails(response.data[0].doctorId);
        }
      } else {
        throw new Error('Invalid response format for Hospital doctors');
      }
    } catch (error) {
      console.error('Error fetching Hospital doctors:', error);
      setDoctors([]);
    }
  };
 
  useEffect(() => {
    axios
      .get('http://localhost:5000/doctors')
      .then((response) => {
        const doctorsData = response.data;
        setDoctors(doctorsData);
      })
      .catch((error) => {
        console.error('Error fetching doctors', error);
      });
  }, []);
 
  const handleClinicClick = async (clinic) => {
    if (selectedClinic === clinic) {
      setSelectedClinic(null);
      setSpecialties([]);
      setDoctors([]);
      setSelectedSpecialty(null);
      setSelectedDoctor(null);
      setDoctorDetails(null);
    } else {
      setSelectedClinic(clinic);
      setSelectedSpecialty(null);
      setSelectedDoctor(null);
      setDoctorDetails(null);
      await fetchSpecialties(clinic.hospi_id);
      if (specialties.length > 0) {
        await fetchDoctors(clinic.hospi_id, specialties[0].specialty_id);
      }
    }
  };
 
  const openBookingModal = () => {
    setFormData({
      ...formData,
      booking_date: '',
      booking_time: ''
    });
    setIsModalOpen(true);
  };
 
  const closeBookingModal = () => {
    setIsModalOpen(false);
  };
  const handleSpecialtyChange = async (event) => {
    const specialtyId = event.target.value;
    setSelectedSpecialty(specialtyId);
 
    if (specialtyId) {
      await fetchDoctors(selectedClinic.hospi_id, specialtyId);
    } else {
      setDoctors([]);
      setSelectedDoctor(null);
      setDoctorDetails(null);
      {SelectedSpecialty}
    }
  };
 { uniqueCategories} {selectedCategory} {highlightedLocation} {mapCenter} {selectedHospital} {directions} {showDirectionsDashboard} {SelectedSpecialty} 
 
  const fetchDoctorDetails = async (doctorId) => {
    try {
      const response = await axios.get(`http://localhost:5000/doctor-details/${doctorId}`);
      console.log('Doctor Details Response:', response.data);
      if (response.data) {
        setDoctorDetails(response.data);
      }
    } catch (error) {
      console.error('Error fetching additional doctor details:', error);
      setDoctorDetails(null);
    }
  };
 
  const handleDoctorChange = async (event) => {
    setSelectedDate('');
    setMessage('');
    setAvailableSlots([]);
    const doctorId = event.target.value;
    console.log(doctorId);
    setSelectedDoctor(doctorId);
    if (doctorId) {
      try {
        await fetchDoctorDetails(doctorId);
      } catch (error) {
        console.error('Error fetching doctor details:', error);
        setDoctorDetails(null);
      }
    } else {
      setDoctorDetails(null);
    }
  };
 
  // const fetchAvailableSlots = (doctorId, date) => {
  //   axios.get(`http://localhost:5000/slots?doctorId=${doctorId}&date=${date}`)
  //     .then(response => {
  //       console.log('Response from fetchAvailableSlots:', response);
 
  //       const slots = response.data;
  //       setAvailableSlots(slots);
  //       if (slots.length === 0) {
  //         setMessage(`Error fetching available slots`);
  //       } else {
  //         setMessage('');
  //       }
  //     })
  //     .catch(error => {
  //       console.error(`No available slots for ${date}`, error);
  //       setMessage(`No available slots for ${date}.`);
  //     }
  //     );
  // };
 
  const handleBookNowClick = () => {
    if (!selectedDate || !selectedSlot) {
      setMessage('Please select both date and time slot before booking.');
    } else {
      setMessage('selected successfully');
      openBookingModal();
    }
  };
 
  useEffect(() => {
    const handleSuccess = (response) => {
      console.log('Data submitted successfully:', response.data);
    };
 
    const handleError = (error) => {
      console.error('Error submitting data:', error);
    };
 
    if (formData.name && formData.contact && formData.email && formData.address) {
      axios.post('http://localhost:5000/api/patient_booking', formData).then(handleSuccess).catch(handleError);
    }
  }, [formData]);
  useEffect(() => {
    const filterClinics = () => {
      let filtered = clinics;
 
      if (selectedCity) {
        filtered = filtered.filter((clinic) => clinic.city === selectedCity);
      }
 
      if (selectedLocality) {
        filtered = filtered.filter((clinic) => clinic.locality === selectedLocality);
      }
 
      if (selectedNearby) {
        filtered = filtered.filter((clinic) => clinic.nearby === selectedNearby);
      }
 
      setFilteredClinics(filtered);
    };
 
    filterClinics();
  }, [clinics, selectedCity, selectedLocality, selectedNearby]);
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };
 
  const handleonSubmit = async (event) => {
    event.preventDefault();
 
    try {
      if (!formData.name || !formData.contact || !formData.email || !formData.address) {
        toast.error('Please fill in all required fields');
        return;
      }
 
      let slotTime = '';
      if (selectedSlot) {
        slotTime = `${selectedSlot.from_time} - ${selectedSlot.to_time}`;
      }
 
      const editedDataToSend = {
        name: formData.name,
        contact: formData.contact,
        email: formData.email,
        address: formData.address,
        HospitalFullName: selectedClinic.HospitalFullName,
        locality: selectedClinic.locality,
        doctor_name: doctorDetails.doctor_name,
        doctor_id: doctorDetails.doctor_id,
        consultation_fee: doctorDetails.consultation_fee,
        slot_time: slotTime // Change this line to extract from_time
      };
 
      if (selectedDoctor && doctorDetails) {
        editedDataToSend.HospitalFullName = selectedClinic.HospitalFullName;
        editedDataToSend.locality = selectedClinic.locality;
        editedDataToSend.doctor_name = doctorDetails.doctor_name;
        editedDataToSend.doctor_id = doctorDetails.doctor_id;
        editedDataToSend.consultation_fee = doctorDetails.consultation_fee;
        editedDataToSend.booking_date = new Date(selectedDate).toISOString().split('T')[0];
        editedDataToSend.slot_time = slotTime;
      }
 
      const response = await axios.post('http://localhost:5000/api/appointment_bookinghospital', editedDataToSend);
 
      setFormData({
        name: '',
        contact: '',
        email: '',
        address: '',
        booking_date: '',
        slot_time: '',
        HospitalFullName: '',
        locality: '',
        doctor_name: '',
        doctor_id: '',
        consultation_fee: ''
      });
 
      toast.success('Form submitted successfully!');
      console.log('Data submitted successfully:', response.data);
    } catch (error) {
      console.error('Error submitting data:', error);
      toast.error(`Error submitting form. ${error.message || 'Please try again later.'}`);
    }
 
    navigate('/User/edit1');
  };
 
  const renderRatingStars = (rating) => {
    const stars = [];
    const integerPart = Math.floor(rating);
    const decimalPart = rating - integerPart;
    for (let i = 0; i < integerPart; i++) {
      stars.push(<FontAwesomeIcon icon={faStar} key={i} style={{ color: 'gold' }} />);
    }
    if (decimalPart >= 0.5) {
      stars.push(<FontAwesomeIcon icon={faStarHalf} key="half" style={{ color: 'gold' }} />);
    }
    const remainingStars = 5 - stars.length;
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<FontAwesomeIcon icon={faStar} key={`empty-${i}`} style={{ color: 'gray' }} />);
    }
    return stars;
  };
 
  const handleViewProfile = () => {
    setShowProfile(!showProfile);
  };
 
  useEffect(() => {
    axios
      .get('http://localhost:5000/locationss1')
      .then((response) => {
        const data = response.data;
        setLocations(data);
 
        if (data.length > 0) {
          setMapCenter({
            lat: data[0].latitude,
            lng: data[0].longitude
          });
          setHighlightedLocation(data[0]);
        }
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);
 
  const uniqueCities = [...new Set(locations.map((location) => location.city))];
 
  const handleCityChange = (event) => {
    const selected = event.target.value;
    setSelectedCity(selected);
    setSelectedHospital('');
 
    const selectedCityLocation = locations.find((location) => location.city === selected);
    if (selectedCityLocation) {
      setMapCenter({
        lat: parseFloat(selectedCityLocation.latitude),
        lng: parseFloat(selectedCityLocation.longitude)
      });
    }
  };
 
  //
  // const handleCategoryChange = (event) => {
  //   const selected = event.target.value;
  //   setSelectedCategory(selected);
  // };
  const handleLocalityChange = (event) => {
    const selectedLocality = event.target.value;
    setSelectedLocality(selectedLocality);
    setSelectedCategory(''); // Reset selected category when locality changes
    setSelectedNearby(''); // Reset selected nearby when locality changes
 
    // Filter locations based on the selected locality
    const filteredLocations = locations.filter((location) => location.locality === selectedLocality);
 
    // Extract unique categories and nearby options for the selected locality
    const uniqueCategoriesForLocality = [...new Set(filteredLocations.map((location) => location.category))];
    const uniqueNearbyForLocality = [...new Set(filteredLocations.map((location) => location.nearby))];
 
    // Update the state variables with the new category and nearby options for the selected locality
    setUniqueCategories(uniqueCategoriesForLocality);
    setNearbyOptions(uniqueNearbyForLocality);
 
    // If needed, set the map center to the coordinates of the selected locality
    const selectedLocalityCoordinates = filteredLocations[0]; // Assuming the first location in the filtered list represents the selected locality
    if (selectedLocalityCoordinates) {
      setMapCenter({
        lat: parseFloat(selectedLocalityCoordinates.latitude),
        lng: parseFloat(selectedLocalityCoordinates.longitude)
      });
    }
    // Other logic as per your requirements
  };
 
  // const handleRangeChange = (event) => {
  //   const selected = parseInt(event.target.value);
  //   setSelectedRange(selected);
  // };
 
  // const handleCurrentLocationClick = (location) => {
  //   setMapCenter({
  //     lat: parseFloat(location.latitude),
  //     lng: parseFloat(location.longitude)
  //   });
  //   setSelectedCity(location.city);
  //   setSelectedLocality(location.locality);
  // };
 
  const uniqueLocalities = [
    ...new Set(locations.filter((location) => location.city === selectedCity).map((location) => location.locality))
  ];
 
  const handleNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedNearby(selected);
 
    const destinationLatLng = {
      lat: parseFloat(locations.find((loc) => loc.nearby === selected)?.latitude || 0),
      lng: parseFloat(locations.find((loc) => loc.nearby === selected)?.longitude || 0)
    };
 
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const origin = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          const directionsService = new window.google.maps.DirectionsService();
          directionsService.route(
            {
              origin: origin,
              destination: destinationLatLng,
              travelMode: window.google.maps.TravelMode.DRIVING
            },
            (result, status) => {
              if (status === window.google.maps.DirectionsStatus.OK) {
                setDirections(result);
                setShowDirectionsDashboard(true);
              } else {
                console.error('Directions request failed due to ' + status);
              }
            }
          );
        },
        (error) => {
          console.error('Error getting user location:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  };
 
  // const handleTypeChange1 = (event) => {
  //   setSelectedType(event.target.value);
  // };
  // const mapStyles = {
  //   height: '400px',
  //   width: '100%'
  // };
  const [clinicTypes, setClinicTypes] = useState([]);
  const [selectedType, setSelectedType] = useState('');
 
  useEffect(() => {
    axios
      .get('http://localhost:5000/clinic-types1')
      .then((response) => {
        const data = response.data;
        setClinicTypes(data);
      })
      .catch((error) => {
        console.error('Error fetching clinic types:', error);
      });
  }, []);
 
  const handleTypeChange = (event) => {
    setSelectedType(event.target.value);
  };
 
  useEffect(() => {
    const filterClinics = () => {
      let filtered = clinics;
 
      if (selectedType) {
        filtered = filtered.filter((clinic) => clinic.Types === selectedType);
      }
 
      setFilteredClinics(filtered);
    };
 
    filterClinics();
  }, [clinics, selectedType]);
  // const [specializationTypes, setSpecializationTypes] = useState([]);
  //   const [selectedSpecialization, setSelectedSpecialization] = useState('');
 
  //   useEffect(() => {
 
  //     axios.get('http://localhost:5000/specialization-types')
  //     .then((response) => {
  //       const specializationTypes = response.data.map(item => item.Specialities);
  //       setSpecializationTypes(specializationTypes);
  //     })
  //     .catch((error) => {
  //       console.error('Error fetching specialization types:', error);
  //     });
 
  //   }, []);
  //   const [filteredSpecializationTypes, setFilteredSpecializationTypes] = useState([]);
 
  //   const handleSpecializationChange = (event) => {
  //     setSelectedSpecialization(event.target.value);
  //   };
 
  // useEffect(() => {
  //   const filterSpecializationTypes = () => {
  //     let filtered = specializationTypes;
 
  //     if (selectedSpecialization) {
  //       filtered = filtered.filter(type => type.Specialities === selectedSpecialization);
  //     }
 
  //     setFilteredSpecializationTypes(filtered);
  //   };
 
  //   filterSpecializationTypes();
  // }, [specializationTypes, selectedSpecialization]);
 
  const [specializationTypes, setSpecializationTypes] = useState([]);
  // const [filteredSpecializationTypes, setFilteredSpecializationTypes] = useState([]);
  const [selectedSpecialization, setSelectedSpecialization] = useState(null);
 
  useEffect(() => {
    axios
      .get('http://localhost:5000/specialization-types1')
      .then((response) => {
        const specializationTypes = response.data.map((item) => item.Specialities);
        setSpecializationTypes(specializationTypes);
      })
      .catch((error) => {
        console.error('Error fetching specialization types:', error);
      });
  }, []);
 
  const handleSpecializationChange = (event) => {
    setSelectedSpecialization(event.target.value);
  };
  useEffect(() => {
    // Filter clinics when selectedSpecialization changes
    const filterClinics = () => {
      let filtered = clinics;
 
      if (selectedSpecialization) {
        filtered = filtered.filter((clinic) => clinic.Specialities === selectedSpecialization);
      }
 
      setFilteredClinics(filtered);
    };
 
    filterClinics();
  }, [clinics, selectedSpecialization]);
  const [selectedDate, setSelectedDate] = useState('');
  const [availableSlots, setAvailableSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState('');
  const [message, setMessage] = useState('');
 
  const handleSlotSelection = (slot) => {
    setSelectedSlot(slot);
  };
 
  const fetchAvailableSlots = async (doctor_Id, date) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/get/hspdoctor-slots/${doctor_Id}/${date}`);
      console.log('Response from fetchAvailableSlots:', response.data);
      const slots = response.data;
      setAvailableSlots(slots);
      if (slots.length === 0) {
        setMessage(`Error fetching available slots`);
      } else {
        setMessage('');
      }
    } catch (error) {
      console.error(`No available slots for ${date}`, error);
      setMessage(`No available slots for ${date}.`);
    }
  };
 
  const handleDateChange = (doctorId, date) => {
    try {
      console.log(date);
      setSelectedDate(date);
      setMessage('');
      setSelectedSlot('');
      fetchAvailableSlots(doctorId, date);
    } catch (error) {
      console.error('Error fetching available slots', error);
    }
  };
  return (
    <div>
      {/* <div className='column' >
      <h1 style={{ textAlign: 'center' }}>Map with Locations</h1>
      <LoadScript googleMapsApiKey="AIzaSyCGhHNoTUpRQo4WQxmfUDzGTlZUcAYSvCg">
        <GoogleMap mapContainerStyle={mapStyles} zoom={5} center={mapCenter}>
          {showDirectionsDashboard && directions && (
            <DirectionsRenderer
              directions={directions}
              options={{
                polylineOptions: {
                  strokeColor: 'black',
                  strokeOpacity: 1,
                  strokeWeight: 4,
                },
              }}
            />
          )}
        </GoogleMap>
      </LoadScript>
      </div> */}
      <img src={img2} id="img2" alt="" />
      <hr></hr>
      <div className="a ">
        <div className="a2 ">
          <select value={selectedCity} onChange={handleCityChange} className=" my-3">
            <option value="">Select a city</option>
            {uniqueCities.map((city, index) => (
              <option key={index} value={city}>
                {city}
              </option>
            ))}
          </select>
 
          <select value={selectedLocality} onChange={handleLocalityChange} className=" my-3">
            <option value="">Select a Locality</option>
            {uniqueLocalities.map((locality, index) => (
              <option key={index} value={locality}>
                {locality}
              </option>
            ))}
          </select>
        </div>
      </div>
 
      <div className="b1 my-3">
        <h4 className="Near">Select Nearby:</h4>
        <div className="mx-4">
          {nearbyOptions.map((nearby, index) => (
            <div key={index} className="option">
              <label htmlFor={`nearby_${index}`} style={{ color: 'black' }}>
                <input
                  type="radio"
                  id={`nearby_${index}`}
                  name="nearbyOptions"
                  value={nearby}
                  checked={selectedNearby === nearby}
                  onChange={handleNearbyChange}
                  style={{ color: 'black' }}
                />
                {nearby}
              </label>
            </div>
          ))}
        </div>
        <div className="Near1">
          <b>
            <hr></hr>
          </b>
        </div>
 
        <div>
          <h4 className="Near">Select Types:</h4>
          <div className="mx-4" style={{ color: 'black' }}>
            {clinicTypes.map((type, index) => (
              <div key={index} className="option">
                <label htmlFor={`clinic_type_${index}`} style={{ color: 'black' }}>
                  <input
                    type="radio"
                    id={`clinic_type_${index}`}
                    name="clinicTypeOptions"
                    value={type}
                    checked={selectedType === type}
                    onChange={handleTypeChange}
                  />
                  {type}
                </label>
              </div>
            ))}
          </div>
        </div>
 
        <div className="Near1">
          <b>
            <hr></hr>
          </b>
        </div>
 
        <h4 className="Near">Specialization:</h4>
        <div style={{ textAlign: 'center' }}>
          <input
            type="text"
            placeholder="Search..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: '60%', marginBottom: '10px' }}
          />
        </div>
        <div style={{ width: '100%', overflowY: 'auto', maxHeight: '200px' }}>
          <div className="mx-4">
            {specializationTypes
              .filter((type) => type.toLowerCase().includes(searchText.toLowerCase()))
              .map((type, index) => (
                <div key={index} className="option">
                  <label htmlFor={`specialization_type_${index}`} style={{ color: 'black' }}>
                    <input
                      type="radio"
                      id={`specialization_type_${index}`}
                      name="specializationTypeOptions"
                      value={type}
                      checked={selectedSpecialization === type}
                      onChange={handleSpecializationChange}
                    />
                    {type}
                  </label>
                </div>
              ))}
          </div>
        </div>
      </div>
 
      <div className="home-container">
        <div></div>
        <br></br>
        <h5 className="headers">
          <p className="name">Hospitals</p>
          <p>Openings</p>
          <p>Specialties</p>
          <p>Services</p>
          <p>Rating</p>
        </h5>
        <div className="clinic-list">
          {filteredClinics.map((clinic, index) => (
            <div key={index} className={`clinic-item ${selectedClinic === clinic ? 'selected' : ''}`}>
              <button onClick={() => handleClinicClick(clinic)} className="clinic-summary">
                <p className="name">
                  <span id="nam">
                    <b>{clinic.HospitalFullName}</b>
                  </span>
                  <br></br>
                  <p>{clinic.Address}</p>
                  <div className="iconss">
                    <div className="iconss22" style={{ display: 'flex' }}>
                      <Button variant="light" onClick={() => handleIconClick('info', clinic)}>
                        <IoInformation />
                      </Button>
                      <Button variant="light" onClick={() => handleIconClick('image', clinic)}>
                        <IoMdImages />
                      </Button>
                      <Button variant="light" onClick={() => handleIconClick('video', clinic)}>
                        <FiVideo />
                      </Button>
                    </div>
                    {popupContent && selectedClinic === clinic && (
                      <div className="popup">
                        {popupContent}
                        <button onClick={() => setPopupContent(null)}>Close</button>
                      </div>
                    )}
                  </div>
                </p>
                <p>{clinic.opening}</p>
                <div className="tooltip-container">
                  <p>Specialties</p>
                  <span className="tooltip" id="date">
                    {clinic.Specialities}
                  </span>
                </div>
 
                <div>
                  <div className="col" id="apple">
                    {clinic.services && clinic.services.includes('Ambulance') && (
                      <div className="tooltip-container">
                        <FaAmbulance className="ambulance" />
                        <span className="tooltip-text">Ambulance</span>
                      </div>
                    )}
                    {clinic.services && clinic.services.includes('24/7 In Touch') && (
                      <div className="tooltip-container">
                        <FaStethoscope />
                        <span className="tooltip-text">24/7 In Touch</span>
                      </div>
                    )}
                    {clinic.services && clinic.services.includes('Laboratory') && (
                      <div className="tooltip-container">
                        <GiMicroscope />
                        <span className="tooltip-text">Laboratory</span>
                      </div>
                    )}
                    {clinic.services && clinic.services.includes('Your health is our priority') && (
                      <div className="tooltip-container">
                        <FaHandHoldingMedical />
                        <span className="tooltip-text">Your health is our priority</span>
                      </div>
                    )}
                  </div>
                </div>
                <p>
                  {renderRatingStars(clinic.rating)}
                  {clinic.rating}
                </p>
              </button>
 
              {selectedClinic === clinic && (
                <div className="clinic-details">
                  <div className="container">
                    <select id="specialtySelect" onChange={handleSpecialtyChange}>
                      <option value="">Choose Specialty</option>
                      {specialties.map((specialty) => (
                        <option key={specialty.specialty_id} value={specialty.specialty_id}>
                          {specialty.specialty_name}
                        </option>
                      ))}
                    </select>
 
                    <select id="doctorSelect" onChange={handleDoctorChange}>
                      <option value="">Select Doctor</option>
                      {doctors.map((doctor) => (
                        <option key={doctor.doctor_id} value={doctor.doctor_id}>
                          {doctor.doctor_name}
                        </option>
                      ))}
                    </select>
                  </div>
 
                  {selectedDoctor && doctorDetails && (
                    <div className="col">
                      <img
                        src={`http://localhost:5000/api/get-doctor-image/${doctorDetails.doctor_id}`}
                        alt={`Profile of ${doctorDetails.full_name}`}
                        style={{ width: '20%', height: '12%', borderRadius: '100%', border: '1px solid black' }}
                      />
                      <br></br>
 
                      <div className="col-md-4">
                        <div className="doctor-details">
                          <p>
                            <b>Name:</b> {doctorDetails.doctor_name}
                          </p>
                          <p>
                            <b>Specialization:</b> {doctorDetails.specialization}
                          </p>
                          <p>
                            <b>Qualification:</b> {doctorDetails.qualification}
                          </p>
                          <p>
                            <b>Experience:</b> {doctorDetails.experience} years
                          </p>
                          <p>
                            <b>Languages:</b> {doctorDetails.Language}
                          </p>
 
                          <button className="btn btn-primary mt-2" onClick={handleViewProfile}>
                            <b>View Profile</b>
                          </button>
 
                          {showProfile && (
                            <div className="modal-container">
                              <div className="modal-content">
                                <button className="close" onClick={handleViewProfile}>
                                  &times;
                                </button>
                                <p>
                                  <b>Name:</b> {doctorDetails.doctor_name}
                                </p>
                                <p>
                                  <b>Specialization:</b> {doctorDetails.specialization}
                                </p>
                                <p>
                                  <b>Qualification:</b> {doctorDetails.qualification}
                                </p>
                                <p>
                                  <b>Experience:</b> {doctorDetails.professional_experience} years
                                </p>
                                <p>
                                  <b>Languages:</b> {doctorDetails.Language}
                                </p>
                                <p>
                                  <b>Email:</b> {doctorDetails.Email}
                                </p>
                                <p>
                                  <b>Contact:</b> {doctorDetails.Contact}
                                </p>
                                <p>
                                  <b>Awards:</b> {doctorDetails.Awards}
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
 
                      <div className="col-md-4">
                        <div className="booking-details">
                          <p>
                            <b>Consultation Fee:</b> {doctorDetails.consultation_fee}
                          </p>
                          <label>
                            <input
                              type="date"
                              id="date"
                              value={selectedDate}
                              onChange={(e) => handleDateChange(selectedDoctor, e.target.value)}
                              min={new Date().toISOString().split('T')[0]}
                            />
                          </label>
                          <p>
                            <b>Available Time Slots:</b>
                          </p>
                          <select
                            value={selectedSlot}
                            onChange={(e) => handleSlotSelection(JSON.parse(e.target.value))}
                            style={{ width: '200px' }}
                          >
                            <option value="0">Select timeslot</option>
                            {availableSlots.map((slot, index) => (
                              <option key={index} value={JSON.stringify(slot)}>
                                {slot.from_time} - {slot.to_time}
                              </option>
                            ))}
                          </select>
                          {message && <p>{message}</p>}
                          {selectedSlot && <p>Selected Slot: {selectedSlot.from_time} - {selectedSlot.to_time}</p>}
 
                         
                        </div>
                        <button type="button" id="date" onClick={() => handleBookNowClick()}>
                            {' '}
                            Book Now{' '}
                          </button>
                      </div>
 
                      <Modal isOpen={isModalOpen} onRequestClose={closeBookingModal}>
                        <form onSubmit={handleonSubmit}>
                          <label className='label1' htmlFor='name'>Name:</label>
                          <input type="text" name="name" value={formData.name} onChange={handleInputChange} required />
                          <label className='label1' htmlFor='contact'>Contact:</label>
                          <input type="text" name="contact" value={formData.contact} onChange={handleInputChange} required />
                          <label className='label1' htmlFor='email'>Email:</label>
                          <input type="email" name="email" value={formData.email} onChange={handleInputChange} required />
                          <label className='label1' htmlFor='address'>Address:</label>
                          <input type="text" name="address" value={formData.address} onChange={handleInputChange} required />
                          <button type="submit">Submit</button>
                        </form>
                        <br />
                        <button className="close-button" onClick={closeBookingModal}>
                          Close
                        </button>
                      </Modal>

                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
 
export default Hospital;
 