// import Navbar from './navbar';
// import Navbar1 from './navbar1';
// import Search from './search';
import Middle from './middle';
// import Map from './map';
import Track from './track';
import Services from './services';
import Subscribe from './subscribe';
// import Footer1 from './footer1';
// import Footer from './footer';
import Map from './map1';
const Home = () => {
 
    return(
        <>
       <Map />
        <Middle />
        <Track />
        <hr />
        <Services />
        <Subscribe />
        </>
    );
}

export default Home;
