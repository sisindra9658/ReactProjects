import React from 'react';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { NavLink } from 'react-router-dom'; // Import NavLink from react-router-dom
import './Navbar1.css';

function Navbar1() {
  return (
    <>
      <Navbar expand="lg" className="navbar1custom-navbar bg-body-red">
        <Navbar.Collapse id="navbar1navbarScroll">
          <Nav className="mx-auto my-2 my-lg-0" style={{ maxHeight: '100px' }}>
            <div id="navbar1tank2">
              {/* Use NavLink instead of Nav.Link */}
              <NavLink to="/User/Hospital" id="tank1" activeClassName="active">
                Hospitals
              </NavLink>
              <NavLink to="/User/Clinic" id="tank1" activeClassName="active">
                Clinics
              </NavLink>
              <NavLink to="/User/Ambulance" id="tank1" activeClassName="active">
                Ambulance
              </NavLink>
              <NavLink to="/User/Labs" id="tank1" activeClassName="active">
                Diagnostic Labs
              </NavLink>
              <NavLink to="/User/Checkups" id="tank1" activeClassName="active">
                Health CheckUp
              </NavLink>
            </div>
          </Nav>
          <Nav />
        </Navbar.Collapse>
      </Navbar>
    </>
  );
}

export default Navbar1;

