import React from 'react'

function Ambulance() {
  return (
    <div>
      <h1>Ambulance</h1>
    </div>
  )
}

export default Ambulance
