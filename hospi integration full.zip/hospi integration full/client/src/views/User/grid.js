import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import './grid.css';
import { Navigate, useNavigate } from 'react-router-dom';
import Form from "react-bootstrap/Form";
import Card from "react-bootstrap/Card";
import { Button } from '@mui/material';
import { Country, State, City }  from 'country-state-city';
import { Link } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { PopupboxManager, PopupboxContainer } from 'react-popupbox';
import 'react-popupbox/dist/react-popupbox.css';
import axios from 'axios';
import { GoogleMap, Marker, LoadScript, InfoWindow, Circle } from '@react-google-maps/api';
import './MapStyles.css';
import { DirectionsRenderer} from '@react-google-maps/api';
import { FaMapMarkerAlt } from 'react-icons/fa';
 
import { FaDirections } from 'react-icons/fa';
import { BsRecordCircle } from "react-icons/bs";
// const cities = [
//   { id: 1, name: "Vishakapatnam", lat: 17.6868, lng: 83.2185 },
//   { id: 2, name: "Vijayawada", lat: 16.5062, lng: 80.6480 },
//   { id: 3, name: "Tirupati", lat: 13.6288, lng: 79.4192 },
//   { id: 4, name: "Hyderabad", lat: 17.3850, lng: 78.4867 },
//   { id: 5, name: "Warangal", lat: 18.0080, lng: 79.5880 },
//   { id: 6, name: "Kakinada", lat: 16.9890, lng: 82.2475 },
//   { id: 7, name: "Rajahmundry", lat: 17.0054, lng: 81.7833 },
//   { id: 8, name: "Guntur", lat: 16.3067, lng: 80.4365 },
//   { id: 9, name: "Bangalore", lat: 12.840711, lng: 77.676369 },
//   { id: 10, name: "Kurnool", lat: 15.8281, lng: 78.0373 },
//   { id: 11, name: "Anantapur", lat: 14.6546, lng: 77.5560 },
//   { id: 12, name: "Khammam", lat: 17.2474, lng: 80.1514 },
//   { id: 13, name: "Karimnagar", lat: 18.4392, lng: 79.1288 },
//   { id: 14, name: "Nizamabad", lat: 18.6734, lng: 78.1000 },
//   { id: 15, name: "Adilabad", lat: 19.6668, lng: 78.5339 },
//   // Add more cities as needed
// ];
 
// const nearbyAreas = {
//   // 'All Locations':[],
//     'Vijayawada': ['Benz Circle', 'AutoNagar','nakkala Rd','MG road','Bolivar Street','Sivananda Street'],
//     'Vishakapatnam': ['Domlur', 'RK Beach', 'Gajuwaka','Waltair Main Rd','Gurudwara Rd','Health City'],
//     'Tirupati': ['Tiruchanur','Mangalam','Renigunta','Avilala','Akkarampalle'],
//     'Hyderabad': ['Secunderabad', 'LB Nagar', 'Gachibowli','Madhapur','Paradise Circle'],
//     'Warangal': ['Kazipet','Hanamkonda','Shambunipet','girmajipet'],
//     'Kakinada': ['Sarpavaram','Vakalapudi','Thimmapuram', 'Gandhi Nagar'],
//     'Rajahmundry': ['Bommuru','Gandhipuram' , 'Katheru','Dowleswaram'],
//     'Guntur': ['Brodipet','Kantheru','Koritepadu'],
//     'Bangalore': ['Jayanagar','Richmond Road','Cunningham Rd','City Market','Kalyananagara'],
//     'Kurnool': ['Orvakal','c-camp','Raj Vihar','check post'],
//     'Anantapur': ['tower Clock','iron bridge','Kamalanagar'],
//     'Khammam': ['Kothagudem','Yellandu','Palwancha','Sathupally'],
//     'Karimnagar': ['Malkapur','Mukarampura','Nagulamallial','Thippapuram'],
//     'Nizamabad': ['Bodhan','Manikbhandar'],
//     'Adilabad': ['Ghatanji','Nirmal','Narsapur']
//   };
 
 
const hospitalsByLocation = {
  'Benz Circle': ["Trust Hospital","Pujitha Hospital", "Srikara Hospital"],
  'AutoNagar': ["Rise Hospital","Apollo Hospital", "Janani Hospital"],
  'nakkala': ["Padmaja Hospital","BHEL Hospital", "Mahanthi Hospital"],
  'MG road': ["Saadana Hospital","Triveni Hospital", "Sri Tirumala Hospital"],
  'Boliver Street': ["BHPV Hospital","Navaratnam Hospital"],
  'Sivananda Street': ["Omni Hospital","ABC Hospital", "Kims Icon Hospital"],
  'Domlur': ["Krishnavenee Hospitals","SV Hospital", "Padmasri Hospital"],
  'RK Beach': ["A.N Beach Hospital","Usha Hospital", "Kondalaroa Hospital"],
  'Gajuwaka': ["RK Hospital","Saptagiri Hospital", "Gowthami Hospital"],
  'Waltair Main Rd': ["Apollo Hospital","Care Hospital", "Omni Hospital"],
  'Gurudwara Rd': ["Rama Hospital","Apollo Hospital", "Maxivision Hospital"],
  'Health City': ["MB Hospital","Citi Hospital", "Unique Hospital"],
  'HSR Layout': ["Narayana Hospital","Lotus Hospital", "Ovum Hospital"],
  'BTM Layout': ["BTM Hospital","Life Care Hospital", "Sri Sairam Hospital"],
  'Jayanagar': ["Bangalore Hospital","United Hospital", "Manipal Hospital"],
  'Richmond Road': ["Fortis Hospital","Victoria Hospital", "Republic Hospital"],
  'Cunningham Rd': ["Relbit Hospital","Al-Ameen Hospital", "Queen's Hospital"],
  'City Market': ["South City Hospital","Citizen Hospital", "E City Hospital"],
  'Kalyananagara': ["Trilife Hospital","Royal Bengalore Hospital", "Hosmat Hospital"],
 
  'Kondapur': ["Care Hospital Malakpet", "Nakshatra Hospital"],
  'Gachibowli': ["Prk Hospitals", "Mark Hospital"],
  'Jubilee Hills': ["Prk Hospitals", "Mark Hospital"],
  'Begumpet': ["Svastha Hospital", "Manipal Hospital Begumpet"],
  'YVStreet': ["Subramendyam Hospital", "Dr Noori"],
  'rStreet': ["Mk hospitals", "pk hospitals"],
  'Tiruchanur':["Family Care Hospital","Padmavathi Hospital","AR Multi Speciality","Firoz Hospital"],
  'Mangalam':["Lepakshi Hospital","Balaji Kidney and Maternity Clinic","Madhuri Remedy ","Balaji Hospital"],
  'Renigunta':["Ms Reddy General Hospital","Amara Hospital","Padamavathi Childerns Hospital"],
  'Avilala':["Elite Hospital","Ganta Neuro Hospitals","Sri Sara Hospita"],
  'Secunderabad':[" Sunshine Hospitals","Chetana Hospital","Navodaya Hospitals","Navjeevan Hospitals","Srikara Hospitals"],
  'LB Nagar':["Aruna Hospital","Orange Hospitals","Premier Health Services","Orange Hospitals","Aruna Hospital"],
   'Gachibowli':["Himagiri Hospitals","Continental Hospitals","care Hospital"],
   'Madhapur':["Medicover Hospitals"," Sravani Hospital","Pace Hospital "],
   'Paradise Circle':[" Chetana Hospital","Sunshine Hospital","Apollo Spectra Hospitals","quaternary care hospital"],
   'Kazipet':[" NSR HOSPITALS","Kalyani Hospital","Aditya Hospital","Sai Ram Hospital"],
   'Hanamkonda':["Prashanthi Hospitals","Rohini Super Speciality","Amrutha Childrens hospital"],
   'Shambunipet':[" Sai Ram Hospital","Health Plus Hospitals","Surya Hospital"],
   'girmajipet':["Metro Hospital","Amri Hospitals","Jupiter Hospital","Kailash Hospital"],
   'Sarpavaram':["Sridevi Children Hospital","Kriti ENT Care Hospital"],
   'Vakalapudi':["Blueray Hospitals","Shravani Ent Hospital","Dhrusti Eye Hospital","Vijaya ENT Care"],
   'Thimmapuram':["Surya Global Hospital","Amrutha Mother & Child Hospital","Medicover Hospitals","Aarogya Hospitals"],
   'Gandhi Nagar':["Foundation Hospital","Cure N Care Clinic"],
   'Bommuru':[" Lakshmi Ganapathi Medicals","Vision Multispeciality Hospital","Goutham Urology & Kidney Center","Santha Ram Hospital"],
   'Katheru':[" Pranava Hospitals","Vaddadi Hospital","Helios Hospital"],
   'Dowleswaram':["Lakshmi Ganapathi Medicals","Vision Multispeciality Hospital","Goutham Urology & Kidney Center"],
   'Brodipet':["Karumuri Hospital","Mgr Multi Speciality Hospital","Jagadeesh Nursing Home","Shiva Hospitals"],
   'Kantheru':["Ramesh Hospitals","Global Medical Centre","Manipal Super Speciality Hospital"],
   'Koritepadu':["Coastal Care Hospital","Azizia Hospital","Gummadi Children Hospital"],
   'Orvakal':["Gvr Children Hospital","Agraseni Hospital","Aarka Hospital","Omni Hospitals"],
   'c-camp':["Vijaya Hospital","Maya's Hospital","rural-tribal hospital"],
   'Raj Vihar':["Gvr Children Hospital","Aarka Hospital","R R Hospital","S S Hospital"],
   'check post':["Aarka Hospital","Agraseni Hospital"],
   'tower Clock':["Murthy Ortho Hospital","Omega Hospitals"],
   'iron bridge':["Sreenivasa Multi Speciality Hospital","Saveera Hospitals","Maha Hospitals"],
   'Kamalanagar':["Sunray Hospital","Magnus Hospital","Hrudaya Childrens Hospital","Sri Tirumala Hospital"],
   'Kothagudem':["Singareni Main Hospital","Gayatri Hospital","Ganesh Nursing Home"],
   'Yellandu':["Y Prasad Hospitals","Kavya Emergency and Multi Speciality Hospitals","Srinivasa Hospital","Karthikeya Emergency Hospital"],
   'Palwancha':[" Nava Bharat Eye Hospital","Venkatawasra Clinic","Sri Balaji Hospitals","T.V Ram Hospital"],
   'Sathupally':["Yashodha Ent Hospital","Kasturiram Multispeciality Hospital","Lalithakumari Hospital"],
   'Malkapur':[" VIDYAVISHWA HOSPITAL","Manas Hospital","Kolte Hospital","Nityaseva Hospital","Ayushmaan Hospital"],
   'Mukarampura':["HARINI HOSPITAL","Vasara Multispeciality Hospital","CVVM Hospital","City Hospital"],
   'Nagulamallial':["Yashoda Krishna Hospital","Fortune Medcare Hospitals","Surabhi Multispeciality Hospital"],
   'Thippapuram':["Siri Hospital","Ashwini Hospital","Jeevadhara Hospital"],
   'Bodhan':["Lions Eye Hospital","Sri Himalaya Skin Hospital","Sri balaji hospital"],
   'Manikbhandar':["Chandamama Hospitals","Sunrise Super Speciality Hospital","SS Balaji Hospital","Dr. B Keshavulu Hospital"],
   'Ghatanji':["Yavatmal Brain and Spine Centre","Christian Hospital","Chrome Hospital"],
   'Nirmal':["Lalitha Multispeciality Hospital","Nirmal Neuro Hospital","Gandhi Skin Hospital"],
};
 
 
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in kilometers
  return Math.floor(distance);
}
 
const generateRandomValue = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};
const Map11 = () => {
  const [uniqueCities, setUniqueCities] = useState([]);
  const [nearbyOptions, setNearbyOptions] = useState([]);
  const [locations, setLocations] = useState([]);
  const [mapCenter, setMapCenter] = useState({ lat: 15.385, lng: 78.486 });
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedNearby, setSelectedNearby] = useState('');
  const [selectedDestinationCity, setSelectedDestinationCity] = useState('');
  const [selectedDestinationNearby, setSelectedDestinationNearby] = useState('');
  const [destination, setDestination] = useState(null);
  const [directions, setDirections] = useState(null);
  const [showDirectionsDashboard, setShowDirectionsDashboard] = useState(false);
  const [nearbyOptionsForDestination, setNearbyOptionsForDestination] = useState([]);
 
 
  useEffect(() => {
    axios.get('http://localhost:5000/api/locationss')
      .then((response) => {
        const data = response.data;
        setLocations(data);
        const uniqueCitiesData = [...new Set(data.map(location => location.city))];
        setUniqueCities(uniqueCitiesData);
        const uniqueNearbyData = [...new Set(data.map(location => location.nearby))];
        setNearbyOptions(uniqueNearbyData);
 
        if (data.length > 0) {
          setMapCenter({
            lat: data[0].latitude,
            lng: data[0].longitude,
          });
        }
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);
 
  const mapStyles = {
    height: '400px',
    width: '100%',
  };
 
  // const handleCityChange = (event) => {
  //   const selected = event.target.value;
  //   setSelectedCity(selected);
  //   setSelectedNearby('');
  //   setDestination(null);
 
  //   const selectedCityLocation = locations.find(location => location.city === selected);
  //   if (selectedCityLocation) {
  //     setMapCenter({
  //       lat: parseFloat(selectedCityLocation.latitude),
  //       lng: parseFloat(selectedCityLocation.longitude),
  //     });
  //   }
 
  //   // Filter nearby options based on the selected city
  //   const nearbyOptionsForSelectedCity = locations
  //     .filter(location => location.city === selected)
  //     .map(location => location.nearby);
 
  //   setNearbyOptions([...new Set(nearbyOptionsForSelectedCity)]);
  // };
 
  const handleNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedNearby(selected);
    setDestination(null);
 
    const selectedNearbyLocation = locations.find(location => location.nearby === selected);
    if (selectedNearbyLocation) {
      setMapCenter({
        lat: parseFloat(selectedNearbyLocation.latitude),
        lng: parseFloat(selectedNearbyLocation.longitude),
      });
    }
  };
 
  const handleCityChange = (event) => {
    const selected = event.target.value;
    setSelectedCity(selected);
    setSelectedNearby('');
    setDestination(null);
 
    // Filter nearby options based on the selected origin city
    const nearbyOptionsForSelectedCity = locations
      .filter(location => location.city === selected)
      .map(location => location.nearby);
 
    setNearbyOptions([...new Set(nearbyOptionsForSelectedCity)]);
  };
 
  const handleDestinationCityChange = (event) => {
    const selected = event.target.value;
    setSelectedDestinationCity(selected);
    setSelectedDestinationNearby('');
    setDestination(null);
 
    // Filter nearby options based on the selected destination city
    const nearbyOptionsForSelectedDestinationCity = locations
      .filter(location => location.city === selected)
      .map(location => location.nearby);
 
    setNearbyOptionsForDestination([...new Set(nearbyOptionsForSelectedDestinationCity)]);
  };
 
  const handleDestinationNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedDestinationNearby(selected);
    setDestination(null);
  };
 
  const handleGetDirections = () => {
    const originLatLng = locations.find(location => location.city === selectedCity && location.nearby === selectedNearby);
    const destinationLatLng = locations.find(location => location.city === selectedDestinationCity && location.nearby === selectedDestinationNearby);
 
    if (originLatLng && destinationLatLng) {
      const origin = {
        lat: parseFloat(originLatLng.latitude),
        lng: parseFloat(originLatLng.longitude),
      };
 
      const destination = {
        lat: parseFloat(destinationLatLng.latitude),
        lng: parseFloat(destinationLatLng.longitude),
      };
 
      const directionsService = new window.google.maps.DirectionsService();
      directionsService.route(
        {
          origin: origin,
          destination: destination,
          travelMode: window.google.maps.TravelMode.DRIVING,
        },
        (result, status) => {
          if (status === window.google.maps.DirectionsStatus.OK) {
            setDirections(result);
            setShowDirectionsDashboard(true);
          } else {
            console.error('Directions request failed due to ' + status);
          }
        }
      );
    }
  };
 
  return (
    <div>
     
     
      <div className="a-container">
        <div className='a2'>
          <div>
            <h4>Origin</h4>
            <select value={selectedCity} onChange={handleCityChange} className='select my-3'>
              <option value="">Select an origin city</option>
              {uniqueCities.map((city, index) => (
                <option key={index} value={city}>
                  {city}
                </option>
              ))}
            </select>
 
            <select value={selectedNearby} onChange={handleNearbyChange} className='select my-3'>
              <option value="">Select a nearby option</option>
              {nearbyOptions.map((nearby, index) => (
                <option key={index} value={nearby}>
                  {nearby}
                </option>
              ))}
            </select>
          </div>
          <div>
            <h4>Destination</h4>
            <select value={selectedDestinationCity} onChange={handleDestinationCityChange} className='select my-3'>
              <option value="">Select a destination city</option>
              {uniqueCities.map((city, index) => (
                <option key={index} value={city}>
                  {city}
                </option>
              ))}
            </select>
 
            <select value={selectedDestinationNearby} onChange={handleDestinationNearbyChange} className='select my-3'>
  <option value="">Select a nearby option for destination</option>
  {nearbyOptionsForDestination.map((nearby, index) => (
    <option key={index} value={nearby}>
      {nearby}
    </option>
  ))}
</select>
          </div>
          <button onClick={handleGetDirections}>
            Get Directions
          </button>
        </div>
      </div>
     
       <h1 style={{ textAlign: 'center' }}>Map with Locations</h1>
      <LoadScript googleMapsApiKey="AIzaSyCGhHNoTUpRQo4WQxmfUDzGTlZUcAYSvCg">
        <GoogleMap mapContainerStyle={mapStyles} zoom={5} center={mapCenter}>
          {showDirectionsDashboard && directions && (
            <DirectionsRenderer
              directions={directions}
              options={{
                polylineOptions: {
                  strokeColor: 'black',
                  strokeOpacity: 1,
                  strokeWeight: 4,
                },
              }}
            />
          )}
        </GoogleMap>
      </LoadScript>
 
     
    </div>
  );
  };
 
const SearchForm = () => {
  const [distance, setDistance] = useState(null);
  const [base_fare, setbase_fare] = useState(null);
  const [driver_allowance, setdriver_allowance] = useState(null);
  const [gst, setgst] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [liveLocation, setLiveLocation] = useState(null);
  const [additionalCharge, setAdditionalCharge] = useState(null);
 
  const [selectedDestination, setSelectedDestination] = useState("");
  const [allFieldsSelected, setAllFieldsSelected] = useState(false);
 
  const [localDate, setLocalDate] = useState("");
  const today = new Date().toISOString().split("T")[0];
 
  const handleDestinationChange = (event) => {
    setSelectedDestination(event.target.value);
  };
 
  const handleDistanceCalculation = () => {
    if (selectedCity && selectedLocation && selectedHospital) {
      setAllFieldsSelected(true);
      setShowPopup(true);
    } else {
      // Handle the case where not all fields are selected
      console.log("Please select all fields");
    }
    // const city = cities.find(city => city.name === selectedCity);
  // const destCity = cities.find(city => city.name === selectedDestCity);
 
  // Update the handleDistanceCalculation function in your React component
  const randomValue = generateRandomValue(500, 1800);
  setAdditionalCharge(randomValue);
  // ... (previous code)
 
  axios.post('http://localhost:5000/api/fare_breakup', {
    distance: distance,
    base_fare: base_fare,
    driver_allowance: driver_allowance,
    gst: gst,
    additional_charge: randomValue,
    total_cost: parseFloat(base_fare) + parseFloat(driver_allowance) + parseFloat(gst) + randomValue,
  })
  .then(response => {
    console.log('Data sent to backend successfully:', response.data);
    // Optionally, you can perform additional actions after successful data submission
  })
  .catch(error => {
    console.error('Error sending data to backend:', error);
    // Handle the error, e.g., display an error message to the user
  });
 
  axios
  .post('http://localhost:5000/api/search', {
    city: selectedCity,
    location: selectedLocation,
    Hospital: selectedHospital,
    Date: selectedDateTime,
    destination_city: selectedDestCity,
    destination_location: selectedDestination,
  })
  .then((response) => {
    console.log('Data sent to backend successfully:', response.data);
    // Optionally, you can perform additional actions after successful data submission
  })
  .catch((error) => {
    console.error('Error sending data to backend:', error);
    // Handle the error, e.g., display an error message to the user
  });
 
 
  // if (city && destCity) {
  //   const dist = calculateDistance(
  //     city.lat,
  //     city.lng,
  //     destCity.lat,
  //     destCity.lng
  //   );
 
  //   setDistance(dist);
 
  //   // Now, you can calculate other details such as basic price, driver allowance, GST, etc.
  //   const base_fare = parseFloat(dist) * 15; // Assuming price is 15 rupees per kilometer
  //   const driver_allowance = parseFloat(dist) * 3; // Assuming 1 rupee per kilometer for driver allowance
  //   const gst = (base_fare + driver_allowance) * 0.05; // Assuming 5% GST
 
  //   setbase_fare(base_fare.toFixed(2));
  //   setdriver_allowance(driver_allowance.toFixed(2));
  //   setgst(gst.toFixed(2));
 
  //   // Open the popup
  //   setShowPopup(true);
  // }
  // else {
  //   console.log("Invalid city selection");
  //   setDistance(null);
  // }
 
 
};
 
  const onMarkerClick = (markerText) => {
    // Set the selected city when a marker is clicked
    setSelectedCity(markerText);
  };
 
  const handleClosePopup = () => {
    // Close the popup
    setShowPopup(false);
  };
 
  const onClickCombined = () => {
    handleDistanceCalculation();
  handleGetDirections();
    handleClosePopup();
  }
 
 
 
 
  const getCurrentDay = () => {
    const today = new Date();
    const options = { weekday: "long" };
    const day = today.toLocaleDateString(undefined, options);
    setLocalDate(day);
  };
  const countryCode = "IN";
  const countryState = State.getStatesOfCountry(countryCode);
  // const cities = ; ["Hyderabad", "Bangalore", "Kadapa"];
 
  const ambulanceList = [
    {city: 'Vijayawada', location: 'Benz Circle', hospital: 'Trust Hospital', ambulanceId: 1, imageUrl: 'amb1.jpg', price: '$ 14500'},
    {city: 'Vijayawada', location: 'Benz Circle', hospital: 'Trust Hospital', ambulanceId: 2, imageUrl: 'amb3.jfif', price: '$ 16500'},
    {city: 'Vijayawada', location: 'Benz Circle', hospital: 'Trust Hospital', ambulanceId: 3, imageUrl: 'amb2.jpg', price: '$ 15500'},
    {city: 'Madhapur', location: 'Kondapur', hospital: 'Care Hospital Malakpet', ambulanceId: 1, imageUrl: 'amb1.jpg', price: '$ 3500'},
    {city: 'Madhapur', location: 'Kondapur', hospital: 'Care Hospital Malakpet', ambulanceId: 3, imageUrl: 'amb1.jpg', price: '$ 5000'},
    {city: 'Ameerpet', location: 'Begumpet', hospital: 'Svastha Hospital', ambulanceId: 2, imageUrl: 'amb2.jpg', price: '$ 4500'},
    {city: 'Ameerpet', location: 'Begumpet', hospital: 'Svastha Hospital', ambulanceId: 4, imageUrl: 'amb1.jpg', price: '$ 4000'},
  ];
  const [nearbyAreasList, setNearbyAreasList] = useState([]);
  const [selectedNearby, setSelectedNearby] = useState("");
  const [selectedState, setSelectedState] = useState("");
  const [citiesList, setcitiesList] = useState([]);
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedDestCity, setSelectedDestCity] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");
  const [locationsList, setlocationsList] = useState([]);
  const [selectedHospital, setSelectedHospital] = useState("");
  // const [selectedDate, setSelectedDate] = useState('');
  const [searched, setSearched] = useState(false);
  const [directionsPath, setDirectionsPath] = useState(null);
  // const handleNearbyChange = (nearby) => {
  //   setSelectedNearby1(nearby);
  // };
  const handleStateChange = (event) => {
    setSelectedState(event.target.value);
    setcitiesList(City.getCitiesOfState(countryCode, event.target.value));
    setSelectedLocation("");
    setSelectedHospital("");
  };
  const handleCityChange = (event) => {
    setSelectedCity(event.target.value);
    setSelectedLocation("");
    setSelectedHospital("");
    setAllFieldsSelected(false);
  };
 
  // Similarly, update other field change handlers
 
  const handleDestCityChange = (event) => {
    setSelectedDestCity(event.target.value);
   
  };
 
  const handleLocationChange = (event) => {
    setSelectedLocation(event.target.value);
    setSelectedHospital("");
  };
 
  const handleHospitalChange = (event) => {
    setSelectedHospital(event.target.value);
  };
 const navigate = useNavigate();
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    // setSearched(true);
    handleDistanceCalculation();
    navigate("./vehicles");
  };
 
  // const navigate = useNavigate();
  // const routeChange = () => {
  //   navigate('/Vehicles');
  // }
 
  const getMinDateTime = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
 
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };
 
  const [selectedDateTime, setSelectedDateTime] = useState(getMinDateTime());
 
  const handleDateTimeChange = (event) => {
    setSelectedDateTime(event.target.value);
  };  
  const [selectedLocality2, setSelectedLocality2] = useState('');
  const [selectedLocality, setSelectedLocality] = useState('');
  const [locations, setLocations] = useState([]);
  const [highlightedLocation, setHighlightedLocation] = useState(null);
  const [selectedCity1, setSelectedCity1] = useState('');
  const [selectedCity2, setSelectedCity2] = useState('');
  const [mapCenter, setMapCenter] = useState({ lat: 15.385, lng: 78.486 });
  const uniqueCities = [...new Set(locations.map(location => location.city))];
  const [selectedNearby1, setSelectedNearby1] = useState('');
  const [selectedNearby2, setSelectedNearby2] = useState('');
  const [nearbyOptions1, setNearbyOptions1] = useState([]);
  const [nearbyOptions2, setNearbyOptions2] = useState([]);
  const [directions, setDirections] = useState(null);
  const [showDirectionsDashboard, setShowDirectionsDashboard] = useState(false);
  const [selectedNearBy, setSelectedNearBy] = useState('');
  const [nearbyOptions, setNearbyOptions] = useState([]);
 
  // const [uniqueCities, setUniqueCities] = useState([]);
  // const [locations, setLocations] = useState([]);
  // const [nearbyOptions, setNearbyOptions] = useState([]);
 
  // const [selectedCity, setSelectedCity] = useState('');
  const [localitiesForSource, setLocalitiesForSource] = useState([]);
  const [nearbyOptionsForSource, setNearbyOptionsForSource] = useState([]);
  // const [selectedLocality, setSelectedLocality] = useState('');
  // const [selectedNearby, setSelectedNearby] = useState('');
 
  // const [selectedCity2, setSelectedCity2] = useState('');
  const [localitiesForDestination, setLocalitiesForDestination] = useState([]);
  const [nearbyOptionsForDestination, setNearbyOptionsForDestination] = useState([]);
  // const [selectedLocality2, setSelectedLocality2] = useState('');
  // const [selectedNearby2, setSelectedNearby2] = useSta
 
  const handleNearByChange = (event) => {
    const selected = event.target.value;
    setSelectedNearBy(selected);
  };
 
 
  const uniqueLocalities = [...new Set(locations.filter(location => location.city === selectedCity).map(location => location.locality))];
 
 
  useEffect(() => {
    axios.get('http://localhost:5000/api/locationss')
      .then((response) => {
        const data = response.data;
        setLocations(data);
 
        if (data.length > 0) {
          setMapCenter({
            lat: data[0].latitude,
            lng: data[0].longitude,
          });
          setHighlightedLocation(data[0]);
        }
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);
// Define initial state using useState
const [hospital, setHospital] = useState({
  city: 0,
  nearby: 0,
  name: 0,
   // Consider changing this property name to something else to avoid conflicts with reserved names
});
 
useEffect(() => {
  axios
    .get('http://localhost:5000/api/locationss')
    .then((response) => {
      console.log('Location not fetched:', response.data);
      const lastRow = response.data[response.data.length-1];
 
      // Update state using setHospital function by passing a callback to ensure proper update based on previous state
      setHospital(prevState => ({
        ...prevState,
        city: lastRow.city, // Replace city with the appropriate property from lastRow
        nearby: lastRow.nearby, // Replace nearby with the appropriate property from lastRow
        // Update other properties as needed
      }));
    })
    .catch((error) => {
      console.error('Error fetching fare details:', error);
    });
}, []);
 
  // const handleCityChange1 = (event) => {
  //   const selected = event.target.value;
  //   setSelectedCity(selected);
  //   setSelectedHospital('');
 
  //   const selectedCityLocation = locations.find(location => location.city === selected);
  //   if (selectedCityLocation) {
  //     setMapCenter({
  //       lat: parseFloat(selectedCityLocation.latitude),
  //       lng: parseFloat(selectedCityLocation.longitude),
  //     });
  //   }
  // };
  // const handleCityChange2 = (event) => {
  //   const selected = event.target.value;
  //   setSelectedCity2(selected);
  //   setSelectedHospital('');
 
  //   const selectedCityLocation2 = locations.find(location => location.city === selected);
  //   if (selectedCityLocation2) {
  //     setMapCenter({
  //       lat: parseFloat(selectedCityLocation2.latitude),
  //       lng: parseFloat(selectedCityLocation2.longitude),
  //     });
  //   }
  // };
 
  // const handleCityChange2 = (event) => {
  //   const selected = event.target.value;
  //   setSelectedCity2(selected);
  //   setSelectedHospital('');
 
  //   const selectedCityLocation = locations.find(location => location.city === selected);
  //   if (selectedCityLocation) {
  //     setMapCenter({
  //       lat: parseFloat(selectedCityLocation.latitude),
  //       lng: parseFloat(selectedCityLocation.longitude),
  //     });
  //   }
 
  //   // Update nearby options for the second city
  //   setNearbyOptions2(nearbyOptions2[selected] || []);
  // };
  // const handleLocalityChange = (event) => {
  //   const selectedLocality = event.target.value;
  //   setSelectedLocality(selectedLocality);
  //   setSelectedNearby(''); // Reset selected nearby when locality changes
 
  //   // Filter locations based on the selected locality
  //   const filteredLocations = locations.filter(location => location.locality === selectedLocality);
 
  //   // Extract unique categories and nearby options for the selected locality
  //   const uniqueCategoriesForLocality = [...new Set(filteredLocations.map(location => location.category))];
  //   const uniqueNearbyForLocality = [...new Set(filteredLocations.map(location => location.nearby))];
 
  //   // Update the state variables with the new category and nearby options for the selected locality
  //   setNearbyOptions(uniqueNearbyForLocality);
 
  //   // If needed, set the map center to the coordinates of the selected locality
  //   const selectedLocalityCoordinates = filteredLocations[0]; // Assuming the first location in the filtered list represents the selected locality
  //   if (selectedLocalityCoordinates) {
  //     setMapCenter({
  //       lat: parseFloat(selectedLocalityCoordinates.latitude),
  //       lng: parseFloat(selectedLocalityCoordinates.longitude),
  //     });
  //   }
  //   // Other logic as per your requirements
  // };
  // const handleLocalityChange2 = (event) => {
  //   const selectedLocality2 = event.target.value;
  //   setSelectedLocality2(selectedLocality2);
  //   setSelectedNearby2(''); // Reset selected nearby when locality changes
 
  //   // Filter locations based on the selected locality
 
  //   const filteredLocations = locations.filter(location => location.locality2 === selectedLocality2);
 
  //   // Extract unique categories and nearby options for the selected locality
  //   const uniqueCategoriesForLocality = [...new Set(filteredLocations.map(location => location.category))];
  //   const uniqueNearbyForLocality = [...new Set(filteredLocations.map(location => location.nearby))];
 
  //   // Update the state variables with the new category and nearby options for the selected locality
  //   setNearbyOptions2(uniqueNearbyForLocality); // Assuming setNearbyOptions2 is a separate state variable for the second select
 
  //   // If needed, set the map center to the coordinates of the selected locality
  //   const selectedLocalityCoordinates = filteredLocations[0]; // Assuming the first location in the filtered list represents the selected locality
  //   if (selectedLocalityCoordinates) {
  //     setMapCenter({
  //       lat: parseFloat(selectedLocalityCoordinates.latitude),
  //       lng: parseFloat(selectedLocalityCoordinates.longitude),
  //     });
  //   }
  //   // Other logic as per your requirements
  // };
  // const handleNearbyChange = (event) => {
  //   const selected = event.target.value;
  //   setSelectedNearby(selected);
 
  //   // Perform logic to get directions from current location to the selected nearby location
  //   const destinationLatLng = {
  //     lat: parseFloat(locations.find(loc => loc.nearby === selected)?.latitude || 0),
  //     lng: parseFloat(locations.find(loc => loc.nearby === selected)?.longitude || 0),
  //   };
 
  //   if (navigator.geolocation) {
  //     navigator.geolocation.getCurrentPosition(
  //       (position) => {
  //         const origin = {
  //           lat: position.coords.latitude,
  //           lng: position.coords.longitude,
  //         };
  //         const directionsService = new window.google.maps.DirectionsService();
  //         directionsService.route(
  //           {
  //             origin: origin,
  //             destination: destinationLatLng,
  //             travelMode: window.google.maps.TravelMode.DRIVING,
  //           },
  //           (result, status) => {
  //             if (status === window.google.maps.DirectionsStatus.OK) {
  //               setDirections(result);
  //               setShowDirectionsDashboard(true);
  //             } else {
  //               console.error('Directions request failed due to ' + status);
  //             }
  //           }
  //         );
  //       },
  //       (error) => {
  //         console.error('Error getting user location:', error);
  //       }
  //     );
  //   } else {
  //     console.error('Geolocation is not supported by this browser.');
  //   }
  // };
  // const handleNearbyChange2 = (event) => {
  //   const selected = event.target.value;
  //   setSelectedNearby2(selected);
 
  //   // Perform logic to get directions from current location to the selected nearby location
  //   const destinationLatLng = {
  //     lat: parseFloat(locations.find(loc => loc.nearby === selected)?.latitude || 0),
  //     lng: parseFloat(locations.find(loc => loc.nearby === selected)?.longitude || 0),
  //   };
 
  //   if (navigator.geolocation) {
  //     navigator.geolocation.getCurrentPosition(
  //       (position) => {
  //         const origin = {
  //           lat: position.coords.latitude,
  //           lng: position.coords.longitude,
  //         };
  //         const directionsService = new window.google.maps.DirectionsService();
  //         directionsService.route(
  //           {
  //             origin: origin,
  //             destination: destinationLatLng,
  //             travelMode: window.google.maps.TravelMode.DRIVING,
  //           },
  //           (result, status) => {
  //             if (status === window.google.maps.DirectionsStatus.OK) {
  //               setDirections(result);
  //               setShowDirectionsDashboard(true);
  //             } else {
  //               console.error('Directions request failed due to ' + status);
  //             }
  //           }
  //         );
  //       },
  //       (error) => {
  //         console.error('Error getting user location:', error);
  //       }
  //     );
  //   } else {
  //     console.error('Geolocation is not supported by this browser.');
  //   }
  // };
  const handleCityChange1 = (event) => {
    const selected = event.target.value;
    setSelectedCity(selected);
    // setSelectedLocality('');
    setSelectedNearby('');
    setSelectedHospital('');
    setSelectedDateTime('');
 
    const selectedCityLocation = locations.find(location => location.city === selected);
    if (selectedCityLocation) {
    }
 
    const filteredLocationsForSource = locations.filter(location => location.city === selected);
    const uniqueLocalitiesForSource = [...new Set(filteredLocationsForSource.map(location => location.locality))];
    const uniqueNearbyForSource = [...new Set(filteredLocationsForSource.map(location => location.nearby))];
 
    setLocalitiesForSource(uniqueLocalitiesForSource);
    setNearbyOptionsForSource(uniqueNearbyForSource);
  };
 
  const handleCityChange2 = (event) => {
    const selected = event.target.value;
    setSelectedCity2(selected);
    setSelectedNearby2('');
 
    const selectedCityLocation2 = locations.find(location => location.city === selected);
    if (selectedCityLocation2) {
      // Set map center or perform other actions for the destination city
    }
 
    // Update localities and nearby options for the destination city
    const filteredLocationsForDestination = locations.filter(location => location.city === selected);
    const uniqueLocalitiesForDestination = [...new Set(filteredLocationsForDestination.map(location => location.locality2))];
    const uniqueNearbyForDestination = [...new Set(filteredLocationsForDestination.map(location => location.nearby))];
 
    setLocalitiesForDestination(uniqueLocalitiesForDestination);
    setNearbyOptionsForDestination(uniqueNearbyForDestination);
  };
 
  const handleLocalityChange = (event) => {
    const selectedLocality = event.target.value;
    setSelectedLocality(selectedLocality);
    setSelectedNearby('');
    // Other logic as needed
  };
 
  const handleLocalityChange2 = (event) => {
    const selectedLocality2 = event.target.value;
    setSelectedLocality2(selectedLocality2);
    setSelectedNearby2('');
    // Other logic as needed
  };
 
  const handleNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedNearby(selected);
    setSelectedHospital('');
    // Other logic as needed
  };
 
  // const handleNearbyChange2 = (event) => {
  //   const selected = event.target.value;
  //   setSelectedNearby2(selected);
  //   // Other logic as needed
  // };
 
  const handleGetDirections = (startLocation, endLocation) => {
    const directionsService = new window.google.maps.DirectionsService();
    directionsService.route(
      {
        origin: startLocation,
        destination: endLocation,
        travelMode: window.google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === window.google.maps.DirectionsStatus.OK) {
          setDirectionsPath(result);
          setShowDirectionsDashboard(true);
        } else {
          console.error('Directions request failed due to ' + status);
        }
      }
    );
  };
  const handleNearbyChange2 = (event) => {
    const selected = event.target.value;
    setSelectedNearby2(selected);
 
    const startLocation = {
      lat: parseFloat(locations.find(loc => loc.nearby === selectedNearby)?.latitude || 0),
      lng: parseFloat(locations.find(loc => loc.nearby === selectedNearby)?.longitude || 0),
    };
 
    const endLocation = {
      lat: parseFloat(locations.find(loc => loc.nearby === selected)?.latitude || 0),
      lng: parseFloat(locations.find(loc => loc.nearby === selected)?.longitude || 0),
    };
 
    handleGetDirections(startLocation, endLocation);
  };
 
  return (
    <div>
 
     
      <div className="bg-clr">
            <div className="search-form-container1" style={{height:'auto'}}>  
           
       
           
            <form onSubmit={handleSubmit}>
                <h2  style={{ textAlign:'center',color:'white' }}>Start Your Search</h2>
            <div className="row">
           
              <div className="col-md-6">
              <div>
        {/* <select value={selectedCity} onChange={(e) => setSelectedCity(e.target.value)}>
          <option value="">Select Source City</option>
          {cities.map(city => (
            <option key={city.id} value={city.name}>{city.name}</option>
          ))}
        </select> */}
          <select value={selectedCity} onChange={handleCityChange1} className='select my-3'>
        <option value="">Select a city</option>
        {uniqueCities.map((city, index) => (
          <option key={index} value={city}>
            {city}
          </option>
        ))}
      </select>
      </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                {/* <select
                    value={selectedLocation}
                    onChange={handleLocationChange}
                    required
                  >
                    <option value="">
                     Select Source Location
                    </option>
                    &nbsp&nbsp
                    {nearbyAreas[selectedCity] &&
                      nearbyAreas[selectedCity].map((location) => (
                        <option key={location} value={location}>
                          {location}
                        </option>
                      ))}
                  </select> */}
                    {/* <select value={selectedLocality} onChange={handleLocalityChange} className='select my-3'>
        <option value="">Select a Locality</option>
        {localitiesForSource.map((locality, index) => (
          <option key={index} value={locality}>
            {locality}
          </option>
        ))}
      </select> */}
      <select value={selectedNearby} onChange={handleNearbyChange} className='select my-3'>
        <option value="">Select a Nearby Option</option>
        {nearbyOptionsForSource.map((nearby, index) => (
          <option key={index} value={nearby}>
            {nearby}
          </option>
        ))}
      </select>
 
 
                 
                </div>
              </div>
            </div>
                       
            <div className="row py-3">
              <div className="col-md-6">
                <div className="form-group">
                  <select
                    value={selectedHospital}
                    onChange={handleHospitalChange}
                  >
                    <option value="">
                      Select Hospital
                    </option>
                    {hospitalsByLocation[selectedLocation] &&
                      hospitalsByLocation[selectedLocation].map((hospital) => (
                        <option key={hospital} value={hospital}>
                          {hospital}
                        </option>
                      ))}
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                <Form.Control
            type="datetime-local"
            value={selectedDateTime}
            onChange={handleDateTimeChange}
            className="mx-0"
            aria-label="Date and Time"
            min={getMinDateTime()}
            required
                  />
                </div>
              </div>
            </div>
            <div className="row">
            <div className="col-md-6">
                <div className="form-group">
                {/* <select value={selectedDestCity} onChange={(e) => setSelectedDestCity(e.target.value)}>
          <option value="">Select Destination City</option>
          {cities.map(city => (
            <option key={city.id} value={city.name}>{city.name}</option>
          ))}
        </select> */}
         <select value={selectedCity2} onChange={handleCityChange2} className='select my-3'>
        <option value="">Select a city</option>
        {uniqueCities.map((city, index) => (
          <option key={index} value={city}>
            {city}
          </option>
        ))}
      </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  {/* <select
                    value={selectedDestination}
                    onChange={handleDestinationChange}
                    required
                  >
                    <option value="">
                      Select Destination
                    </option>
                    {nearbyAreas[selectedDestCity] &&
                      nearbyAreas[selectedDestCity].map((location) => (
                        <option key={location} value={location}>
                          {location}
                        </option>
                      ))}
                  </select> */}
 
{/* <select value={selectedLocality2} onChange={handleLocalityChange2} className='select my-3'>
        <option value="">Select a Locality</option>
        {localitiesForDestination.map((locality, index) => (
          <option key={index} value={locality}>
            {locality}
          </option>
        ))}
      </select> */}
      <select value={selectedNearby2} onChange={handleNearbyChange2} className='select my-3'>
        <option value="">Select a Nearby Option</option>
        {nearbyOptionsForDestination.map((nearby, index) => (
          <option key={index} value={nearby}>
            {nearby}
          </option>
        ))}
      </select>
                </div>
              </div>
            </div>
            <div style={{display:'flex',justifyContent:'center'}}>
           <Button style={{ backgroundColor:'#00ab9f', color:'white'}} onClick={handleDistanceCalculation} type="submit">Search</Button></div>
          </form>
         
          {allFieldsSelected && showPopup && (
      <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0, 0, 0, 0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div style={{ background: '#fff', padding: '20px', borderRadius: '5px', textAlign: 'center' }}>
          <div className="row">
          <div className="col-md-6">
            <p>{`Distance between ${selectedCity} and ${selectedDestCity}:`}</p>
            <p>{`Basic Price: `}</p>
            <p>{`Driver Allowance:`}</p>
            <p>{`GST: `}</p>
            <p>{`Additional Charge:`}</p>
          </div>
          <div className="col-md-6">
            <p>{`₹${distance} km`}</p>
            <p>{`₹${base_fare}`}</p>
            <p>{`₹${driver_allowance}`}</p>
            <p>{`₹${gst}`}</p>
            <p>{`₹${additionalCharge}`}</p>
          </div>
          </div>
          <hr></hr>
          <p>{`Total Price: ₹${parseFloat(base_fare) + parseFloat(driver_allowance) + parseFloat(additionalCharge) + parseFloat(gst)}`}</p>
         
          <button onClick={onClickCombined}>Close</button>
        </div>
       
      </div>
      )}
         
        {/* )} */}
      </div>
    </div>
    <div><Map11 /></div>
    </div>
 
  );
};
 
export default SearchForm;