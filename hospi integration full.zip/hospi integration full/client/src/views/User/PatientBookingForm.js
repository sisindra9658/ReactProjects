// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const PatientBookingForm = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     contact: '',
//     email: '',
//     address: ''
//   });

//   useEffect(() => {
//     const handleSuccess = (response) => {
//       console.log('Data submitted successfully:', response.data);  
//     };

//     const handleError = (error) => {
//       console.error('Error submitting data:', error);
//     };


//     if (formData.name && formData.contact && formData.email && formData.address) {   
//       axios.post('http://localhost:5001/api/patient_booking', formData)
//         .then(handleSuccess)
//         .catch(handleError);
//     }
//   }, [formData]);

  
//   const handleInputChange = (event) => {
//     const { name, value } = event.target;
//     setFormData({ ...formData, [name]: value });
//   };

 
//   const handleSubmit = (event) => {
//     event.preventDefault();  
      
//       if (formData.name && formData.contact && formData.email && formData.address) {
        
//         axios.post('http://localhost:5001/api/patient_booking', formData)
//           .then(response => {
//             console.log('Data submitted successfully:', response.data);
           
//           })
//           .catch(error => {
//             console.error('Error submitting data:', error);
            
//           });
//       }
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <label>
//         Name:
//         <input type="text" name="name" value={formData.name} onChange={handleInputChange} />
//       </label>
//       <br />
//       <label>
//         Contact:
//         <input type="text" name="contact" value={formData.contact} onChange={handleInputChange} />
//       </label>
//       <br />
//       <label>
//         Email:
//         <input type="email" name="email" value={formData.email} onChange={handleInputChange} />
//       </label>
//       <br />
//       <label>
//         Address:
//         <input type="text" name="address" value={formData.address} onChange={handleInputChange} />
//       </label>
//       <br />
//       <button type="submit">Submit</button>


       
//     </form>
//   );
// };

// export default PatientBookingForm;



import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const PatientBookingForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    email: '',
    address: ''
  });

  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    const handleSuccess = (response) => {
      console.log('Data submitted successfully:', response.data);  
    };

    const handleError = (error) => {
      console.error('Error submitting data:', error);
    };

    if (formData.name && formData.contact && formData.email && formData.address) {   
      axios.post('http://localhost:5001/api/patient_booking', formData)
        .then(handleSuccess)
        .catch(handleError);
    }
  }, [formData]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();  
      
    if (formData.name && formData.contact && formData.email && formData.address) {
      axios.post('http://localhost:5001/api/patient_booking', formData)
        .then(response => {
          console.log('Data submitted successfully:', response.data);
        })
        .catch(error => {
          console.error('Error submitting data:', error);
        });
    }
  };

  const handleBookingButtonClick = () => {
    setShowForm(true);
  };

  return (
    // <div>
    //   <button type="button" onClick={handleBookingButtonClick}>
    //     Book Now
    //   </button>

    //   {showForm && (
    //     <form onSubmit={handleSubmit}>
    //       <label>
    //         Name:
    //         <input type="text" name="name" value={formData.name} onChange={handleInputChange} />
    //       </label>
    //       <br />
    //       <label>
    //         Contact:
    //         <input type="text" name="contact" value={formData.contact} onChange={handleInputChange} />
    //       </label>
    //       <br />
    //       <label>
    //         Email:
    //         <input type="email" name="email" value={formData.email} onChange={handleInputChange} />
    //       </label>
    //       <br />
    //       <label>
    //         Address:
    //         <input type="text" name="address" value={formData.address} onChange={handleInputChange} />
    //       </label>
    //       <br />
    //       <button type="submit">Submit</button>
    //     </form>
    //   )}
    // </div>

 <div
      className="modal show"
      style={{ display: 'block', position: 'initial' }}
    >
      <Modal.Dialog>
        <Modal.Header closeButton>
          <Modal.Title>Modal title</Modal.Title>
        </Modal.Header>

        <Modal.Body>
        <div>
      <button type="button" onClick={handleBookingButtonClick}>
        Book Now
      </button>

      {showForm && (
        <form onSubmit={handleSubmit}>
          <label>
            Name:
            <input type="text" name="name" value={formData.name} onChange={handleInputChange} />
          </label>
          <br />
          <label>
            Contact:
            <input type="text" name="contact" value={formData.contact} onChange={handleInputChange} />
          </label>
          <br />
          <label>
            Email:
            <input type="email" name="email" value={formData.email} onChange={handleInputChange} />
          </label>
          <br />
          <label>
            Address:
            <input type="text" name="address" value={formData.address} onChange={handleInputChange} />
          </label>
          <br />
          <button type="submit">Submit</button>
        </form>
      )}
    </div>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary">Close</Button>
          <Button variant="primary">Save changes</Button>
        </Modal.Footer>
      </Modal.Dialog>
    </div>

  );
};

export default PatientBookingForm;

