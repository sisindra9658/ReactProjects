import React, { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import { CgProfile } from "react-icons/cg";
import { FcCallback } from "react-icons/fc";
import { FaFacebook, FaWifi, FaTwitter } from "react-icons/fa";
import { TiSocialGooglePlus } from "react-icons/ti";
import img1 from './Images/image2.png';
import "./Navbar.css";
import { useNavigate } from 'react-router-dom';

function Profile() {
  const navigate = useNavigate(); 

  const [username, setUsername] = useState('');

  useEffect(() => {
    const loadUsername = async () => {
      try {
        const storedUsername = localStorage.getItem('username');
        setUsername(storedUsername);
      } catch (error) {
        console.error('Error fetching username:', error);
      }
    };

    loadUsername();
  }, []);

  const handleProfileClick = () => {
    navigate('/User/my-account');
  };

  const handleProfileKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleProfileClick();
    }
  };

  return (
    <button
      onClick={handleProfileClick}
      onKeyDown={handleProfileKeyPress}
      className="profile-icon"
      title={username}
    >
      <CgProfile style={{ width: '50px', height: '30px' }}  />
    </button>
  );
}

function NavScrollExample1() {
  const navigate = useNavigate();
  const handleMyBookingClick = () => {
    navigate('/User/my-account?tab=1');
  };

  return (
    <div className='navbarrow'>
      <Navbar className="bg-body-tertiary">
        <Container className="navbar-container">
          <div className="navbar-logo">
            <Navbar.Brand href="#">
              <img src={img1} alt="Logo"/>
            </Navbar.Brand>
          </div>
          <div className="navbar-items">
            <div className="navbar-item1">
              <Button onClick={handleMyBookingClick} className="navbar-btn"> My Booking</Button>
            </div>
            <div className="navbar-item">
              <span><FcCallback /></span>
              <span>1800 556 3529</span>
            </div>
            <div className="navbar-item">
              <span><FaFacebook style={{ width: '20px', height: '20px' }} /></span>
            </div>
            <div className="navbar-item">
              <span><FaWifi style={{ width: '20px', height: '20px' }} /></span>
            </div>
            <div className="navbar-item">
              <span><FaTwitter style={{ width: '20px', height: '20px' }} /></span>
            </div>
            <div className="navbar-item">
              <span><TiSocialGooglePlus style={{ width: '20px', height: '20px' }} /></span>
            </div>
            <div className="navbar-item">
              <Profile />
            </div>
          </div>
        </Container>
      </Navbar>
    </div>
  );
}

export default NavScrollExample1;
