 
import React, { useState, useEffect } from 'react';
import { Tab, Tabs, Card, Button, Modal } from '@mui/material';
import { CgProfile } from 'react-icons/cg';
import { Link } from 'react-router-dom';
import { FaWhatsapp } from "react-icons/fa";
import './EditProfilePage.css'; // Import the CSS file
import { TiArrowBack } from "react-icons/ti";
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { logoutUser, clearAccessToken } from 'layout/MainLayout/Header/ProfileSection/logout'; // Importing logoutUser action creator


function EditProfilePage() {
  const [selectedTab, setSelectedTab] = useState(0);
  const [userData, setUserData] = useState({});
  const [showEditModal, setShowEditModal] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    contact_number: '',
    password: ''
  });
  const [selectedOption, setSelectedOption] = useState('');  
  const [searchQuery, setSearchQuery] = useState('');
  const [managingAdminDetails, setManagingAdminDetails] = useState(null);
  const dispatch = useDispatch();

//  const [adminData, setAdminData] = useState(null); // State to store admin data

//  useEffect(() => {
//    const loadUsernameAndAdminData = async () => {
//      try {
//        // Fetch username from local storage
//        const storedUsername = localStorage.getItem('username');
//        setUsername(storedUsername);

//        // Fetch admin data based on the username
//        const response = await axios.get(`http://localhost:5000/api/addadmin/${storedUsername}`);
//        setAdminData(response.data);
//      } catch (error) {
//        console.error('Error fetching data:', error);
//      }
//    };

//    loadUsernameAndAdminData();
//  }, []);

const [userData1, setUserData1] = useState({});

  useEffect(() => {
    const loadUserData = async () => {
      try {
        // Fetch username from local storage
        const storedUsername = localStorage.getItem('username');

        // Fetch user data from backend API
        const response = await axios.get(`http://localhost:5000/api/addadmin/${storedUsername}`);
        setUserData1(response.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    loadUserData();
  }, []);


  // useEffect(() => {
  //   async function fetchData() {
  //     try {
  //       const userResponse = await fetch('http://localhost:5000/user/last');
  //       if (!userResponse.ok) {
  //         throw new Error('Failed to fetch user data');
  //       }
  //       const userData = await userResponse.json();
  //       setUserData(userData);
  //       setFormData(userData);
  //     } catch (error) {
  //       console.error('Error fetching user data:', error);
  //     }
 
  //     try {
  //       const appointmentResponse = await fetch('http://localhost:5000/api/appointment_bookinguser');
  //       const appointmentData = await appointmentResponse.json();
  //       if (appointmentData.success) {
  //         setAppointmentData(appointmentData.data);
  //       }
  //     } catch (error) {
  //       console.error('Error fetching appointment data:', error);
  //     }
  //   }
  //   fetchData();
  // }, []);

    useEffect(() => {
      fetchManagingAdminDetails();
    }, []);

    const fetchManagingAdminDetails = async () => {
      try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/user/${username}`);
      setManagingAdminDetails(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };
 
  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };
 
  const handleSelectChange = (e) => {
    setSelectedOption(e.target.value);
  };
 
  const handleOpenEditModal = () => {
    setShowEditModal(true);
  };
 
  const handleCloseEditModal = () => {
    setShowEditModal(false);
  };
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleLogout = () => {
    dispatch(logoutUser());
    dispatch(clearAccessToken());
    sessionStorage.removeItem('username'); 
  
    const loginTime = localStorage.getItem('loginTime');
    if (loginTime) {
      const currentTime = new Date().getTime();
      const sessionDuration = (currentTime - parseInt(loginTime)) / (1000 * 60);
  
      axios.post('http://localhost:5000/api/logout', { sessionDuration })
        .then(() => {
          console.log('Logout successful');
        })
        .catch(error => {
          console.error('Error during logout:', error);
        });
    }
  
    try {
      window.location.href = 'http://localhost:3000';
    } catch (error) {
      console.error('Error navigating to login page:', error);
    }
  };
 
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`http://localhost:5000/api/user_details/${userData.user_id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      if (!response.ok) {
        throw new Error('Failed to update profile');
      }
      const data = await response.json();
      setUserData(data.data);
      handleCloseEditModal();
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };
 
  const location = useLocation();
 
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const tab = searchParams.get('tab');
    setSelectedTab(tab ? parseInt(tab, 10) : 0);
  }, [location]);
 
  const sendAppointmentDetails = async (phoneNumber, appointment) => {
    try {
      const message = `Appointment Details:\nId: ${appointment.patient_id}\nName: ${appointment.name}\nDoctor: ${appointment.doctor_name}\nClinic: ${appointment.clinic_name}\nAddress: ${appointment.clinic_address}\nDate: ${appointment.booking_date}\nTime: ${appointment.slot_time}\nFee: ${appointment.consultation_fee}\nStatus: ${appointment.status}`;
 
      await axios.post('http://localhost:5000/message', {
        phoneNumber,
        message,
      });
 
      console.log('Appointment details sent successfully');
    } catch (error) {
      console.error('Error sending appointment details:', error);
    }
  };
 
 
  return (
    <div>
      <Link to="/User/Hospital" style={{ position: 'absolute', left: '5%', top: '27%' }}>
        <TiArrowBack style={{ fontSize: "40px" }} />
      </Link>
 
      <Tabs value={selectedTab} onChange={handleTabChange} centered sx={{ background: 'rgb(108, 177, 122)', width: '80%', marginLeft: '10%', height: '60px' }}>
        <Tab label="Profile" sx={{ marginRight: '50px', fontSize: '20px', marginTop: '10px', '&:hover': { color: 'inherit' } }} />
        <Tab label="My Appointments" sx={{ marginRight: '50px', fontSize: '20px', marginTop: '10px', '&:hover': { color: 'inherit' } }} />
        <Tab label="Reports" sx={{ marginRight: '50px', fontSize: '20px', marginTop: '10px', '&:hover': { color: 'inherit' } }} />
      </Tabs>
 
      {selectedTab === 0 && (
        <div className="profile-card-container">
          <Card className="profile-card">
            <div className="profile-icon">
              <CgProfile style={{ fontSize: '80px' }} />
            </div>
            {userData1 && (
            <grid className="user-details">
              <h6><span className="field-name">Username:</span> {userData1.username}</h6>
              <h6><span className="field-name">Email:</span> {userData1.email}</h6>
              <h6><span className="field-name">Contact Number:</span> {userData1.contact_number}</h6>
            </grid>
            )}
            <div className="update-profile-button">
              <Button variant="contained" onClick={handleOpenEditModal} className='button'>Update Profile</Button>
            </div>
            <div>
              <Button onClick={handleLogout}  className='Logout'>Logout</Button>
            </div>
          </Card>
        </div>
      )}
 
      {selectedTab === 1 && (
        <div className="appointment-table">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search appointments..."
              style={{ width: '25%', marginLeft: '10%' }}
            />
            <div style={{ width: '25%', display: 'flex', alignItems: 'center' }}>
              <select value={selectedOption} onChange={handleSelectChange} style={{ width: '60%', marginRight: '10%' }}>
                <option value="">All</option>
                <option value="previous">Past</option>
                <option value="present">Present</option>
                <option value="upcoming">Upcoming</option>
              </select>
            </div>
          </div>
         
          <div className="table-container">
          <table className="styled-table">
            <thead>
              <tr>
                <th>FullName</th>
                <th>Doctor Name</th>
                <th>Clinic Name</th>
                <th>Clinic Address</th>
                <th>Booking date</th>
                <th>Slot time booking</th>
                <th>Fee</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            {managingAdminDetails && managingAdminDetails.map((detail, index) => (
                <tr key={index}>
                  <td>{detail.name}</td>
                  <td>{detail.doctor_name}</td>
                  <td>{detail.clinic_name}</td>
                  <td>{detail.clinic_address}</td>
                  <td>{detail.booking_date}</td>
                  <td>{detail.slot_time}</td>
                  <td>{detail.consultation_fee}</td>
                  <td>{detail.status}</td>
                  <td>
                  <FaWhatsapp
  style={{ fontSize: '30px', marginLeft: '15px', color: 'green', cursor: 'pointer' }}
  onClick={() => sendAppointmentDetails('+99652899470', appointment)}
/>
 
                    </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        </div>
      )}
 
      {selectedTab === 2 && (
        <div className="appointment-table1">
          {/* Content for Reports tab */}
        </div>
      )}
 
      <Modal open={showEditModal} onClose={handleCloseEditModal} aria-labelledby="update-profile-modal-title">
        <div className="update-profile-modal">
          <h2 id="update-profile-modal-title">Update Profile</h2>
          <form onSubmit={handleUpdateProfile}>
            <div className="form-group">
              <label htmlFor="username">Username:</label>
              <input type="text" id="username" name="username" value={formData.username} onChange={handleInputChange} />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} />
            </div>
            <div className="form-group">
              <label htmlFor="contact">Contact Number:</label>
              <input type="text" id="contact" name="contact_number" value={formData.contact_number} onChange={handleInputChange} />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password:</label>
              <input type="password" id="password" name="password" value={formData.password} onChange={handleInputChange} />
            </div>
            <Button variant="contained" type="submit">Update</Button>
          </form>
        </div>
      </Modal>
 
    </div>
  );
}
 
export default EditProfilePage;
 
 
 