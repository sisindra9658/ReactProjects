import React, { useState, useEffect } from 'react';
import { Button } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
// import FormControl from '@mui/material/FormControl';
import Amb5 from './Images/amb5.png';
import { useNavigate } from 'react-router-dom';
// import Navbar from './navbar';
// import Navbar1 from './navbar1';
import Subscribe from './subscribe';
// import Footer from './footer';
// import Footer1 from './footer1';
import './booking1.css';
import axios from 'axios';
 
 
const RedBusPaymentForm = () => {
  const navigate = useNavigate();
  const routeChange = () => {
    navigate('/User/Payment');
  };
 
  // const location = useLocation();
  // const queryParams = new URLSearchParams(location.search);
  // const totalPrice = queryParams.get('price');
 
  const initialTimeRemainingInSeconds = 10 * 60 * 60; // 10 hours in seconds
  const [remainingTime, setRemainingTime] = useState(initialTimeRemainingInSeconds);
 
  useEffect(() => {
    // Update the remaining time every second
    const intervalId = setInterval(() => {
      setRemainingTime((prevTime) => Math.max(0, prevTime - 1)); // Decrease by 1 second
    }, 1000);
 
    // Cleanup function to clear the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, []);
 
  const [cancelationChecked, setCancelationChecked] = useState(false);
 
  const [fareBreakup, setFareBreakup] = useState({
    additional_charge: 0,
  });
 
  useEffect(() => {
    axios
      .get('http://localhost:5000/api/fare_breakup')
      .then((response) => {
        if (response.data && typeof response.data === 'object') {
          setFareBreakup({
            additional_charge: response.data.additional_charge,
          });
        } else {
          console.error('Invalid response data:', response.data);
        }
      })
      .catch((error) => {
        console.error('Error fetching fare details:', error);
      });
  }, []);
 
  return (
    <>
      <div className="row" style={{ marginTop: '50px', display: 'flex', flexWrap: 'wrap' }}>
       
 
      <div className="column" style={{ flex: '2', textAlign: 'center', justifyContent: 'center', marginBottom: '20px', boxShadow: '0 0 5px grey', width: '100%' }}>

    <div style={{ border: 'none' }}>
      <h1 style={{ color: 'black' }}>Booking Form</h1>

      <FormControlLabel
        control={<Checkbox checked={cancelationChecked} onChange={() => setCancelationChecked(!cancelationChecked)} />}
        label="Free cancellation before 10hrs of Journey"
        style={{display:'flex', justifyContent:'center', color:'black'}}
      />
      {cancelationChecked && (
        <div>
          <p style={{ color: 'green', backgroundColor: 'lightgreen', border: 'none' }}>
            Get a full refund in
            <span>{remainingTime !== null && ` ${formatTime(remainingTime)}`} Hours</span>
          </p>
        </div>
      )}
    </div>
    <div className='row' style={{ backgroundColor: 'lightgrey', height: 'auto', padding: '10px', justifyContent: 'space-between', display: 'flex', flexWrap: 'wrap' }}>
      <div className='column' style={{ flex: '1', marginBottom: '10px', textAlign: 'center', border: 'none' }}>
        <h2 style={{ fontSize: '1.5rem' }}>Payment for Equipment Usage</h2>
      </div>
      <div className='column' style={{ flex: '1', textAlign: 'center', border: 'none' }}>
        <h2 style={{ color: 'black', fontSize: '1.5rem', textAlign: 'center' }}> ₹ {fareBreakup.additional_charge} </h2>
        {/* <p style={{ fontSize: '1rem', textAlign: 'center' }}>May Vary Depending on Time</p> */}
      </div>
    </div>
    <p>Payment may vary according to the usage of basic things like stretchers, emergency medicines, portable oxygen, suction devices, first aid kit, and AMBU bags.</p>

    <div style={{ backgroundColor: 'lightgrey' }}>
      <Button style={{ backgroundColor: '#00ab9f', color: 'white', width: '100%' }} onClick={routeChange} type="submit">Proceed to Book</Button>
    </div>
  
</div>

        <div className="column" style={{ flex: '1', marginRight: '20px', boxShadow: '0 0 5px grey' }}>
          <img src={Amb5} alt="ambulance" style={{ width: '100%' }} />
        </div>
      </div>
      <Subscribe />
    </>
  );
};
 
// Function to format remaining time as HH:MM:SS
const formatTime = (timeInSeconds) => {
  const hours = Math.floor(timeInSeconds / 3600);
  const minutes = Math.floor((timeInSeconds % 3600) / 60);
  const seconds = timeInSeconds % 60;
 
  const formattedTime = `${padZero(hours)}:${padZero(minutes)}:${padZero(seconds)}`;
  return formattedTime;
};
 
// Function to pad single-digit numbers with a leading zero
const padZero = (num) => (num < 10 ? `0${num}` : num);
 
export default RedBusPaymentForm;