import React, { useState } from 'react';
import './App.css'; // Import your external CSS file
import { Button } from '@mui/material';
import IMG from './Images/tracking.png';
 
const TwoColumnsEdgesContainer = () => {
  const [showMoreData, setShowMoreData] = useState(false);
 
  const toggleMoreData = () => {
    setShowMoreData(!showMoreData);
  };
 
  return (
    <div className="container9">
      <div className="column left">
        <div>
          <h2 style={{ color: "#00ab9f" }}>Track Ambulance</h2>
          <p>
            Ambulance Tracking system is a specialised tracking solution aimed at the efficient management of ambulance fleet
            {showMoreData && (
              <span> providing real-time location updates, route optimization, and emergency response coordination...</span>
            )}
          </p>
          <Button style={{ backgroundColor: "#00ab9f", color: "white" }} onClick={toggleMoreData}>
            {showMoreData ? 'Less' : 'More'}
          </Button>
        </div>
      </div>
      <div className="column right">
        <img src={IMG} alt='track' style={{ width: '100%',height: '100%', maxWidth: '700px' }} />
      </div>
    </div>
  );
};
 
export default TwoColumnsEdgesContainer;
 