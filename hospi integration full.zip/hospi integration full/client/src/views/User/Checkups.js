import React from 'react'

function Checkups() {
  return (
    <div>
      <h1>Checkups</h1>
    </div>
  )
}

export default Checkups
