import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import FormControlLabel from '@mui/material/FormControlLabel';
import Rupee from './Images/rupee.png';
import './payment1.css'
import Subscribe from './subscribe';
import axios from 'axios';
import Checkbox from '@mui/material/Checkbox';
import Alert from 'react-bootstrap/Alert';
 
 
const ContactForm = () => {
  // const [data, setData] = useState({ key: 'value' });
 
  const [show, setShow] = useState(false);
 
    const [ setEmail] = useState("");
 
    // const alert = ("Email send successfully");
    const sendEmail = async (e) => {
        e.preventDefault();
        console.log(formData);
        const res = await fetch("http://localhost:5000/api/register1?Email="+formData.Email, {
          method: "POST",
          headers: {
              "Content-Type": "application/json",
          },
          body: JSON.stringify({
              Email:formData.Email
          }),
      });
       
 
        const data = await res.json();
        console.log(data);
 
        if (data.status === 400 || !data) {
            console.log("error")
        } else {
            setShow(true);
            setEmail("")
            console.log("Email sent")
        }
    }
 
  const sendDataToServer = async () => {
    const isFormValid = () => {
      // Check if all fields are filled
      return (
        formData.CName.trim() !== '' &&
        formData.Email.trim() !== '' &&
        formData.Phone_No.trim() !== '' &&
        formData.Payment_mode.trim() !== '' &&
        formData.Payment_type.trim() !== '' &&
        formData.Dcity.trim() !== '' &&
        formData.Dstate.trim() !== ''
      );
    };
 
    if (isFormValid()) {
      axios
        .post('http://localhost:5000/api/booking', formData)
        .then((response) => {
          console.log('Response from server:', response.data);
          // navigate('/Pay');
        })
        .catch((error) => {
          console.error('Error sending data:', error);
          window.alert('Error sending data. Please try again.'); // Use window.alert
        });
    } else {
      window.alert('Please fill in all the fields.'); // U
    }
  };
 
  const navigate = useNavigate();
  const routeChange = () => {
    navigate('/User/payment1');
  };
 
  const [formData, setFormData] = useState({
    CName: '',
    Email: '',
    Phone_No: '',
    Payment_mode: '',
    Payment_type: '',
    Dcity: '',
    Dstate: '',
  });
 
  // const [selectedValue, setSelectedValue] = useState({
  //   Payment_mode: '',
  //   Payment_type: '',
  // });
 
  // const handleChanges = (event) => {
  //   const { name, value } = event.target;
  //   console.log(`Selected ${name}: ${value}`);
  //   setSelectedValue((prevData) => ({
  //     ...prevData,
  //     [name]: value,
  //   }));
  // };
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
 
  const [isWhatsAppChecked, setIsWhatsAppChecked] = useState(false);
 
  const handleBookingConfirmation = (event) => {
    setIsWhatsAppChecked(event.target.checked);
    sendMsg();
    if (event.target.checked) {
      console.log('Share updates on WhatsApp: Checked');
    } else {
      // Checkbox is unchecked
      console.log('Share updates on WhatsApp: Unchecked');
      // You can perform additional actions here
    }
  }
 
  const [number, setNumber] = useState()
 
  const sendMsg = () => {
 
    console.log("Number is", number)
 
    const header = {
      headers: {
        Authorization: `Bearer EAAKv0n7VqfEBO0F7E9ky57l8ZCTSjy70Tla8GS8Y6H3Jy2DRKOxMYwucJ3TwZCckXo5YNkpvXBMTYRuAaZBbO3au9A6y7CYhjKiCJizEyq2TUrpdpV8kMq3RTumeI2EGVOKTuOGjDDThMG8kehfl2oYNxKpbpIv86nA3PPvsHo8iXM6CzsaxNYwtrlbe7s6RZAHZCrqfeNDuflUWPoawZD`,
        Accept: 'application/json',
      }
    }
   
    const body = {
      "messaging_product": "whatsapp",
      "recipient_type": "individual",
      "to": "919959279658",
      "type": "template",
      "template": {
        "name": "booking",
        "language": {
          "code": "en"
        }
      }
    }
 
 
    axios.post('https://graph.facebook.com/v17.0/146053898600950/message', body, header)
    .then((res) => (
      console.log("Message sent seccess", res)
    ))
    .catch((err) => (
      console.log("error while sending Msg", err)
    ))
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your logic here to handle the form submission, e.g., send data to a server
    console.log('Form submitted:', formData);
  };
 
  const onClickCombined = (e) => {
    if (e) {
      e.preventDefault();
    }
 
    sendEmail(e);
    sendDataToServer();
    routeChange();
   
  };
 
  return (
    <>
    {
      show ? <Alert variant="primary" onClose={() => setShow(false)} dismissible>
          Your Email Succesfully Send to {formData.Email}
      </Alert> : ""
  }
    <div className='e-card-header-title'>
      <h1> Contact Information </h1>
      {setNumber}
      <div className='contact-form'>
        <form onSubmit={handleSubmit}>
          <div className='row' style={{ border: 'none' , width:'95%', margin:'10px' }}>
            <input
              type='text'
              id='CName'
              name='CName'
              placeholder='Enter Full Name'
              value={formData.CName}
              onChange={handleChange}
              required
            />
          </div>
          <div className='row'>
            <input
              type='text'
              id='Email'
              name='Email'
              placeholder='Enter Email Id'
              value={formData.Email}
              onChange={handleChange}
              required
              className='column'
            />
            <input
              type='tel'
              id='Phone_No'
              name='Phone_No'
              placeholder='Enter Mobile Number'
              value={formData.Phone_No}
              onChange={handleChange}
              required
              className='column'
            />
          </div>
          <div className='row'>
            <select
              name='Payment_mode'
              id='Payment_mode'
              value={formData.Payment_mode}
              required
              className='column'
              onChange={handleChange}
            >
              <option value=''>Payment Mode</option>
              <option value='Google Pay'>Google Pay</option>
              <option value='Phone Pay'>Phone Pay</option>
              <option value='Net Banking'>Net Banking</option>
              <option value='Pay later'>Pay Later</option>
            </select>
 
            <select
              name='Payment_type'
              id='Payment_type'
              value={formData.Payment_type}
              required
              className='column'
              onChange={handleChange}
            >
              <option value=''>Payment Type</option>
              <option value='Conformation Payment'>Conformation Payment</option>
              <option value='Full Payment'>Full Payment</option>
            </select>
          </div>
          <div className='row'>
            <input
              type='text'
              id='Dcity'
              name='Dcity'
              placeholder='Enter Residential City'
              value={formData.Dcity}
              onChange={handleChange}
              required
              className='column'
            />
            <input
              type='text'
              id='Dstate'
              name='Dstate'
              placeholder='Enter Residential State'
              value={formData.Dstate}
              onChange={handleChange}
              required
              className='column'
            />
          </div>
          <div style={{ textAlign: 'center' }}> {/* Style added for centering */}
        <FormControlLabel
          icon={<WhatsAppIcon />}
          control={
            <Checkbox
              checked={isWhatsAppChecked}
              onChange={handleBookingConfirmation}
            />
          }
          label='Share updates on WhatsApp'
          style={{color:'black'}}
        />
        <button onClick={onClickCombined} disabled={!formData.Dstate}>
          Proceed
        </button>
      </div>
        </form>
      </div>
    </div>
    </>
  );
};
 
function App() {
  const [fareBreakup, setFareBreakup] = useState({
    distance: 0,
    base_fare: 0,
    driver_allowance: 0,
    gst: 0,
    additional_charge: 0,
    total_cost: 0,
  });

  useEffect(() => {
    axios
      .get('http://localhost:5000/api/fare_breakup')
      .then((response) => {
        if (response.data && typeof response.data === 'object') {
          setFareBreakup({
            distance: response.data.distance,
            base_fare: response.data.base_fare,
            driver_allowance: response.data.driver_allowance,
            gst: response.data.gst,
            additional_charge: response.data.additional_charge,
            total_cost: response.data.total_cost,
          });
        } else {
          console.error('Invalid response data:', response.data);
        }
      })
      .catch((error) => {
        console.error('Error fetching fare details:', error);
      });
  }, []);
  
  
  return (
    <>
      {/* <Navbar />
      <Navbar1 /> */}
      <div className='row' style={{ marginTop: '50px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        <div className='column' style={{ boxShadow: '0 0 10px grey', justifyContent:'center', display:'flex'}}>
          <ContactForm />
        </div>
        {/* <div className='column' style={{ boxShadow: '0 0 10px grey' }}> */}
        <div className='column centered' style={{ boxShadow: '0 0 10px grey', height:'auto'}}>
          {fareBreakup && (
  <div className='card' style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
    <div className='left-content' style={{ flex: '3' ,  width:'100%'}}>
      <div>
    <h4 style={{ display: 'flex', justifyContent: 'center'}}>
            {' '}
            <img src={Rupee} alt='symbol' width={'35'} height={'35'} /> Fare Breakup{' '}
          </h4>
          </div>
         
      <p> Base Fare Includes <b>({fareBreakup.distance})</b> KMs </p>
      <p>Driver Allowance</p>
      <p> GST @ 5% </p>
      <p>Equipment Usage</p>
      <hr />
      <p> Total cost of your trip </p>
    </div>
    <div className='right-content'>
      <br />
      <br />
      <p> ₹ {fareBreakup.base_fare} </p>
      <br />
      <p> ₹ {fareBreakup.driver_allowance} </p>
      <p> ₹ {fareBreakup.gst} </p>
      <p> ₹ {fareBreakup.additional_charge} </p>
      <hr />
      <p> ₹ {fareBreakup.total_cost} </p>
    </div>
  </div>
)}
        </div>
      </div>
      <Subscribe />
      {/* <Footer />
      <Footer1 /> */}
    </>
  );
}
 
export default App;