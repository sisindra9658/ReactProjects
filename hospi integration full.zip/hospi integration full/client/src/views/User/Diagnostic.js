import React from 'react'

function Diagnostic() {
  return (
    <div>
      <h1>Labs</h1>
    </div>
  )
}

export default Diagnostic
