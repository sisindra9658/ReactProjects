// BookingModal.js
import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import { Button } from 'react-bootstrap';

const BookingModal = ({ isOpen, onClose, onSubmit, doctorDetails, getTodayDate }) => {
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    email: '',
    address: '',
    booking_date: '',
    booking_time: '',
  });

  useEffect(() => {
    // Update the form data when a doctor is selected
    if (doctorDetails) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        doctor_name: doctorDetails.doctor_name,
        consultation_fee: doctorDetails.consultation_fee,
      }));
    }
  }, [doctorDetails]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Modal isOpen={isOpen} onRequestClose={onClose}>
      <form onSubmit={handleFormSubmit}>
        {/* ... (other form fields) */}
        <label>Name:</label>
        <input type="text" name="name" value={formData.name} onChange={handleChange} required />

        <label>Contact:</label>
        <input type="text" name="contact" value={formData.contact} onChange={handleChange} required />

        <label>Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleChange} required />

        <label>Address:</label>
        <input type="text" name="address" value={formData.address} onChange={handleChange} required />

        <label>Date:</label>
        <input type="date" name="booking_date_display" value={formData.booking_date} onChange={handleChange} disabled />

        <label>Time:</label>
        <input type="time" name="booking_time_display" value={formData.booking_time} onChange={handleChange} disabled />

        <Button type="submit">Submit</Button>
      </form>
      <Button onClick={onClose}>Close</Button>
    </Modal>
  );
};

export default BookingModal;
