// import React from "react";
// // import { BrowserRouter, Routes, Route } from "react-router-dom";
// import { ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './App.css';
// import Home1 from "./Home1";
// import Footer from "./Footer";
// import NavScrollExample1 from "./Navbar";
// import EditForm from "./EditForm";
// import PaymentOptions from "./Payment";
// import Hospital from "./Hospital";
// import Diagnostic from "./Diagnostic";
// // import Ambulance from "./Ambulance";
// import Checkups from "./Checkups";
// import HospitalEdit from "./HospitalEdit";

// import Home from "./home";
// import Vehicles from './vehicles';
// import Bookings from './Bookings';
// import Payment from './payment1';
// import EditProfilePage from "./EditProfilePage";
// // import Map7 from "./Map";

// import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
// import Navbar1 from "./Navbar1";

// function App() {
//   const location = useLocation();
 
//   // Check if the current route is not "/my-account"
//   const isNotMyAccountPage = location.pathname !== "/my-account";
 
//   return (
//     <BrowserRouter>
//       <div className="App">

//         <ToastContainer position="top-center" /> 
//         <NavScrollExample1 /> 
//         {isNotMyAccountPage && <Navbar1/>}
//         {/* <Map7/> */}
//         <Routes>
//         <Route exact path="/Hospital" element={<Hospital />} />
//         {/* <Route exact path="/" element={<Home />} /> */}
//           <Route exact path="/Clinic" element={<Home1 />} />
//           <Route exact path="/Ambulance" element={<Home />} />
//           <Route exact path="/Labs" element={<Diagnostic />} />
//           <Route exact path="/Checkups" element={<Checkups />} />
//           <Route exact path="/edit" element={<EditForm />} />
//           <Route exact path="/edit1" element={<HospitalEdit />} />
//           <Route exact path="/Payment" element={<PaymentOptions/>} /> 
//           <Route exact path="/my-account" element={<EditProfilePage/>} /> 
//           <Route path='vehicles' element={<Vehicles />}></Route>
//       <Route path='Bookings' element={<Bookings />}></Route>
//       <Route path='payment1' element={<Payment />}></Route>   
//         </Routes> 
         
//         <Footer/>

//       </div>
//     </BrowserRouter>
//   );
// }

// export default App;


import React from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';
import Home1 from "./Home1";
import Footer from "./Footer";
import NavScrollExample1 from "./Navbar";
import EditForm from "./EditForm";
import PaymentOptions from "./Payment";
import EditProfilePage from "./EditProfilePage";
import Navbar1 from "./Navbar1";
// import Home21 from "./Home21";
import Hospital from "./Hospital";
// import Ambulance from "./Ambulance";
import Diagnostic from "./Diagnostic";
import Checkups from "./Checkups";
import HospitalEdit from "./HospitalEdit";
import Home from "./home";
import Vehicles from './vehicles'; 
import Bookings from './Bookings';
import Payment from './payment1';

function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
 
function AppContent() {
  const location = useLocation();
 
  // Check if the current route is not "/my-account"
  const isNotMyAccountPage = location.pathname !== "/my-account";
 
  return (
    <div className="App">
      <ToastContainer position="top-center" />
      <NavScrollExample1 />
      {isNotMyAccountPage && <Navbar1/>} {/* Render Navbar1 only if not on the "my-account" page */}
      <Routes>
      <Route exact path="/Hospital" element={<Hospital />} />
        <Route exact path="/Clinic" element={<Home1 />} />
        <Route exact path="/Ambulance" element={<Home />} />
        <Route exact path="/Labs" element={<Diagnostic />} />
          <Route exact path="/Checkups" element={<Checkups />} />
        <Route exact path="/edit" element={<EditForm />} />
        <Route exact path="/edit1" element={<HospitalEdit />} />
        <Route exact path="/Payment" element={<PaymentOptions/>} />
        <Route path="/my-account" element={<EditProfilePage />} />
        <Route path='/vehicles' element={<Vehicles />}></Route>
        <Route path='/Bookings' element={<Bookings />}></Route>
        <Route path='/payment1' element={<Payment />}></Route> 
      </Routes>  
      <Footer />
    </div>
  );
}
 
export default App;
 
 
 
 