import * as React from 'react';
import Container from '@mui/material/Container';
import Grid from './grid';

let imageStyle = {
  backgroundImage:
  'url("https://img.freepik.com/free-vector/abstract-medical-wallpaper-template-design_53876-61802.jpg?w=900&t=st=1701612786~exp=1701613386~hmac=f837e3f877afe2d7a0f03b767b97e5105dab26ceeed98f7814856eb6a24be3de")',
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
};
export default function SimpleContainer() {
  return (
    <React.Fragment>
      <Container style = {imageStyle} maxWidth="xl" sx={{ height: 'auto' }}  >
        <Grid />
      </Container>
    </React.Fragment>
  );
}