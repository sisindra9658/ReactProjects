// YourComponent.js
import React from 'react';
import './App.css'; // Add a CSS file for styling
import SearchIcon from '@mui/icons-material/Search';
import HistoryIcon from '@mui/icons-material/History';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';


const YourComponent = () => {
  return (
    <div className="container2">
      <div className="column1">
        <SearchIcon style={{ fontSize: '80px', color: '00ab9f' }} />
      <h2>Easy Search</h2>
      <p style={{color:'#00ab9f'}}>its quick,convinient and free</p>
      </div>
      <div className="column1">
      <HistoryIcon style={{ fontSize: '80px', color: '00ab9f' }} />
      <h2>Save Time</h2>
      <p style={{color:'#00ab9f'}}>Everything you want</p>
      </div>
      <div className="column1">
      <HealthAndSafetyIcon style={{ fontSize: '80px', color: '00ab9f' }} />
      <h2>Better Life</h2>
      <p style={{color:'#00ab9f'}}>its quick,convinient and free</p>
      </div>
    </div>
    
  );
};

export default YourComponent;
