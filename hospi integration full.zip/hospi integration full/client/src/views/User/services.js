// YourComponent.js

import React from 'react';
import './App.css'; // Add a CSS file for styling

import PersonIcon from '@mui/icons-material/Person';
import ApartmentIcon from '@mui/icons-material/Apartment';
import AirportShuttleIcon from '@mui/icons-material/AirportShuttle';


const YourComponent = () => {
  return (
    <div className="container2">
      <div className="column1">
        <PersonIcon style={{ fontSize: '80px', color: '00ab9f' }} />
      <p> <b>67000</b> Doctors </p>
      <p style={{color:'#00ab9f'}}>its quick,convinient and free to use</p>
      </div>
      <div className="column1">
      <ApartmentIcon style={{ fontSize: '80px', color: '00ab9f' }} />
      <p> <b>4176</b> Hospitals </p>
      <p style={{color:'#00ab9f'}}>its quick,convinient and free to use</p>
      </div>
      <div className="column1">
      <AirportShuttleIcon style={{ fontSize: '80px', color: '00ab9f' }} />
      <p> <b>5438</b> Ambulances </p>
      <p style={{color:'#00ab9f'}}>its quick,convinient and free to use</p>
      </div>
    </div>
    
  );
};

export default YourComponent;
