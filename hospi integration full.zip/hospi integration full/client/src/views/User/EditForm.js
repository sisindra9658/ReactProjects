import React, { useState, useEffect } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link, useNavigate } from 'react-router-dom';
import './EditForm.css'
 
const EditForm = () => {
  const [appointmentData, setAppointmentData] = useState(null);
  const [editedData, setEditedData] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const navigate = useNavigate();
 
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/appointment_booking?sort=patient_id:desc");
        const data = response.data.data;
        if (data && data.length > 0) {
          setAppointmentData(data[data.length - 1]);
          setEditedData({
            name: (data.length > 0 ? data[data.length - 1].name : "") || "",
            contact: (data.length > 0 ? data[data.length - 1].contact : "") || "",
            email: (data.length > 0 ? data[data.length - 1].email : "") || "",
            address: (data.length > 0 ? data[data.length - 1].address : "") || "",
            // booking_date: (data.length > 0 ? new Date(data[data.length - 1].booking_date).toISOString().split('T')[0] : "") || "",
            booking_date: (data.length > 0 ? new Date(data[data.length - 1].booking_date).toLocaleDateString('en-GB') : "") || "",
            slot_time: (data.length > 0 ? data[data.length - 1].slot_time : "") || "",
            clinic_name: (data.length > 0 ? data[data.length - 1].clinic_name : "") || "",
            locality: (data.length > 0 ? data[data.length - 1].locality : "") || "",
            doctor_name: (data.length > 0 ? data[data.length - 1].doctor_name : "") || "",
            consultation_fee: (data.length > 0 ? data[data.length - 1].consultation_fee : "") || "",
          });
         
        }
      } catch (error) {
        console.error("Error fetching appointment booking data:", error);
      }
    };
 
    fetchData();
  }, []);
 
  const editableFields = ['name', 'contact', 'email', 'address', 'booking_date', 'slot_time'];
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
 
  const handleEditFormClick = () => {
    setIsEditing(true);
  };
 
  const handleSaveChangesClick = async () => {
    try {
      if (!appointmentData || !appointmentData.patient_id) {
        console.error("Invalid appointment data:", appointmentData);
        toast.error("Error saving changes. Invalid appointment data.");
        return;
      }
 
      const editedDataToSend = {};
      editableFields.forEach((field) => {
        editedDataToSend[field] = editedData[field];
      });
 
      console.log("Data to send:", editedDataToSend);
 
      const response = await axios.put(`http://localhost:5000/api/appointment_booking/${appointmentData.patient_id}`, editedDataToSend);
 
      console.log("Response:", response);
 
      if (response.status === 200) {
        toast.success("Changes saved successfully");
 
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        console.error("Unexpected response:", response);
        toast.error("Error saving changes. Unexpected response.");
      }
    } catch (error) {
      console.error("Error updating form:", error);
 
      toast.error("Error saving changes");
 
      console.error(error);
    }
  };
 
 
  const handleCancelClick = () => {
    setEditedData({
      name: (appointmentData ? appointmentData.name : "") || "",
      contact: (appointmentData ? appointmentData.contact : "") || "",
      email: (appointmentData ? appointmentData.email : "") || "",
      address: (appointmentData ? appointmentData.address : "") || "",
      booking_date: (appointmentData ? appointmentData.booking_date : "") || "",
      slot_time: (appointmentData ? appointmentData.slot_time : "") || "",
      clinic_name: (appointmentData ? appointmentData.clinic_name : "") || "",
      locality: (appointmentData ? appointmentData.locality : "") || "",
      doctor_name: (appointmentData ? appointmentData.doctor_name : "") || "",
      consultation_fee: (appointmentData ? appointmentData.consultation_fee : "") || "",
    });
    setIsEditing(false);
  };
 
 
  const handleProceed = () => {
    navigate('./Payment');
  };
 
 
  return (

<div className="edit-form-container">
  <div className="details-template confirm-details">
  <br></br>
    <h3 className="heading">CONFIRM DETAILS</h3><br></br>
    {appointmentData && (
      <div>
        {editableFields.map((field) => (
          <p key={field}>
            {field.charAt(0).toUpperCase() + field.slice(1)}: {editedData[field]}
          </p>
        ))}
        {!isEditing && (
          <button type="button" className="edit-button" onClick={handleEditFormClick}>
            Edit Form
          </button>
        )}
      </div>
    )}
  </div>

  <div className="details-template additional-details">
  
    {!isEditing && (
      <div className="additionalhe">
      <br></br>
    <h3 className="heading">ADDITIONAL DETAILS</h3><br></br>
        <p>Clinic Name: {editedData.clinic_name}</p>
        <p>Clinic Address: {editedData.locality}</p>
        <p>Doctor Name: {editedData.doctor_name}</p>
        <p>Consultation Fee: {editedData.consultation_fee}</p>
        <br></br><br></br><br></br>
        <Link to={'/Payment'}>
        <button className="button" onClick={handleProceed}>
          Proceed to Payment
        </button>
        </Link>
      </div>
    )}
  </div>

  {isEditing && (
    <div className="edit-template">
      <h3>Edit Form</h3>
      {appointmentData && (
        <form className="formhe">
          {editableFields.map((field) => (
            <div key={field}>
              <label className="heading1">
                Edit {field.charAt(0).toUpperCase() + field.slice(1)}:
                <input type="text" name={field} value={editedData[field]} onChange={handleChange} />
              </label>
              <br />
            </div>
          ))}
          <button type="button" onClick={handleSaveChangesClick}>
            Save Changes
          </button>
          <button type="button" onClick={handleCancelClick}>
            Cancel
          </button>
        </form>
      )}
    </div>
  )}

  <ToastContainer position="bottom-right" autoClose={3000} />
</div>

 
  );
};
 
export default EditForm;
 