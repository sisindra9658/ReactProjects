import React from 'react';
import Button from '@mui/material/Button';

const App = () => {
  return (
    <div style={{backgroundColor:'lightgrey',height:'180px'}}>
      <br/>
    <h1 style={{textAlign:'center', color:'#00ab9f', marginTop:'30px'}}>Stay Connected!</h1>
    <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center',justifyContent:'space-around', marginTop:'20px' }}>
      <input placeholder='Name' style={{ marginRight: '10px',width:'27%' }} />
      <input placeholder='Email' style={{ marginRight: '10px',width:'27%' }} />
      <Button style={{ width:'15%',backgroundColor:'#00ab9f',color:'white' }}>Subscribe</Button>
    </div>
  </div>
  
  );
};

export default App;

