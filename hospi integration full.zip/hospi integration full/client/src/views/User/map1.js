 
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Form } from 'react-bootstrap';
import { GoogleMap, DirectionsRenderer, LoadScript } from '@react-google-maps/api';
import axios from 'axios';
import './grid.css';
import 'react-datepicker/dist/react-datepicker.css';
import Col from 'react-bootstrap/Col';
 
const calculateDistance = (lat1, lng1, lat2, lng2) => {
  console.log('Calculating distance:', lat1, lng1, lat2, lng2);
  const R = 6371;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLng = (lng2 - lng1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  console.log('Distance calculated:', distance);
  return distance;
};
const generateRandomValue = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};
 
function Map() {
 
  const [uniqueCities, setUniqueCities] = useState([]);
  const [nearbyOptions, setNearbyOptions] = useState([]);
  const [locations, setLocations] = useState([]);
  const [mapCenter, setMapCenter] = useState({ lat: 15.385, lng: 78.486 });
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedNearby, setSelectedNearby] = useState('');
  const [selectedDestinationCity, setSelectedDestinationCity] = useState('');
  const [selectedDestinationNearby, setSelectedDestinationNearby] = useState('');
  const [destination, setDestination] = useState(null);
  const [directions, setDirections] = useState(null);
  const [showDirectionsDashboard, setShowDirectionsDashboard] = useState(false);
  const [nearbyOptionsForDestination, setNearbyOptionsForDestination] = useState([]);
  const [uniqueHospitals, setUniqueHospitals] = useState([]);
  const [selectedHospital, setSelectedHospital] = useState('');
  const [selectedDateTime, setSelectedDateTime] = useState('');
  const [allFieldsSelected, setAllFieldsSelected] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [additionalCharge, setAdditionalCharge] = useState(null);
  // const [base_fare, setBaseFare] = useState(null);
  // const [driver_allowance, setDriverAllowance] = useState(null);
  // const [gst, setGst] = useState(null);
  const [distance, setDistance] = useState(null);
 
  const handleDateTimeChange = (dateTimeString) => {
    const selectedDateTime = new Date(dateTimeString.replace('T', ' ') + 'Z'); // Append 'Z' to indicate UTC
    setSelectedDateTime(selectedDateTime);
  };
 
 
 
  useEffect(() => {
    axios.get('http://localhost:5000/api/locationss3')
      .then((response) => {
        const data = response.data;
        setLocations(data);
        const uniqueCitiesData = [...new Set(data.map(location => location.city))];
        setUniqueCities(uniqueCitiesData);
        const uniqueNearbyData = [...new Set(data.map(location => location.nearby))];
        setNearbyOptions(uniqueNearbyData);
 
        if (data.length > 0) {
          setMapCenter({
            lat: data[0].latitude,
            lng: data[0].longitude,
          });
        }
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);
 
  const mapStyles = {
    height: '400px',
    width: '100%',
  };
 
  const handleNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedNearby(selected);
    setSelectedHospital('');
 
    // Filter hospital options based on the selected nearby option
    const hospitalsForSelectedNearby = locations
      .filter(location => location.city === selectedCity && location.nearby === selected)
      .map(location => location.hospital);
 
    setUniqueHospitals([...new Set(hospitalsForSelectedNearby)]);
  };
 
  const handleHospitalChange = (event) => {
    const selected = event.target.value;
    setSelectedHospital(selected);
  };
 
  const handleCityChange = (event) => {
    const selected = event.target.value;
    setSelectedCity(selected);
    setSelectedNearby('');
    setSelectedHospital('');
 
    // Filter nearby options based on the selected origin city
    const nearbyOptionsForSelectedCity = locations
      .filter(location => location.city === selected)
      .map(location => location.nearby);
 
    setNearbyOptions([...new Set(nearbyOptionsForSelectedCity)]);
  };
 const navigate = useNavigate();
  const handleDestinationCityChange = (event) => {
    const selected = event.target.value;
    setSelectedDestinationCity(selected);
    setSelectedDestinationNearby('');
    setDestination(null);
 
    // Filter nearby options based on the selected destination city
    const nearbyOptionsForSelectedDestinationCity = locations
      .filter(location => location.city === selected)
      .map(location => location.nearby);
 
    setNearbyOptionsForDestination([...new Set(nearbyOptionsForSelectedDestinationCity)]);
  };
 
  const handleDestinationNearbyChange = (event) => {
    const selected = event.target.value;
    setSelectedDestinationNearby(selected);
    setDestination(null);
  };
  {destination}
 
  const getMinDateTime = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (`0${currentDate.getMonth() + 1}`).slice(-2);
    const day = (`0${currentDate.getDate()}`).slice(-2);
    const hours = (`0${currentDate.getHours()}`).slice(-2);
    const minutes = (`0${currentDate.getMinutes()}`).slice(-2);
 
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };
 
  const handleGetDirections = () => {
    const originLatLng = locations.find(location => location.city === selectedCity && location.nearby === selectedNearby);
    const destinationLatLng = locations.find(location => location.city === selectedDestinationCity && location.nearby === selectedDestinationNearby);
 
    if (originLatLng && destinationLatLng) {
      const origin = {
        lat: parseFloat(originLatLng.latitude),
        lng: parseFloat(originLatLng.longitude),
      };
 
      const destination = {
        lat: parseFloat(destinationLatLng.latitude),
        lng: parseFloat(destinationLatLng.longitude),
      };
 
      const directionsService = new window.google.maps.DirectionsService();
      directionsService.route(
        {
          origin: origin,
          destination: destination,
          travelMode: window.google.maps.TravelMode.DRIVING,
        },
        (result, status) => {
          if (status === window.google.maps.DirectionsStatus.OK) {
            setDirections(result);
            setShowDirectionsDashboard(true);
          } else {
            console.error('Directions request failed due to ' + status);
          }
        }
      );
    }
  };
 
 
  // const handleDistanceCalculation = () => {
  //       if (selectedCity && selectedNearby && selectedDestinationCity && selectedDestinationNearby) {
  //         setAllFieldsSelected(true);
  //         setShowPopup(true);
  //       } else {
  //         // Handle the case where not all fields are selected
  //         console.log("Please select all fields");
  //       }
  //     //   const city = cities.find(city => city.name === selectedCity);
  //     // const destCity = cities.find(city => city.name === selectedDestCity);
     
  //     // Update the handleDistanceCalculation function in your React component
  //     const randomValue = generateRandomValue(500, 1800);
  //     setAdditionalCharge(randomValue);
  //     // ... (previous code)
     
  //     axios.post('http://localhost:5000/api/fare_breakup', {
  //       base_fare: base_fare,
  //       driver_allowance: driver_allowance,
  //       gst: gst,
  //       additional_charge: randomValue,
  //       total_cost: parseFloat(base_fare) + parseFloat(driver_allowance) + parseFloat(gst) + randomValue,
  //     })
  //     .then(response => {
  //       console.log('Data sent to backend successfully:', response.data);
  //       // Optionally, you can perform additional actions after successful data submission
  //     })
  //     .catch(error => {
  //       console.error('Error sending data to backend:', error);
  //       // Handle the error, e.g., display an error message to the user
  //     });
     
     
   
  //     // if (city && destCity) {
  //     //   const dist = calculateDistance(
  //     //     city.lat,
  //     //     city.lng,
  //     //     destCity.lat,
  //     //     destCity.lng
  //     //   );
  //     //   setDistance(dist);
  //     //   // Now, you can calculate other details such as basic price, driver allowance, GST, etc.
  //     //   const base_fare = parseFloat(dist) * 15; // Assuming price is 15 rupees per kilometer
  //     //   const driver_allowance = parseFloat(dist) * 3; // Assuming 1 rupee per kilometer for driver allowance
  //     //   const gst = (base_fare + driver_allowance) * 0.05; // Assuming 5% GST
  //     //   setbase_fare(base_fare.toFixed(2));
  //     //   setdriver_allowance(driver_allowance.toFixed(2));
  //     //   setgst(gst.toFixed(2));
  //     //   // Open the popup
  //     //   setShowPopup(true);
  //     // } else {
  //     //   console.log("Invalid city selection");
  //     //   setDistance(null);
  //     // }
  //     const originLatLng = locations.find(location => location.city === selectedCity && location.nearby === selectedNearby);
  //       const destinationLatLng = locations.find(location => location.city === selectedDestinationCity && location.nearby === selectedDestinationNearby);
   
  //       if (originLatLng && destinationLatLng) {
  //         const origin = {
  //           lat: parseFloat(originLatLng.latitude),
  //           lng: parseFloat(originLatLng.longitude),
  //         };
   
  //         const destination = {
  //           lat: parseFloat(destinationLatLng.latitude),
  //           lng: parseFloat(destinationLatLng.longitude),
  //         };
   
  //         const directionsService = new window.google.maps.DirectionsService();
  //         directionsService.route(
  //           {
  //             origin: origin,
  //             destination: destination,
  //             travelMode: window.google.maps.TravelMode.DRIVING,
  //           },
  //           (result, status) => {
  //             if (status === window.google.maps.DirectionsStatus.OK) {
  //               setDirections(result);
  //               setShowDirectionsDashboard(true);
  //             } else {
  //               console.error('Directions request failed due to ' + status);
  //             }
  //           }
  //         );
  //         const farePrice = distance * 15;
  //         const driverAllowance = distance * 3;
  //         const gst = (farePrice + driverAllowance) * 0.05;
   
  //       const distance = calculateDistance(origin.lat, origin.lng, destination.lat, destination.lng);
  //       const totalPrice = farePrice + driverAllowance + gst + additionalCharge;
  //       setbase_fare(farePrice.toFixed(2));
  //         setdriver_allowance(driverAllowance.toFixed(2));
  //         setgst(gst.toFixed(2));
  //         setDistance(distance.toFixed(2));
  //         setAdditionalCharge(additionalCharge.toFixed(2));
  //         console.log('Distance:', distance);
  //         console.log('Fare Price:', farePrice);
  //         console.log('Driver Allowance:', driverAllowance);
  //         console.log('GST:', gst);
  //         console.log('Additional Charge:', additionalCharge);
  //         console.log('Total Price:', totalPrice);
  //       }
  //     else {
  //         console.log('Invalid origin or destination selection');
  //         // Handle the case where the origin or destination is not valid
  //       }
     
  //     };
 
  const handleDistanceCalculation = async () => {
        if (selectedCity && selectedNearby && selectedDestinationCity && selectedDestinationNearby) {
          setAllFieldsSelected(true);
     
          const originLatLng = locations.find(
            (location) => location.city === selectedCity && location.nearby === selectedNearby
          );
          const destinationLatLng = locations.find(
            (location) =>
              location.city === selectedDestinationCity && location.nearby === selectedDestinationNearby
          );
     
          if (originLatLng && destinationLatLng) {
            const origin = {
              lat: parseFloat(originLatLng.latitude),
              lng: parseFloat(originLatLng.longitude),
            };
     
            const destination = {
              lat: parseFloat(destinationLatLng.latitude),
              lng: parseFloat(destinationLatLng.longitude),
            };
     
            try {
              // Calculate distance using Haversine formula
              const distance = calculateDistance(origin.lat, origin.lng, destination.lat, destination.lng);
     
              // Set state variables for distance
              setDistance(distance.toFixed(2));
              // Set state variables for distance
     
              // Calculate fare breakdown
              const farePrice = distance * 15; // Assuming price is 15 rupees per kilometer
              const driverAllowance = distance * 3; // Assuming 3 rupees per kilometer for driver allowance
              const gst = (farePrice + driverAllowance) * 0.05; // Assuming 5% GST
              const additionalCharge = generateRandomValue(500, 1800);
     
              // Set state variables for fare breakdown
              setbase_fare(farePrice.toFixed(2));
              setdriver_allowance(driverAllowance.toFixed(2));
              setgst(gst.toFixed(2));
              setAdditionalCharge(additionalCharge.toFixed(2));
     
              // Show the fare breakdown popup
              setShowPopup(true);
     
              // Send data to the backend
              await axios.post('http://localhost:5000/api/fare_breakup', {
                distance: distance,
                base_fare: farePrice.toFixed(2),
                driver_allowance: driverAllowance.toFixed(2),
                gst: gst.toFixed(2),
                additional_charge: additionalCharge.toFixed(2),
                total_cost:
                  parseFloat(farePrice) + parseFloat(driverAllowance) + parseFloat(gst) + parseFloat(additionalCharge),
              });
     
              // Log data to console
              console.log('Distance:', distance);
              console.log('Fare Price:', farePrice);
              console.log('Driver Allowance:', driverAllowance);
              console.log('GST:', gst);
              console.log('Additional Charge:', additionalCharge);
            } catch (error) {
              console.error('Error calculating distance:', error);
            }
          } else {
            console.log('Invalid origin or destination selection');
          }
        } else {
          console.log('Please select all required fields');
        }
      };
 
const [base_fare, setbase_fare] = useState(null);
const [driver_allowance, setdriver_allowance] = useState(null);
const [gst, setgst] = useState(null);
 
 
const handleClosePopup = () => {
  // Close the popup
  setShowPopup(false);
};
 
const onClickCombined = () => {
  handleDistanceCalculation();
  handleClosePopup();
}
 
 
 
 
const handleSubmit = (e) => {
  e.preventDefault();
  // Handle form submission logic here
  // setSearched(true);
  handleDistanceCalculation();
  navigate("/User/vehicles");
};
 
 
  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   // Handle form submission logic here
  //   // setSearched(true);
  //   handleDistanceCalculation();
  //   const navigate = useNavigate();
  //   navigate("/User/vehicles");
  // };
  return (
    <>
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
    <div className='column'>
  <div className='contain'>
    <div>
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>  
    <Col>
    <select id='originCity' value={selectedCity} onChange={handleCityChange} className='xyz'>
      <option value="">Select an origin city</option>
      {uniqueCities.map((city, index) => (
        <option key={index} value={city}>
          {city}
        </option>
      ))}
    </select>
  </Col>
 
  <Col>
    <select id='nearbyOption' value={selectedNearby} onChange={handleNearbyChange} className='xyz'>
      <option value="">Select a nearby option</option>
      {nearbyOptions.map((nearby, index) => (
        <option key={index} value={nearby}>
          {nearby}
        </option>
      ))}
    </select>
  </Col>
</div>
 
 
<div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Col>
          <select id='hospital' value={selectedHospital} onChange={handleHospitalChange} className='xyz'>
            <option value="">Select a hospital</option>
            {uniqueHospitals.map((hospital, index) => (
              <option key={index} value={hospital}>
                {hospital}
              </option>
            ))}
          </select>
        </Col>
 
        <Col>
          <Form.Control
            type="datetime-local"
            value={selectedDateTime ? selectedDateTime.toISOString().slice(0, 16) : ''}
            onChange={(e) => handleDateTimeChange(e.target.value)}
            id='dateTime'
            className='xyz'
            aria-label="Date and Time"
            min={getMinDateTime()}
            border='solid'
            required
          />
        </Col>
      </div>
 
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Col>
          <select id='destinationCity' value={selectedDestinationCity} onChange={handleDestinationCityChange} className='xyz'>
            <option value="">Select a destination city</option>
            {uniqueCities.map((city, index) => (
              <option key={index} value={city}>
                {city}
              </option>
            ))}
          </select>
        </Col>
 
        <Col>
          <select id='destinationNearby' value={selectedDestinationNearby} onChange={handleDestinationNearbyChange} className='xyz'>
            <option value="" className='xyzz'>Select a nearby option for destination</option>
            {nearbyOptionsForDestination.map((nearby, index) => (
              <option key={index} value={nearby} >
                {nearby}
              </option>
            ))}
          </select>
        </Col>
      </div>
    </div>
   
    <div style={{ justifyContent: 'space-between', display: 'flex' }}>
      <button className='Bhu' onClick={handleGetDirections} style={{ marginTop: "10px" }}>Get Directions</button>
    </div>
    <div style={{ justifyContent: 'space-between', display: 'flex', marginTop: '20px' }}>
      <button className='Bhu' onClick={handleSubmit}>Search</button>
    </div>
  </div>
</div>
 
     
     
      <div className='column' >
      <h1 style={{ textAlign: 'center' }}>Map with Locations</h1>
      <LoadScript googleMapsApiKey="AIzaSyCGhHNoTUpRQo4WQxmfUDzGTlZUcAYSvCg">
        <GoogleMap mapContainerStyle={mapStyles} zoom={5} center={mapCenter}>
          {showDirectionsDashboard && directions && (
            <DirectionsRenderer
              directions={directions}
              options={{
                polylineOptions: {
                  strokeColor: 'black',
                  strokeOpacity: 1,
                  strokeWeight: 4,
                },
              }}
            />
          )}
        </GoogleMap>
      </LoadScript>
      </div>
     
     
     
      {allFieldsSelected && showPopup && (
<div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0, 0, 0, 0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
<div style={{ background: '#fff', padding: '20px', borderRadius: '5px', textAlign: 'center' }}>
<div className="row">
<div className="col-md-6">
<p>{`Distance between ${selectedCity} and ${selectedDestinationCity}:`}</p>
<p>{`Basic Price: `}</p>
<p>{`Driver Allowance:`}</p>
<p>{`GST: `}</p>
<p>{`Additional Charge:`}</p>
</div>
<div className="col-md-6">
<p>{`₹${distance} km`}</p>
<p>{`₹${base_fare}`}</p>
<p>{`₹${driver_allowance}`}</p>
<p>{`₹${gst}`}</p>
<p>{`₹${additionalCharge}`}</p>
</div>
</div>
<hr></hr>
<p>{`Total Price: ₹${parseFloat(base_fare) + parseFloat(driver_allowance) + parseFloat(additionalCharge) + parseFloat(gst)}`}</p>
<button onClick={onClickCombined}>Close</button>
</div>
</div>
      )}
    </div>
    </>
  );
}
 
export default Map;
 
 
 
 