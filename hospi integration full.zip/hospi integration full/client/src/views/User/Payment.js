import React, { useState } from 'react';
import './RadioButtons.css'; 

const PaymentOptions = () => {
  const [selectedOption, setSelectedOption] = useState(null);

  const handleOptionChange = (option) => {
    setSelectedOption(option);
  };

  const handleThankYou = () => {
    if (selectedOption === 'payAtClinic') {
      return 'Thank you for choosing Pay at Clinic.';
    } else if (selectedOption === 'onlinePayment') {
      return 'We will soon add online payment option.';
    }
    return null;
  };

  return (
    <div className="payment-options-container">
      <label className={`payment-option ${selectedOption === 'payAtClinic' && 'selected'}`}>
        <input type="radio" value="payAtClinic" checked={selectedOption === 'payAtClinic'} onChange={() => handleOptionChange('payAtClinic')} />
        Pay At Clinic
      </label>

      <label className={`payment-option ${selectedOption === 'onlinePayment' && 'selected'}`}>
        <input type="radio" value="onlinePayment" checked={selectedOption === 'onlinePayment'} onChange={() => handleOptionChange('onlinePayment')} />
        Online Payment
      </label>
      <br />

      {selectedOption && (
        <div className="confirmation-message">
          {handleThankYou()}
        </div>
      )}
    </div>
  );
};

export default PaymentOptions;
 