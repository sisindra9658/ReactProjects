import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import amb1 from './Images/amb1.png';
import amb2 from './Images/amb2.png';
import amb3 from './Images/amb3.png';
import amb4 from './Images/amb4.png';
import StarRateIcon from '@mui/icons-material/StarRate';
import { useNavigate } from 'react-router-dom';
// import Navbar from './navbar';
// import Navbar1 from './navbar1';
import Subscribe from './subscribe';
// import Footer from './footer';
// import Footer1 from './footer1';
import Popover from '@mui/material/Popover';
import { useState, useEffect } from 'react';



export default function MediaCard() {

  const navigate = useNavigate();
  // const routeChange = () => {
  //   navigate('/User/Bookings');
  // };
  const routeChange = () => {
    console.log('Navigating to /User/Bookings');
    navigate('/User/Bookings');
  };
  
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [anchorE2, setAnchorE2] = React.useState(null);
  const [anchorE3, setAnchorE3] = React.useState(null);
  const [anchorE4, setAnchorE4] = React.useState(null);
  const [anchorE5, setAnchorE5] = React.useState(null);
  const [anchorE6, setAnchorE6] = React.useState(null);
  const [anchorE7, setAnchorE7] = React.useState(null);
  const [anchorE8, setAnchorE8] = React.useState(null);
  const [anchorE9, setAnchorE9] = React.useState(null);
  const [anchorE10, setAnchorE10] = React.useState(null);
  const [anchorE11, setAnchorE11] = React.useState(null);
  const [anchorE12, setAnchorE12] = React.useState(null);


  const handlePopoverOpen = (event, anchorEl) => {
    switch (anchorEl) {
      case '1':
        setAnchorEl(event.currentTarget);
        break;
      case '2':
        setAnchorE2(event.currentTarget);
        break;
      case '3':
        setAnchorE3(event.currentTarget);
        break;
        case '4':
          setAnchorE4(event.currentTarget);
          break;
        case '5':
          setAnchorE5(event.currentTarget);
          break;
        case '6':
          setAnchorE6(event.currentTarget);
          break;
          case '7':
            setAnchorE7(event.currentTarget);
            break;
          case '8':
            setAnchorE8(event.currentTarget);
            break;
          case '9':
            setAnchorE9(event.currentTarget);
            break;
            case '10':
              setAnchorE10(event.currentTarget);
              break;
            case '11':
              setAnchorE11(event.currentTarget);
              break;
            case '12':
              setAnchorE12(event.currentTarget);
              break;
      // ... handle more cases if needed
      default:
        break;
    }
  };

  const handlePopoverClose = (anchorEl) => {
    switch (anchorEl) {
      case '1':
        setAnchorEl(null);
        break;
      case '2':
        setAnchorE2(null);
        break;
      case '3':
        setAnchorE3(null);
        break;
          case '4':
            setAnchorE4(null);
            break;
          case '5':
            setAnchorE5(null);
            break;
          case '6':
            setAnchorE6(null);
            break;
              case '7':
                setAnchorE7(null);
                break;
              case '8':
                setAnchorE8(null);
                break;
              case '9':
                setAnchorE9(null);
                break;
                  case '10':
                    setAnchorE10(null);
                    break;
                  case '11':
                    setAnchorE11(null);
                    break;
                  case '12':
                    setAnchorE12(null);
                    break;
      // ... handle more cases if needed
      default:
        break;
    }
  };

  const open1 = Boolean(anchorEl);
  const open2 = Boolean(anchorE2);
  const open3 = Boolean(anchorE3);
  const open4 = Boolean(anchorE4);
  const open5 = Boolean(anchorE5);
  const open6 = Boolean(anchorE6);
  const open7 = Boolean(anchorE7);
  const open8 = Boolean(anchorE8);
  const open9 = Boolean(anchorE9); 
  const open10 = Boolean(anchorE10);
  const open11 = Boolean(anchorE11);
  const open12 = Boolean(anchorE12);

  const generatePrice = () => {
    return (Math.random() * (1500 - 800) + 800).toFixed(2);
  };
  
  const [location, setLocation] = useState({ latitude: 15.478569, longitude: 78.483093, city: 'Nandyal' });
  const [location1] = useState({ latitude: 15.834536, longitude: 78.029366, city: 'kurnool' });
  const [location2] = useState({ latitude: 17.448294, longitude: 78.391487, city: 'madhapur' });
  const [location3] = useState({ latitude: 17.450333, longitude: 78.381052, city: 'hitech city' });
  const [location4] = useState({ latitude: 17.491659, longitude: 78.391983, city: 'Kukatpalli' });
  const [location5] = useState({ latitude: 17.440081, longitude: 78.348915, city: 'gachibowli' });
  const [location6] = useState({ latitude: 17.401810, longitude: 78.560188, city: 'uppal' });
  const [location7] = useState({ latitude: 17.071230, longitude: 78.204887, city: 'sadnagar' });
  const [location8] = useState({ latitude: 18.000055, longitude: 79.588165, city: 'warangal' });
  const [location9] = useState({ latitude: 17.439930, longitude: 78.498276, city: 'secunderabad' });
  const [location10] = useState({ latitude: 17.3687826, longitude: 78.52467060000004, city: 'dilsukhnagar' });
  const [location11] = useState({ latitude: 15.834536, longitude: 78.029366, city: 'kurnool' });


  const [destination ] = useState({ latitude: 15.478569, longitude: 78.483093, city: 'Nandyal' });
  const [destination1] = useState({ latitude: 15.834536, longitude: 78.029366, city: 'kurnool' });
  const [destination2] = useState({ latitude: 17.448294, longitude: 78.391487, city: 'madhapur' });
  const [destination3] = useState({ latitude: 17.450333, longitude: 78.381052, city: 'hitech city' });
  const [destination4] = useState({ latitude: 17.491659, longitude: 78.391983, city: 'Kukatpalli' });
  const [destination5] = useState({ latitude: 17.440081, longitude: 78.348915, city: 'gachibowli' });
  const [destination6] = useState({ latitude: 17.401810, longitude: 78.560188, city: 'uppal' });
  const [destination7] = useState({ latitude: 17.071230, longitude: 78.204887, city: 'sadnagar' });
  const [destination8] = useState({ latitude: 18.000055, longitude: 79.588165, city: 'warangal' });
  const [destination9] = useState({ latitude: 17.439930, longitude: 78.498276, city: 'secunderabad' });
  const [destination10] = useState({ latitude: 17.3687826, longitude: 78.52467060000004, city: 'dilsukhnagar' });
  const [destination11] = useState({ latitude: 15.834536, longitude: 78.029366, city: 'kurnool' });

  const [currentLocation, setCurrentLocation] = useState({ latitude: 15.834536, longitude: 78.029366 });


  // useEffect(() => {
  //   const updateLocationDetails = async (id) => {
  //     // Simulate fetching city name based on latitude and longitude
  //     // Replace this with the actual API call to the reverse geocoding service
  //     const newLocation = await fetchCityName(id);
  //     setLocation(newLocation);
  //   };

  //   // Example: updateLocationDetails('1');
  // }, []);

  useEffect(() => {
    // Simulate fetching the current location or use actual geolocation API
    const fetchCurrentLocation = async () => {
      // Replace with actual logic to get the user's current location
      setCurrentLocation({ latitude:  17.450333, longitude: 78.381052 });
    };
    fetchCurrentLocation();
  }, []);

  // const fetchCityName = async (id) => {
  //   // Simulate API call to the reverse geocoding service
  //   // Replace 'YOUR_API_KEY' with your actual OpenCage API key
  //   const apiKey = 'AIzaSyBLStvcSKLrEz0wThzVC6XItsG9Ydf1CJQ';
  //   const response = await fetch(
  //     `https://api.opencagedata.com/geocode/v1/json?key=${apiKey}&q=${location.latitude}+${location.longitude}&pretty=1`
  //   );
  //   const data = await response.json();

  //   // Extract the city name from the API response
  //   const city = data.results[0]?.components?.city || 'Unknown City';

  //   return { latitude: location.latitude, longitude: location.longitude, city };
  // };

  const calculateDistance = (start, end) => {
    const earthRadius = 6371; // Earth radius in kilometers

    const toRadians = (angle) => (angle * Math.PI) / 180;

    const lat1 = toRadians(start.latitude);
    const lon1 = toRadians(start.longitude);
    const lat2 = toRadians(end.latitude);
    const lon2 = toRadians(end.longitude);

    const dLat = lat2 - lat1;
    const dLon = lon2 - lon1;

    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    const distance = earthRadius * c;
    return distance;
  };




  return (
    <>
<div className="row" style={{marginTop:'50px', display: 'flex', flexWrap: 'wrap'}}>
<div className="column" style={{flex: '1', margin: '10px'}}>
            {setLocation}
            <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open1 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '1')}
            onMouseLeave={() => handlePopoverClose('1')}
          >
      <CardMedia
        sx={{ height: 140 }}
        image={ amb1 }
        title="green iguana"
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}
      >
          Isolation  Ambulance
        </Typography>
        <Typography variant="body2" color="text.secondary">
        Isolation ambulances are designed to transport patients who have been exposed to dangerous radioactive, biological, or chemical contaminants.The ambulance staff should follow standard precautions while handling the patient and airborne precautions if aerosol generating procedures are done.        </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
        <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
        {/* <Button
  style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
  onClick={() => routeChange(generatePrice())}
  size="small"
>
  Book Now
</Button> */}
<Button
  style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
  onClick={() => {
    console.log('Button clicked');
    routeChange(generatePrice());
  }}
  size="small"
>
  Book Now
</Button>

      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-1"
          sx={{
          pointerEvents: 'none',
        }}
        open={open1}
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('1')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
        <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination)} km</p>
    </ul>

        </Typography>
      </Popover>

    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
    <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open2 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '2')}
            onMouseLeave={() => handlePopoverClose('2')}
          >
      <CardMedia
        sx={{ height: 140 }}
        image={ amb2 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
        First Responder Ambulance  
        </Typography>
        <Typography variant="body2" color="text.secondary">
        Their aim is to reach a potential life threatening emergency  in the first vital minutes to save life before the ambulance crew arrives.Their role is to help stabilise the patient and provide the appropriate care until the more highly skilled ambulance crew arrives on scene to take over the treatment.        </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-2"
          sx={{
          pointerEvents: 'none',
        }}
        open={open2}
        anchorEl={anchorE2}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('2')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
        <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location1.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination1)} km</p>
    </ul>
        </Typography>
      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
    <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open3 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '3')}
            onMouseLeave={() => handlePopoverClose('3')}
          >
       <CardMedia
        sx={{ height: 140 }}
        image={ amb3 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          Advanced life Support
        </Typography>
        <Typography variant="body2" color="text.secondary">
        The Advance life support ambulance provide primaryand secondary patient Equipment for ALS Ambulance is transportation by ground ambulance vehicle and the provision of medically necessary supplies and services including the provision of an ALS assessment or at least one ALS intervention. </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-3"
          sx={{
          pointerEvents: 'none',
        }}
        open={open3}
        anchorEl={anchorE3}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('3')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
              <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location2.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination2)} km</p>
    </ul>
        </Typography>
      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
      <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open4 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '4')}
            onMouseLeave={() => handlePopoverClose('4')}
          >
              <CardMedia
        sx={{ height: 140 }}
        image={ amb4 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          MVA Ambulance
        </Typography>
        <Typography variant="body2" color="text.secondary">
        A Multiple Victims Assistance (MVA) logistics unit is an advanced care, health or medical post that is fully configurable. It is designed to be used at large events, sports events and non-routine incidents in urban zones. However, its care capacity will vary depending on the configuration employed.
       </Typography>
       <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-4"
          sx={{
          pointerEvents: 'none',
        }}
        open={open4}
        anchorEl={anchorE4}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('4')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
                <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location3.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination3)} km</p>
    </ul>
        </Typography>
      </Popover>
    </div>
    </div>
    <div className="row" style={{marginTop:'50px', display: 'flex', flexWrap: 'wrap'}}>
    <div className="column" style={{flex: '1', margin: '10px'}}>
      <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open5 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '5')}
            onMouseLeave={() => handlePopoverClose('5')}
          >
              <CardMedia
        sx={{ height: 140 }}
        image={ amb4 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          Patient Transport Ambulance
        </Typography>
        <Typography variant="body2" color="text.secondary">
        Their purpose is simply to transport patients to, from or between places of treatment. These services are often provided by ambulance services using non-emergency vehicles, but may be subject to tendering processes. Their purpose is simply to transport patients ensuring timely and safe arrival for medical care.</Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-4"
          sx={{
          pointerEvents: 'none',
        }}
        open={open5}
        anchorEl={anchorE5}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('5')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
                <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location4.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination4)} km</p>
    </ul>
        </Typography>
      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
    <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open6 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '6')}
            onMouseLeave={() => handlePopoverClose('6')}
          >
    <CardMedia
        sx={{ height: 140 }}
        image={ amb3 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
        Neanatal Ambulance 
        </Typography>
        <Typography variant="body2" color="text.secondary">
        Neo Natal Ambulances are launched in order to ensure emergency transfers for neonates who transfers to transport recovering babies back to the hospital nearest to their homes. It is primarily launched to reduce the Infant Mortality. This specialized service is operated as a part 108 Emergency Response,        </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-6"
          sx={{
          pointerEvents: 'none',
        }}
        open={open6}
        anchorEl={anchorE6}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('6')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
                <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location5.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination5)} km</p>
    </ul>
        </Typography>
      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
    <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open7 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '7')}
            onMouseLeave={() => handlePopoverClose('7')}
          >
    <CardMedia
        sx={{ height: 140 }}
        image={ amb1 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          Ambulance Bus
        </Typography>
        <Typography variant="body2" color="text.secondary">
        An ambulance bus is a type of ambulance with the capacity to transport and treat multiple patients. An ambulance bus is used primarily for medical evacuation of medical transport of care-dependent patients, and can also be used for specific problems such as drunk patients in town centres. </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-7"
          sx={{
          pointerEvents: 'none',
        }}
        open={open7}
        anchorEl={anchorE7}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('7')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >        <Typography sx={{ p: 1 }}>
      <h4>Live Location:</h4>
  <ul>
  <p>Current Location: {location6.city}</p>
  <p>Distance from current location: {calculateDistance(currentLocation, destination6)} km</p>
  </ul>
      </Typography>
      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
      <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open8 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '8')}
            onMouseLeave={() => handlePopoverClose('8')}
          >
      <CardMedia
        sx={{ height: 140 }}
        image={ amb2 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          MVA Ambulance
        </Typography>
        <Typography variant="body2" color="text.secondary">
        A Multiple Victims Assistance (MVA) logistics unit is an advanced care, health or medical post that is fully configurable. It is designed to be used at large events, sports events and non-routine incidents in urban zones. However, its care capacity will vary depending on the configuration employed.
       </Typography>
       <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-8"
          sx={{
          pointerEvents: 'none',
        }}
        open={open8}
        anchorEl={anchorE8}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('8')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
            <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location7.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination7)} km</p>
    </ul>
        </Typography>
      </Popover>
    </div>
    </div>
    <div className="row" style={{marginTop:'50px', display: 'flex', flexWrap: 'wrap'}}>
    <div className="column" style={{flex: '1', margin: '10px'}}>
      <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open9 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '9')}
            onMouseLeave={() => handlePopoverClose('9')}
          >
        <CardMedia
        sx={{ height: 140 }}
        image={ amb1 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          ICU  Ambulance
        </Typography>
        <Typography variant="body2" color="text.secondary">
        ICU ambulances are specially designed emergency services that help in transporting critically ill patients who require intensive medical care. These ambulances come equipped with advanced life support systems, ventilators, cardiac monitors, infusion pumps, and other critical care equipment        </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-9"
          sx={{
          pointerEvents: 'none',
        }}
        open={open9}
        anchorEl={anchorE9}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('9')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
        <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location8.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination8)} km</p>
    </ul>
        </Typography>      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
    <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open10 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '10')}
            onMouseLeave={() => handlePopoverClose('10')}
          >
      <CardMedia
        sx={{ height: 140 }}
        image={ amb2 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
        Dead Body Ambulance  
        </Typography>
        <Typography variant="body2" color="text.secondary">
        Dead body ambulances are also known as mortuary vans. These ambulances are used for the dignified transportation of deceased individuals. They come with facilities to preserve and transport the body with cultural and legal requirements.transporting the deceased to mortuaries homes.        </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-10"
          sx={{
          pointerEvents: 'none',
        }}
        open={open10}
        anchorEl={anchorE10}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('10')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
        <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location9.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination9)} km</p>
    </ul>
        </Typography>      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
    <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open11 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '11')}
            onMouseLeave={() => handlePopoverClose('11')}
          >
     <CardMedia
        sx={{ height: 140 }}
        image={ amb3 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          Non Emergency
        </Typography>
        <Typography variant="body2" color="text.secondary">
        Non-emergency patient transport ambulances are helpful in transporting stable patients who require medical assistance but do not require immediate emergency care. The advantage of these ambulances is that they free up emergency resources and provide transportation services for patients </Typography>
        <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-11"
          sx={{
          pointerEvents: 'none',
        }}
        open={open11}
        anchorEl={anchorE11}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('11')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
        <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location10.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination10)} km</p>
    </ul>
        </Typography>      </Popover>
    </div>
    <div className="column" style={{flex: '1', margin: '10px'}}>
      <Card
            sx={{ maxWidth: 345, boxShadow: '0 0 5px gray' }}
            aria-owns={open12 ? 'mouse-over-popover' : undefined}
            aria-haspopup="true"
            onMouseEnter={(event) => handlePopoverOpen(event, '12')}
            onMouseLeave={() => handlePopoverClose('12')}
          >
      <CardMedia
        sx={{ height: 140 }}
        image={ amb4 }
        title="green iguana"
      />
      <CardContent>
      <Typography gutterBottom variant="h5" component="div" style={{color:'#00ab9f'}}>
          BLS Ambulance
        </Typography>
        <Typography variant="body2" color="text.secondary">
        A Basic Life Support ambulance is the most common type of emergency service and is typically the first responder in these situations. These ambulances come equipped with essential medical devices and trained personnel. So, they can provide basic medical care on the spot.
       </Typography>
       <hr />
       <p style={{color:'red'}}>Price varies as per choosen Destination</p>
       <hr />
      </CardContent>
      <CardActions>
      <p><StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}} /> <StarRateIcon style={{color:'#00ab9f'}}/> Ratings </p>
      <Button
        style={{ width: '30%', backgroundColor: '#00ab9f', color: 'white', marginLeft: '10%' }}
        onClick={() => routeChange(generatePrice())}
        size="small"
      >
        Book Now
      </Button>      </CardActions>
    </Card>
    <Popover
  id="mouse-over-popover-12"
          sx={{
          pointerEvents: 'none',
        }}
        open={open12}
        anchorEl={anchorE12}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        onClose={() => handlePopoverClose('12')}
        disableRestoreFocus
        PaperProps={{
          style: {
            width: '300px',
            height: '180px', 
          },
        }}
      >
        <Typography sx={{ p: 1 }}>
        <h4>Live Location:</h4>
    <ul>
    <p>Current Location: {location11.city}</p>
    <p>Distance from current location: {calculateDistance(currentLocation, destination11)} km</p>
    </ul>
        </Typography>      </Popover>
    </div>
    </div>
    <Subscribe />
    </>
    
  );
}