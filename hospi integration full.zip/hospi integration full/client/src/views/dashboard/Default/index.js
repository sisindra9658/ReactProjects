import React, { useState, useEffect } from 'react';
import { Grid } from '@mui/material';
import { gridSpacing } from 'store/constant';
import { styled, useTheme } from '@mui/material/styles';
import { Avatar, Box, Typography } from '@mui/material';
import MainCard from 'ui-component/cards/MainCard';
// import SkeletonEarningCard from 'ui-component/cards/Skeleton/EarningCard';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import { faCity } from '@fortawesome/free-solid-svg-icons';
import { FaUserMd } from 'react-icons/fa';
import { faBed } from '@fortawesome/free-solid-svg-icons';
import { faAmbulance } from '@fortawesome/free-solid-svg-icons';
import { faMapMarker } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';
// import { useUser } from '../../hospi-login/Usercontext';
import axios from 'axios';

const CardWrapper = styled(MainCard)(({ theme }) => ({
  backgroundColor: '#00ab9f',
  color: '#fff',
  overflow: 'hidden',
  position: 'relative',
  '&:after': {
    content: '""',
    position: 'absolute',
    width: 210,
    height: 210,
    background: '#4edcd8',
    borderRadius: '50%',
    top: -85,
    right: -95,
    [theme.breakpoints.down('sm')]: {
      top: -105,
      right: -140
    }
  },
  '&:before': {
    content: '""',
    position: 'absolute',
    width: 210,
    height: 210,
    background: '#4edcd8',
    borderRadius: '50%',
    top: -125,
    right: -15,
    opacity: 0.5,
    [theme.breakpoints.down('sm')]: {
      top: -155,
      right: -70
    }
  },
  width: '100%', // Ensure the card takes up full width
}));

const Dashboard = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const [managingAdminDetails, setManagingAdminDetails] = useState(null);

  useEffect(() => {
    // Fetch managing admin details upon component mount or login
    fetchManagingAdminDetails();
  }, []);

  const fetchManagingAdminDetails = async () => {
    try {
      const username = localStorage.getItem('username'); // Assuming the username is stored in localStorage upon login
      const response = await axios.get(`http://localhost:5000/api/hospital-details/${username}`);
      
      setManagingAdminDetails(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };

  const handleCardClick = (page) => {
    navigate(page);
  };


  return (
    <>
    {managingAdminDetails && managingAdminDetails.map((detail, index) => (
    <Grid key={index} container spacing={gridSpacing}>
      <Grid item xs={12}>
        <Grid container spacing={gridSpacing}>
          <Grid item xs={12} sm={6} md={4} lg={4}>
              <CardWrapper border={false} content={false} onClick={() => handleCardClick('/Admin/util-Doctors')}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item >
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor:"white",
                              mt: 1,
                              justifyContent: "center",
                              display: "flex"
                            }}
                          >
                            < FaUserMd />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {detail.AuthorisedPerson}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                         Authorised Person
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
            
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
              <CardWrapper border={false} content={false} onClick={() => handleCardClick('/Admin/util-Patients')}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                          < FaUserMd />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {detail.NumberOfDoctors}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        No of Doctors
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
              <CardWrapper border={false} content={false} onClick={() => handleCardClick('/Admin/util-Nurses')}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                          <FontAwesomeIcon icon={faBed} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {detail.NoOfBeds}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                      Number Of Beds
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Grid container spacing={gridSpacing}>
          <Grid item xs={12} sm={6} md={4} lg={4}>
              <CardWrapper border={false} content={false} onClick={() => handleCardClick('/Admin/util-Pharmacist')}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            <FontAwesomeIcon icon={faAmbulance} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {detail.NumberOfAmbulances}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                      Number Of Ambulances
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
              <CardWrapper border={false} content={false} onClick={() => handleCardClick('/Admin/util-Laboratorist')}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                            <FontAwesomeIcon icon={faCity} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {detail.city}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        City
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={4}>
              <CardWrapper border={false} content={false} onClick={() => handleCardClick('/Admin/util-Receptionist')}>
                <Box sx={{ p: 2.25 }}>
                  <Grid container direction="column">
                    <Grid item>
                      <Grid container justifyContent="space-between">
                        <Grid item>
                          <Avatar
                            variant="rounded"
                            sx={{
                              ...theme.typography.commonAvatar,
                              ...theme.typography.largeAvatar,
                              backgroundColor: "white",
                              mt: 1
                            }}
                          >
                             <FontAwesomeIcon icon={faMapMarker} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item>
                      <Grid container alignItems="center">
                        <Grid item>
                          <Typography sx={{ fontSize: '2.125rem', fontWeight: 500, mr: 1, mt: 1.75, mb: 0.75 }}>
                          {detail.locality}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <Avatar
                            sx={{
                              cursor: 'pointer',
                              ...theme.typography.smallAvatar,
                              backgroundColor: theme.palette.secondary[200],
                              color: theme.palette.secondary.dark
                            }}
                          >
                            <ArrowUpwardIcon fontSize="inherit" sx={{ transform: 'rotate3d(1, 1, 1, 45deg)' }} />
                          </Avatar>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item sx={{ mb: 1.25 }}>
                      <Typography
                        sx={{
                          fontSize: '1rem',
                          fontWeight: 500,
                          color: "white"
                        }}
                      >
                        Locality
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
              </CardWrapper>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
     ))}
     </>
  );
};

export default Dashboard;
