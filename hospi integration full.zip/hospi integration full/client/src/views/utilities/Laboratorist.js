 import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
import './Home.css';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import Typography from '@mui/material/Typography';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';
import { FormControl } from '@mui/material';
 
const LaboratoristForm = () => {
  const [data, setData] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [selectedLaboratorist, setSelectedLaboratorist] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    fullname: '',
    shift: '',
    qualification: '',
    department: '',
    emailaddress: '',
    contactnumber: '',
    bloodgroup: '',
    licensecertificatenumber: '',
    experience: '',
    activestatus: '',
    managing_admin: ''
  });
  const [bloodGroupOptions] = useState([
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
    // Add more blood group options as needed
  ]);
  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    // Validation logic
    let error = '';
    if (name === 'contactnumber') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'emailaddress') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the birth_date is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error
    });
  };
 
  const editlaboratorist = (laboratorist) => {
    // Set the form data to the selected pharmacist for editing
    setFormData({ ...laboratorist });
    // Set the selected pharmacist
    setSelectedLaboratorist(laboratorist);
    // Show the form for editing
    setShowForm(true);
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    try {
      if (selectedLaboratorist) {
        // If a patient is selected, update the patient
        await axios.put(`http://localhost:5000/api/updatelaboratorist/${selectedLaboratorist.employeeid}`, formData);
        toast.success('laboratorist updated successfully');
      } else {
        // If no patient is selected, add a new patient
        await axios.post('http://localhost:5000/api/postlaboratorist', formData);
        toast.success('laboratorist added successfully');
      }
      // Reset the form after successful submission
      setFormData({
        fullname: '',
        shift: '',
        qualification: '',
        department: '',
        emailaddress: '',
        contactnumber: '',
        bloodgroup: '',
        licensecertificatenumber: '',
        experience: '',
        activestatus: '',
        managing_admin: ''
      });
 
      // Fetch updated data
      setSelectedLaboratorist(null);

      // Reload data from the server to update the table
      loadData();
      setShowForm(false);
    } catch (error) {
      console.error('Error submitting receptionist data:', error);
    }
  };
 
  // const loadData = async () => {
  //   try {
  //     const response = await axios.get("http://localhost:5000/api/get/laboratorist");
  //     setData(response.data);
  //   } catch (error) {
  //     console.error('Error loading data:', error);
  //   }
  // };
 
  // useEffect(() => {
  //   loadData();
  // }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/laboratorist/${username}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };
 
  const deleteContact = (employeeid) => {
    if (window.confirm("Are you sure that you wanted to delete that contact?")) {
      axios.delete(`http://localhost:5000/api/remove4/${employeeid}`)
        .then(() => {
          toast.success("Contact Deleted Successfully");
        })
        .catch((error) => {
          console.error('Error deleting contact:', error);
        });
 
      setTimeout(() => {
        loadData();
      }, 500);
    }
  };
 
  const handleSearch = () => {
    setData(
      data.filter((item) => {
        const lowerCaseSearchInput = searchInput.toLowerCase();
        const lowerCaseFullName = item.fullname.toLowerCase();
        const lowerCaseMobile = item.contactnumber.toLowerCase();
        const lowerCaseShift = item.shift.toLowerCase();
 
        return (
          lowerCaseFullName.includes(lowerCaseSearchInput) ||
          lowerCaseMobile.includes(lowerCaseSearchInput) ||
          lowerCaseShift.includes(lowerCaseSearchInput)
        );
      })
    );
  };
 
  return (
    <>
        {data.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8} style={{ backgroundColor: '#4edcd8' }}>
        <Breadcrumbs aria-label="breadcrumb" >
          <Link color="inherit" underline="hover" href="/free">{<HomeIcon />}</Link>
          <Link color="inherit" underline="hover" href="/free">
            Home
          </Link>
          <Link color="inherit" underline="hover" href="/utils">
            Utilities
          </Link>
          <Typography color="textPrimary">Add Laboratorist</Typography>
        </Breadcrumbs>
      </Stack>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8}>
        <Button variant="contained" justifyContent="flex-end" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto' }} onClick={() => setShowForm(true)}>
          Add Laboratorist
        </Button>
      </Stack>
 
      {showForm && (
        <Stack direction="column" spacing={2} position="relative" mb={2}>
        <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white', width: '80%', maxWidth: '800px', margin: '0 auto' }} onSubmit={handleSubmit}>            <IconButton color="primary" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
              <CloseIcon />
            </IconButton>
            <h1 style={{ justifyContent: 'center', textAlign: 'center' }}>{selectedLaboratorist ? 'Update Laboratorist Details' : 'Add Laboratorist'}</h1>
            <Box display="flex" flexDirection="column" mt={2} ml={2} mr={2}>
              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                  <input label="Full Name" name="fullname" placeholder="Full Name" value={formData.fullname} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
        <select
          id="shift"
          name="shift"
          value={formData.shift}
          onChange={handleChange}
          label="shift"
          style={{width:'100%', height:'39px', marginTop:'2px'}}
        >
          <option value="">Shift</option>
          <option value="Day Shift">Day shift</option>
          <option value="Evening Shift">Morning shift</option>
          <option value="Night Shift">Night shift</option>
        </select>
      </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Qualifications" placeholder="Qualifications" name="qualifications" value={formData.qualifications} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Department" placeholder="Department" name="department" value={formData.department} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Email" placeholder="Email" name="emailaddress" value={formData.emailaddress} onChange={handleChange} />
                  {errors.emailaddress && <span style={{ color: 'red' }}>{errors.emailaddress}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Mobile" placeholder="Mobile" name="contactnumber" value={formData.contactnumber} onChange={handleChange} />
                  {errors.contactnumber && <span style={{ color: 'red' }}>{errors.contactnumber}</span>}
                </Grid>
              </Grid>
 
              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
                  <select
                    id="bloodgroup"
                    name="bloodgroup"
                    value={formData.bloodgroup}
                    onChange={handleChange}
                    label="Blood Group"
                    style={{width:'100%', height:'39px', marginTop:'2px'}}
                  >
                    <option value="">BloodGroup</option>
                    {bloodGroupOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </FormControl>
                </Grid>
 
                <Grid item xs={12} sm={4}>
                  <input label="License Certificate Number" placeholder="License Number" name="licensecertificatenumber" value={formData.licensecertificatenumber} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Experience" placeholder="Experience" name="experience" value={formData.experience} onChange={handleChange} />
                </Grid>
              </Grid>
              <Grid container spacing={2} mb={3}>
              <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
        <select
          id="activestatus"
          name="activestatus"
          value={formData.activestatus}
          onChange={handleChange}
          label="Status"
          style={{width:'100%', height:'39px', marginTop:'2px'}}
        >
          <option value="">Status</option>
          <option value="Active">Active</option>
          <option value="InActive">InActive</option>
        
        </select>
      </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Hospital Name" placeholder="Hospital Name" name="managing_admin" value={formData.managing_admin} onChange={handleChange} />
                </Grid>
              </Grid>
              <Box display="flex" justifyContent="space-between">
                <Button variant="contained" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto', height: '32px', mt: '8px', mb: '20px' }} type="submit">
                  Add Laboratorist
                </Button>
              </Box>
            </Box>
          </form>
        </Stack>
      )}
 
      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center' }} mt={1} mb={1}>
        <Grid item xs={4}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input
            label="Search laboratorist"
            placeholder="Search by Name, Mobile, etc."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            style={{ width: '50%', height: '39px', marginTop: '2px' }}
            />
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
        </div>
        </Grid>
      </Grid>
 
      <table className="adminstyled-table">
        <thead>
          <tr>
            <th>Id.</th>
            <th>Full Name</th>
            <th>Shift</th>
            <th>Qualifications</th>
            <th>Department</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Blood Group</th>
            <th>License Certificate Number</th>
            <th>Experience</th>
            <th>Active Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={item.employeeid}>
              <th scope="row">{index + 1}</th>
              <td>{item.fullname}</td>
              <td>{item.shift}</td>
              <td  style={{ wordBreak: 'break-all' }}>{item.qualifications}</td>
              <td>{item.department}</td>
              <td  style={{ wordBreak: 'break-all' }}>{item.emailaddress}</td>
              <td>{item.contactnumber}</td>
              <td>{item.bloodgroup}</td>
              <td>{item.licensecertificatenumber}</td>
              <td>{item.experience}</td>
              <td>{item.activestatus}</td>
              <td>
                <button className='adminbtn btn-edit' onClick={() => editlaboratorist(item)}>
                  <EditIcon />
                </button>
                <button className='adminbtn btn-edit' onClick={() => deleteContact(item.employeeid)}>
                  <DeleteIcon />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
    )}
    </>
  );
};
 
export default LaboratoristForm;
 