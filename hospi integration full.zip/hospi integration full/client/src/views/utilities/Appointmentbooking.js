import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
import './Home.css';
import SearchIcon from '@mui/icons-material/Search';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import Typography from '@mui/material/Typography';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';
import { Modal, InputLabel, FormControl, FormGroup, FormControlLabel } from '@mui/material';
import { format } from 'date-fns';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { styled } from '@mui/material/styles';

const DownloadProgressModal = ({ isOpen, handleClose, downloadProgress }) => {
  return (
    <Modal open={isOpen} onClose={handleClose} aria-labelledby="modal-download-progress" aria-describedby="modal-download-progress">
      <div style={{ position: 'absolute', top: '10%', left: '50%', transform: 'translate(-50%, -50%)', width: 200, backgroundColor: '#ff0000', boxShadow: 24, padding: 4 }}>
        <h2 id="modal-download-progress">Download Progress</h2>
        <p id="modal-download-progress">Download Progress: {downloadProgress}%</p>
        <Button onClick={handleClose}>Close</Button>
      </div>
    </Modal>
  );
};
 
const AppointmentDetails = ({ isOpen, handleClose, patientDetails }) => {

  const [downloadProgress, setDownloadProgress] = useState(0); // State to track download progress
  const [isDownloadProgressOpen, setIsDownloadProgressOpen] = useState(false);
 
  const {
    patient_id,
    name,
    contact,
    email,
    address,
    doctor_name,
    booking_time,
    consultation_fee,
    booking_date,
    weight,
    height,
    temperature,
    blood_pressure,
    paymentMode,
    status
  } = patientDetails;
 
  const [formData, setFormData] = useState({
    patient_id,
    weight,
    height,
    temperature,
    blood_pressure,
    paymentMode: '',
    status: ''
  });
 
  const [cancellationReasons, setCancellationReasons] = useState([]);
 
  useEffect(() => {
    setFormData({
      patient_id,
      weight,
      height,
      temperature,
      blood_pressure,
      paymentMode: patientDetails.paymentMode || '',
      status: patientDetails.status || ''
    });
  }, [patientDetails]);
 
  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    // Validation logic
    let error = '';
    if (name === 'mobile') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'email') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the birth_date is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error
    });
  };
 
  const handleReasonChange = (e) => {
    const { value, checked } = e.target;
 
    if (checked) {
      setCancellationReasons([...cancellationReasons, value]);
    } else {
      setCancellationReasons(cancellationReasons.filter((reason) => reason !== value));
    }
  };

  const handleDownload = async () => {
    try {
      toast.info('Download started...');
      setIsDownloadProgressOpen(true);

      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        setDownloadProgress(progress);
        if (progress === 100) {
          clearInterval(interval);
          toast.success('Download successful');
          setIsDownloadProgressOpen(false);
        }
      }, 1000);

      await axios.post('http://localhost:5000/api/download-pdf', formData);
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast.error('Download failed');
      setIsDownloadProgressOpen(false);
    }
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (patientDetails) {
        await axios.put(`http://localhost:5000/api/updateappointment1/${patientDetails.patient_id}`, formData);
        toast.success('Patient details updated successfully');
      } else {
        await axios.post('http://localhost:5000/api/postappointment1', formData);
        toast.success('Patient details added successfully');
      }
 
      setFormData({
        weight: '',
        height: '',
        temperature: '',
        blood_pressure: '',
        paymentMode: '',
        status: '',
        cancellationReasons: ''
      });
      loadData();
      setSelectedPatientDetails(null);
 
      onPatientDetailsChange(null);
 
      setDetailsModalOpen(false);
      setShowForm(false);
      handleClose();
    } catch (error) {
      console.error('Error submitting patient data:', error);
    }
    window.location.reload();
  };
 
  const loadData = async () => {
    const response = await axios.get('http://localhost:5000/api/get/booking');
    setData(response.data);
  };
 
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
              <html>
                <head>
                  <title>Appointment Details</title>
                  <style>
                    body {
                      font-family: Arial, sans-serif;
                    }
                    h1 {
                      text-align: center;
                    }
                    table {
                      width: 100%;
                      border-collapse: collapse;
                      margin-bottom: 20px;
                    }
                    th, td {
                      border: 1px solid #ddd;
                      padding: 8px;
                      text-align: left;
                    }
                    th {
                      background-color: #f2f2f2;
                    }
                  </style>
                </head>
                <body>
                  <h1>Patient Details</h1>
                  <table>
                    <tr>
                      <th>Patient ID</th>
                      <td>${patient_id}</td>
                    </tr>
                    <tr>
                      <th>Name</th>
                      <td>${name}</td>
                    </tr>
                    <tr>
                      <th>Mobile Number</th>
                      <td>${contact}</td>
                    </tr>
                    <tr>
                      <th>Email</th>
                      <td>${email}</td>
                    </tr>
                    <tr>
                      <th>Address</th>
                      <td>${address}</td>
                    </tr>
                    <tr>
                      <th>Doctor</th>
                      <td>${doctor_name}</td>
                    </tr>
                    <tr>
                      <th>Booking Date</th>
                      <td>${format(new Date(booking_date), 'yyyy-MM-dd')}</td>
                    </tr>
                    <tr>
                      <th>Booking Time</th>
                      <td>${booking_time}</td>
                    </tr>
                    <tr>
                      <th>Weight</th>
                      <td>${weight}</td>
                    </tr>
                    <tr>
                      <th>Height</th>
                      <td>${height}</td>
                    </tr>
                    <tr>
                      <th>Temperature</th>
                      <td>${temperature}</td>
                    </tr>
                    <tr>
                      <th>Blood Pressure</th>
                      <td>${blood_pressure}</td>
                    </tr>
                    <tr>
                      <th>Consultation Fee</th>
                      <td>${consultation_fee}</td>
                    </tr>
                    <tr>
                      <th>Payment Mode</th>
                      <td>${paymentMode}</td>
                    </tr>
                    <tr>
                      <th>Payment Status</th>
                      <td>${status}</td>
                    </tr>
                   
                  </table>
                </body>
              </html>
            `);
    printWindow.document.close();
    printWindow.print();
  };
 
  const BpIcon = styled('span')(({ theme }) => ({
    borderRadius: '50%',
    width: 16,
    height: 16,
    boxShadow:
      theme.palette.mode === 'dark'
        ? '0 0 0 1px rgb(16 22 26 / 40%)'
        : 'inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)',
    backgroundColor: theme.palette.mode === 'dark' ? '#394b59' : '#f5f8fa',
    backgroundImage:
      theme.palette.mode === 'dark'
        ? 'linear-gradient(180deg,hsla(0,0%,100%,.05),hsla(0,0%,100%,0))'
        : 'linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))',
    '.Mui-focusVisible &': {
      outline: '2px auto rgba(19,124,189,.6)',
      outlineOffset: 2
    },
    'input:hover ~ &': {
      backgroundColor: theme.palette.mode === 'dark' ? '#30404d' : '#ebf1f5'
    },
    'input:disabled ~ &': {
      boxShadow: 'none',
      background: theme.palette.mode === 'dark' ? 'rgba(57,75,89,.5)' : 'rgba(206,217,224,.5)'
    }
  }));
 
  const BpCheckedIcon = styled(BpIcon)({
    backgroundColor: '#137cbd',
    backgroundImage: 'linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))',
    '&::before': {
      display: 'block',
      width: 16,
      height: 16,
      backgroundImage: 'radial-gradient(#fff,#fff 28%,transparent 32%)',
      content: '""'
    },
    'input:hover ~ &': {
      backgroundColor: '#106ba3'
    }
  });
 
  // Inspired by blueprintjs
  function BpRadio(props) {
    return <Radio disableRipple color="default" checkedIcon={<BpCheckedIcon />} icon={<BpIcon />} {...props} />;
  }
 
  return (
    <>
      <Modal open={isOpen} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
      <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white', width: '80%', maxWidth: '800px', margin: '0 auto' }}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 400,
            bgcolor: 'background.paper',
            boxShadow: 24,
            p: 4
          }}
        >
          <Typography id="modal-modal-title" variant="h6" component="h2">
            <h1 className='namecolor'>Patient Details</h1>
            <h3 className='namecolor'>(Patient Name: {name})</h3>
            <h3 className='namecolor'>(Booking Date: {format(new Date(booking_date), 'yyyy-MM-dd')})</h3>
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
                <input label="Weight" placeholder='Weight' name="weight" value={formData.weight} onChange={handleChange} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <input label="Height" placeholder='Height' name="height" value={formData.height} onChange={handleChange} />
              </Grid>
              <Grid item xs={6}>
                <input label="Temperature" placeholder='Temperature' name="temperature" value={formData.temperature} onChange={handleChange} />
              </Grid>
              <Grid item xs={6}>
                <input label="Blood Pressure" placeholder='Blood Pressure' name="blood_pressure" value={formData.blood_pressure} onChange={handleChange} />
              </Grid>
              <Grid item xs={6}>
                  <select
                    id="paymentMode"
                    name="paymentMode"
                    label="paymentMode"
                    placeholder="paymentMode"
                    value={formData.paymentMode}
                    onChange={handleChange}
                    style={{width:'100%', height:'39px', marginTop:'2px'}}
                  >
                    <option value=""> Payment Mode </option>
                    <option value="Cash">Cash</option>
                    <option value="Online">Online</option>
                    <option value="UPI">UPI</option>
                  </select>
              </Grid>
              <Grid item xs={6}>
                  <select
                    id="status"
                    name="status"
                    label="Status"
                    value={formData.status}
                    onChange={handleChange}
                    style={{width:'100%', height:'39px', marginTop:'2px'}}
                  >
                   <option value=""> Status </option>
                    <option value="Pending">Pending</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
              </Grid>
              {formData.status === 'Cancelled' && (
                <Grid item xs={12}>
                  <FormControl component="fieldset">
                    <InputLabel id="cancellation-reasons-label">Cancellation Reasons</InputLabel>
                    <FormGroup>
                      {/* {reasonsForCancellation.map((reason) => (
                        <FormControlLabel key={reason} control={<Checkbox onChange={handleReasonChange} name={reason} />} label={reason} />
                      ))} */}
                      <RadioGroup defaultValue="Doctor Unavailable" aria-labelledby="demo-customized-radios" name="customized-radios">
                        <FormControlLabel
                          value="Doctor Unavailable"
                          control={<BpRadio />}
                          label="Doctor Unavailable"
                          onChange={handleReasonChange}
                        />
                        <FormControlLabel
                          value="Patient did not show up"
                          control={<BpRadio />}
                          label="Patient did not show up"
                          onChange={handleReasonChange}
                        />
                        <FormControlLabel value="Emergency" control={<BpRadio />} label="Emergency" onChange={handleReasonChange} />
                        <FormControlLabel
                          value="Changed to another healthcare provider"
                          control={<BpRadio />}
                          label="Changed to another healthcare provider"
                          onChange={handleReasonChange}
                        />
                      </RadioGroup>
                    </FormGroup>
                  </FormControl>
                </Grid>
              )}
            </Grid>
          </Typography>
          <div style={{ marginBottom: '20px', marginTop: '20px' }}>
            <Button style={{ right: 90, position: 'absolute' }} onClick={handleSubmit}>
              Save
            </Button>
            <Button style={{ right: 20, position: 'absolute' }} onClick={handleClose}>
              Close
            </Button>
            <Button style={{ right: 160, position: 'absolute' }} onClick={handlePrint}>
              Print
            </Button> <Button style={{ right: 210, position: 'absolute' }} onClick={handleDownload}>Download</Button>
            {/* {downloadProgress > 0 && downloadProgress < 100 && (
              <div style={{ marginTop: '50px' }}>
                Download Progress: {downloadProgress}%
              </div>
            )}     */}
          </div>
        </Box>
        </form>
      </Modal>
      <DownloadProgressModal isOpen={isDownloadProgressOpen} handleClose={() => setIsDownloadProgressOpen(false)} downloadProgress={downloadProgress} />
    </>
  );
};
 
const AppointmentBookingForm = () => {
  const [searchInput, setSearchInput] = useState('');
  const [data, setData] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date()); // New state for selected date
 
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    email: '',
    address: '',
    booking_date: '',
    clinic_name: '',
    locality: '',
    doctor_name: '',
    doctor_id: '',
    slot_time: '',
    consultation_fee: '',
    weight: '',
    height: '',
    temperature: '',
    blood_pressure: '',
    status: '',
    cancellationReasons: '',
    managing_admin: ''
  });
 
  const [Slottimes, setSlotTimes] = useState([]);
  const [isDetailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedPatientDetails, setSelectedPatientDetails] = useState(null);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
 
  const [doctors, setDoctors] = useState([]);
 
  const formattedDate = format(selectedDate, 'yyyy-MM-dd');
 
 
  const fetchDoctorNames = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/get/doctors');
      setDoctors(response.data);
    } catch (error) {
      console.error('Error fetching doctor names:', error);
    }
  };
 
  const editPatientdetails = (patientdetails) => {
    setFormData({ ...patientdetails });
    setSelectedPatientDetails(patientdetails);
    setShowForm(true);
  };
  const editAppointment = (appointment) => {
    // Set the form data to the selected appointment for editing
 
    setFormData({ ...appointment });
    // Set the selected appointment
    setSelectedAppointment(appointment);
    // Show the form for editing
    setShowForm(true);
  };
 
  const openDetailsModal = (patientDetails) => {
    editPatientdetails();
    setSelectedPatientDetails(patientDetails);
    setDetailsModalOpen(true);
  };
 
  const closeDetailsModal = () => {
    setDetailsModalOpen(false);
  };
 

  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    const selectedDoctor = doctors.find((doctor) => doctor.doctor_name === value);


    // Validation logic
    let error = '';
    if (name === 'contact') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'email') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the birth_date is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
        consultation_fee: selectedDoctor ? selectedDoctor.consultation_fee : formData.consultation_fee,
        doctor_id: selectedDoctor ? selectedDoctor.doctor_id : formData.doctor_id
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error
    });
  };

  const handleDateChange = async (date) => {
    setSelectedDate(new Date(date.target.value)); // Convert the string to a Date object
    // Fetch slot times for the selected doctor and date
    const response = await axios.get(`http://localhost:5000/api/get/doctor-slots/${formData.doctor_id}/${date.target.value}`);
    if (response.data) {
      const slotTimes = response.data.map((slot) => ({
        value: `${slot.from_time} - ${slot.to_time}`,
        label: `${slot.from_time} - ${slot.to_time}`
      }));
      setSlotTimes(slotTimes);
    }
    console.log('Formatted Date:', formattedDate);
 
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    try {
      if (selectedAppointment) {
        await axios.put(`http://localhost:5000/api/updateappointment/${selectedAppointment.patient_id}`, formData);
        toast.success('Appointment updated successfully');
      } else {
        const formattedDate = format(selectedDate, 'yyyy-MM-dd');
        await axios.post('http://localhost:5000/api/postappointment',{ ...formData, booking_date: formattedDate });
        toast.success('Appointment added successfully');
      }
 
      setFormData({
        name: '',
        contact: '',
        email: '',
        address: '',
        booking_date: '',
        clinic_name: '',
        locality: '',
        doctor_name: '',
        doctor_id: '',
        slot_time: '',
        consultation_fee: '',
        weight: '',
        height: '',
        temperature: '',
        blood_pressure: '',
        status: '',
        cancellationReasons: '',
        managing_admin: ''
      });
      setSelectedAppointment(null);
      loadData();
      setShowForm(false);
    } catch (error) {
      console.error('Error submitting Appointment data:', error);
    }
  };


  const loadData = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/appointment_booking/${username}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };
 
  const deleteAppointment = async (patient_id) => {
    if (window.confirm('Are you sure that you wanted to delete that contact?')) {
      try {
        await axios.delete(`http://localhost:5000/api/remove6/${patient_id}`);
        toast.success('Appointment Deleted Successfully');
        loadData();
      } catch (error) {
        console.error('Error deleting appointment:', error);
        toast.error('Error Deleting Appointment');
      }
    }
    loadData();
  };
 
  useEffect(() => {
    loadData();
  }, []);
 
  const handleSearch = () => {
    setData(
      data.filter((item) => {
        const lowerCaseSearchInput = searchInput.toLowerCase();
        const lowerCasePatientID = item.patient_id.toLowerCase();
        const lowerCaseFullName = item.name.toLowerCase();
        const lowerCaseMobile = item.contact.toLowerCase();
        const lowerCaseEmail = item.email.toLowerCase();
        const lowerCasePayment = item.paymentMode.toLowerCase();
        const lowerCaseStatus = item.status.toLowerCase();
        const lowerCaseDoctorName = item.doctor_name.toLowerCase();
        return (
          lowerCasePatientID.includes(lowerCaseSearchInput) ||
          lowerCaseFullName.includes(lowerCaseSearchInput) ||
          lowerCaseEmail.includes(lowerCaseSearchInput) ||
          lowerCasePayment.includes(lowerCaseSearchInput) ||
          lowerCaseStatus.includes(lowerCaseSearchInput) ||
          lowerCaseDoctorName.includes(lowerCaseSearchInput) ||
          lowerCaseMobile.includes(lowerCaseSearchInput)
        );
      })
    );
  };
 
  const statusColors = {
    Pending: 'blue',
    Confirmed: '#7CFC00',
    Cancelled: 'red'
  };
 
  return (
    <>
        {data.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8} style={{ backgroundColor: '#4edcd8' }}>
        <Breadcrumbs aria-label="breadcrumb">
          <Link color="inherit" underline="hover" href="/free">
            {<HomeIcon />}
          </Link>
          <Link color="inherit" underline="hover" href="/free">
            Home
          </Link>
          <Link color="inherit" underline="hover" href="/utils">
            Utilities
          </Link>
          <Typography color="textPrimary">Book Appointment</Typography>
        </Breadcrumbs>
      </Stack>
 
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8}>
        <Button
          variant="contained"
          justifyContent="flex-end"
          startIcon={<PersonAddAlt1Icon />}
          sx={{ ml: 'auto' }}
          onClick={() => setShowForm(true)}
        >
          Book Appointment
        </Button>
      </Stack>
 
      {showForm && (
        <Stack direction="column" spacing={2} position="relative" mb={2}>
          <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white',width: '80%', maxWidth: '800px', margin: '0 auto' }} onSubmit={handleSubmit}>
            <IconButton color="primary" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
              <CloseIcon />
            </IconButton>
            <h1 style={{ justifyContent: 'center', textAlign: 'center' }}>
              {selectedAppointment ? 'Update Book Appointment Details' : 'Book Appointment'}
            </h1>
            <Box display="flex" flexDirection="column" mt={2} ml={2} mr={2}>
              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                  <input label="Full Name" name="name" value={formData.name} onChange={handleChange} placeholder='Name' />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Mobile" name="contact" value={formData.contact} onChange={handleChange} placeholder='Contact' />
                  {errors.contact && <span style={{ color: 'red' }}>{errors.contact}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Email" name="email" value={formData.email} onChange={handleChange} placeholder='Email' />
                  {errors.email && <span style={{ color: 'red' }}>{errors.email}</span>}
                </Grid>
              </Grid>
 
              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                  <input label="Address" name="address" value={formData.address} onChange={handleChange} placeholder='Address' />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <select
                    label="Doctor Name"
                    name="doctor_name"
                    value={formData.doctor_name}
                    onClick={fetchDoctorNames}
                    onChange={handleChange}
                    style={{width:'100%', height:'39px', marginTop:'2px'}}
                  >
                   <option value=''> Doctor Name  </option>
                    {doctors.map((doctor) => (
                      <option key={doctor.doctor_name} value={doctor.doctor_name}>
                        {doctor.doctor_name}
                      </option>
                    ))}
                  </select>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input
                    label="Booking Date"
                    type="date"
                    name="booking_date"
                    value={formData.selectedDate}
                    onChange={handleDateChange}
                  />
                </Grid>
              </Grid>
 
              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                  <select
                    label="Booking Time"
                    name="slot_time"
                    value={formData.slot_time}
                    onChange={handleChange}
                    style={{width:'100%', height:'39px', marginTop:'2px'}}
                    placeholder='Slot Time'
                  >
                  <option value=''> Booking Time </option>
                     {Slottimes.map((slot) => (
      <option key={slot.value} value={slot.value}>
        {slot.label}
      </option>
    ))}
                  </select>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <input
                    label="Consultation Fee"
                    name="consultation_fee"
                    value={formData.consultation_fee}
                    onChange={handleChange}
                    disabled
                    placeholder='Consultation Fee'
                  ></input>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <input
                    label="doctor_id"
                    name="doctor_id"
                    onChange={handleChange}
                    value={formData.doctor_id}
                    disabled
                    placeholder='Doctor Id'
                  ></input>
                </Grid>
              </Grid>
 
              <Grid container spacing={2} mb={3}>
              <Grid item xs={6} sm={4}>
                  <input
                    label="Hospital Name"
                    name="managing_admin"
                    value={formData.managing_admin}
                    onChange={handleChange}
                    placeholder='Hospital Name'
                  />
                </Grid>
              </Grid>
 
              <Box display="flex" justifyContent="space-between">
                <Button variant="contained" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto', height: '32px', mt: '8px' }} type="submit">
                  {selectedAppointment ? 'Update Book Appointment' : 'Book Appointment'}
                </Button>
              </Box>
            </Box>
          </form>
        </Stack>
      )}
 
      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center' }} mt={1} mb={1}>
        <Grid item xs={4}>
          <TextField
            label="Search appointment"
            placeholder="Search by Name, Mobile, etc."
            variant="outlined"
            fullWidth
            margin="normal"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
              )
            }}
          />
        </Grid>
      </Grid>
 
      <table className="adminstyled-table">
        <thead>
          <tr>
            <th>Id.</th>
            <th>FullName</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Address</th>
            <th>Booking date</th>
            <th>Booking time</th>
            <th>Doctor name</th>
            <th>Consultation fee</th>
            <th>Payment mode</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => {
            return (
              <tr key={item.patient_id}>
                <td>{item.patient_id}</td>
                <td>{item.name}</td>
                <td>{item.contact}</td>
                <td style={{ wordBreak: 'break-all' }}>{item.email}</td>
                <td style={{ wordBreak: 'break-all' }}>{item.address}</td>
                <td>{item.booking_date}</td>
                <td>{item.slot_time}</td>
                <td>{item.doctor_name}</td>
                <td>{item.consultation_fee}</td>
                <td>{item.paymentMode}</td>
                <td style={{ color: statusColors[item.status], fontWeight: 'bold', padding: '5px' }}>
                  {item.status}
                  <br />
                  --
                  <br />
                  {item.cancellationReasons}
                </td>
 
                <td>
                  <button className="adminbtn btn-edit" onClick={() => editAppointment(item)}>
                    <EditIcon />
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => deleteAppointment(item.patient_id)}>
                    <DeleteIcon />
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => openDetailsModal(item)}>
                    <MoreVertIcon />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {selectedPatientDetails && (
        <AppointmentDetails
          isOpen={isDetailsModalOpen}
          handleClose={closeDetailsModal}
          patientDetails={selectedPatientDetails}
          onPatientDetailsChange={setSelectedPatientDetails}
        />
      )}
    </>
    )}
    </>
  );
};
 
export default AppointmentBookingForm;
 