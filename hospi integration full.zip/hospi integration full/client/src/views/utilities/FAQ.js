import React, { useState, useEffect } from 'react';
import { FaSave } from 'react-icons/fa';
import './FAQ.css';

const FormComponent = () => {
  const [data, setData] = useState([]);
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    phone_number: '',
    email: '',
    date: '',
    timeslot: '',
    doctor: ''
  });

  useEffect(() => {
    // Fetch data from the backend API
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/data');
        const result = await response.json();
        setData(result);

        // Set form data to the last row
        if (result.length > 0) {
          const lastRow = result[result.length - 1];
          setFormData(lastRow);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSave = async () => {
    // Update the data on the backend
    try {
      const response = await fetch(`http://localhost:5000/api/data/${formData.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const updatedData = await response.json();
        setData(data.map(item => (item.id === updatedData.id ? updatedData : item)));
        console.log('Saved:', updatedData);
      } else {
        console.error('Failed to save data');
      }
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  return (
    <div>
      <table className="form-table">
        <thead>
          <tr>
            <th>Label</th>
            <th>Value</th>
            <th>Save</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Name:</td>
            <td>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
              />
            </td>
            <td><FaSave className="save-icon" onClick={handleSave} /></td>
          </tr>
          <tr>
            <td>Phone Number:</td>
            <td>
              <input
                type="text"
                name="phone_number"
                value={formData.phone_number}
                onChange={handleChange}
              />
            </td>
            <td><FaSave className="save-icon" onClick={handleSave} /></td>
          </tr>
          <tr>
            <td>Email:</td>
            <td>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </td>
            <td><FaSave className="save-icon" onClick={handleSave} /></td>
          </tr>
          <tr>
            <td>Date:</td>
            <td>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
              />
            </td>
            <td><FaSave className="save-icon" onClick={handleSave} /></td>
          </tr>
          <tr>
            <td>Timeslot:</td>
            <td>
              <input
                type="text"
                name="timeslot"
                value={formData.timeslot}
                onChange={handleChange}
              />
            </td>
            <td><FaSave className="save-icon" onClick={handleSave} /></td>
          </tr>
          <tr>
            <td>Doctor:</td>
            <td>
              <input
                type="text"
                name="doctor"
                value={formData.doctor}
                onChange={handleChange}
              />
            </td>
            <td><FaSave className="save-icon" onClick={handleSave} /></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default FormComponent;
