import React from 'react'

function Help() {
  return (
    <center style={{alignItems: 'center',marginTop: '25%'}}>
        <h1>Help</h1>
      </center>
  )
}

export default Help