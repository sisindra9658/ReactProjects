import SearchIcon from '@mui/icons-material/Search';
import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import './Home.css';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import axios from 'axios';
import { Modal, Grid, TextField, FormLabel } from '@mui/material';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import Typography from '@mui/material/Typography';
import HomeIcon from '@mui/icons-material/Home';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import { toast } from 'react-toastify';
import Switch from '@mui/material/Switch';
import './Shadow.css';
import { FaCalendarAlt } from 'react-icons/fa';
const AppointmentDetails = ({ isOpen, handleClose, doctordetails }) => {
  const { doctor_id, doctor_name, OP_start_time, OP_end_time } = doctordetails;

  const [timeSlotGap, setTimeSlotGap] = useState(30); // Default to 30-minute gap
  const [selectedInterval, setSelectedInterval] = useState('30'); // Default to 30-minute interval

  const [selectedDate, setSelectedDate] = useState('');

  const [showTimeSlots, setShowTimeSlots] = useState({
    Sunday: false,
    Monday: false,
    Tuesday: false,
    Wednesday: false,
    Thursday: false,
    Friday: false,
    Saturday: false
  });

  const handleDateChange = (event) => {
    const selectedDate = event.target.value;
    setSelectedDate(selectedDate);
    updateShowTimeSlots(selectedDate);
  };

  const updateShowTimeSlots = (selectedDate) => {
    const selectedDayIndex = new Date(selectedDate).getDay();
    const selectedDay = daysOfWeek[selectedDayIndex];
    const updatedShowTimeSlots = { ...showTimeSlots };
    Object.keys(updatedShowTimeSlots).forEach((day) => {
      updatedShowTimeSlots[day] = day === selectedDay;
    });
    setShowTimeSlots(updatedShowTimeSlots);
  };

  const handleGapChange = (event) => {
    const interval = event.target.checked ? '15' : '30';
    if (window.confirm(`Are you sure you want to switch ${interval}-minute slots?`)) {
      setTimeSlotGap(parseInt(interval));
      setSelectedInterval(interval);
    }
  };

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const generateTimeOptions = () => {
    const timeOptions = [];
    const startHour = parseInt(OP_start_time.split(':')[0], 10);
    const endHour = parseInt(OP_end_time.split(':')[0], 10);
    const gap = timeSlotGap; // Use the selected time slot gap

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += gap) {
        const meridiem = hour >= 12 ? 'PM' : 'AM';
        const formattedHour = hour % 12 || 12; // Convert to 12-hour format
        const formattedMinute = String(minute).padStart(2, '0');
        const formattedTime = `${formattedHour}:${formattedMinute} ${meridiem}`;
        timeOptions.push(formattedTime);
      }
    }
    return timeOptions;
  };

  const Reports = React.memo(({ day }) => {
    const [showTimeSlots, setShowTimeSlots] = useState(false);
    const [timeSelections, setTimeSelections] = useState({
      Sunday: [{ from: '', to: '' }],
      Monday: [{ from: '', to: '' }],
      Tuesday: [{ from: '', to: '' }],
      Wednesday: [{ from: '', to: '' }],
      Thursday: [{ from: '', to: '' }],
      Friday: [{ from: '', to: '' }],
      Saturday: [{ from: '', to: '' }]
    });

    useEffect(() => {
      const selectedDayIndex = new Date(selectedDate).getDay(); // 0 for Sunday, 1 for Monday, etc.
      const selectedDay = daysOfWeek[selectedDayIndex];

      if (selectedDay === day) {
        setShowTimeSlots(true);
      } else {
        setShowTimeSlots(false);
      }
    }, [selectedDate, day]);

    const handleTimeChange = (day, slot, field, value, index) => {
      let timeSelections1 = localStorage.getItem('timeslots');
      if (timeSelections1) {
        timeSelections1 = JSON.parse(timeSelections1);
      } else {
        timeSelections1 = timeSelections;
      }
      const updatedTimeSelectionsitems = { ...timeSelections1 };
      updatedTimeSelectionsitems[day][index] = { ...updatedTimeSelectionsitems[day][index], [field]: value };

      setTimeSelections(updatedTimeSelectionsitems);
      localStorage.setItem('timeslots', JSON.stringify(updatedTimeSelectionsitems));
    };

    const handleAddTimeSelection = () => {
      let timeSelections1 = localStorage.getItem('timeslots');
      if (timeSelections1) {
        timeSelections1 = JSON.parse(timeSelections1);
      } else {
        timeSelections1 = timeSelections;
      }
      const updatedTimeSelectionsitems = { ...timeSelections1 };

      updatedTimeSelectionsitems[day].push({ from: '', to: '' });
      setTimeSelections(updatedTimeSelectionsitems);
      localStorage.setItem('timeslots', JSON.stringify(updatedTimeSelectionsitems));
    };

    const handleDeleteTimeSelection = (day, index) => {
      let timeSelections1 = localStorage.getItem('timeslots');
      if (timeSelections1) {
        timeSelections1 = JSON.parse(timeSelections1);
      } else {
        timeSelections1 = timeSelections;
      }
      const updatedTimeSelectionsitems = { ...timeSelections1 };

      updatedTimeSelectionsitems[day].splice(index, 1);

      setTimeSelections(updatedTimeSelectionsitems);
      localStorage.setItem('timeslots', JSON.stringify(updatedTimeSelectionsitems));
    };

    const handleApplyToAll = () => {
      const startHour = parseInt(OP_start_time.split(':')[0], 10);
      const endHour = parseInt(OP_end_time.split(':')[0], 10);

      const totalSlots = ((endHour - startHour) * 60) / timeSlotGap;
      const slots = [];

      let currentHour = startHour;
      let currentMinute = 0;

      const updatedTimeSelectionsitems = { ...timeSelections };

      for (let i = 0; i < totalSlots; i++) {
        const fromMeridiem = currentHour >= 12 ? 'PM' : 'AM';
        const fromFormattedHour = currentHour % 12 || 12;
        const fromFormattedMinute = String(currentMinute).padStart(2, '0');
        const fromFormattedTime = `${fromFormattedHour}:${fromFormattedMinute} ${fromMeridiem}`;

        currentMinute += timeSlotGap;
        if (currentMinute >= 60) {
          currentMinute = 0;
          currentHour++;
        }

        const toMeridiem = currentHour >= 12 ? 'PM' : 'AM';
        const toFormattedHour = currentHour % 12 || 12;
        const toFormattedMinute = String(currentMinute).padStart(2, '0');
        const toFormattedTime = `${toFormattedHour}:${toFormattedMinute} ${toMeridiem}`;

        slots.push({ from: fromFormattedTime, to: toFormattedTime });
      }

      updatedTimeSelectionsitems[day] = slots;
      setTimeSelections(updatedTimeSelectionsitems);
      localStorage.setItem('timeslots', JSON.stringify(updatedTimeSelectionsitems));
    };

    return (
      <>
        <div style={{ border: '1px dashed grey' }}>
          <div className="day-container" style={{ border: 'none' }}>
            <div className="day-label">{day}</div>
            {showTimeSlots && (
              <div className="time-selection-container">
                {timeSelections[day]?.map((slot, index) => (
                  <div key={index} className="time-selection">
                    <div className="time-dropdown">
                      <select
                        value={slot.from}
                        className="time-dropdown-item"
                        onChange={(e) => handleTimeChange(day, slot, 'from', e.target.value, index)}
                      >
                        <option value="">From</option>
                        {generateTimeOptions().map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                      <select
                        value={slot.to}
                        className="time-dropdown-item"
                        onChange={(e) => handleTimeChange(day, slot, 'to', e.target.value, index)}
                      >
                        <option value="">To</option>
                        {generateTimeOptions().map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                      <button className="delete-button" onClick={handleAddTimeSelection}>
                       <AddIcon />
                      </button>
                      <button 
                      className="delete-button"
                        onClick={() => handleDeleteTimeSelection(day, index)}
                      >
                      <DeleteIcon />
                      </button>
                    </div>
                  </div>
                ))}
                <button className="apply-to-all-button" onClick={handleApplyToAll}>
                  Apply to All
                </button>
              </div>
            )}
          </div>
        </div>
      </>
    );
  });

  const handleSubmitA = async () => {
    try {
      const doctor_id = doctordetails.doctor_id;
      const doctor_name = doctordetails.doctor_name;
 
      const timeSelections1 = JSON.parse(localStorage.getItem('timeslots'));
      if (Object.keys(timeSelections1).length > 0) {
        let hasvalues = false;
        Object.keys(timeSelections1).map((day) => {
          if (timeSelections1[day].length > 0) hasvalues = true;
        });
 
        if (!hasvalues) return false;
        const response = await axios.post('http://localhost:5000/api/postoptimings', {
          slotsArray: timeSelections1,
          doctor_id: doctor_id,
          doctor_name: doctor_name,
          date: selectedDate
        });
 
        console.log(response.data);
 
        localStorage.removeItem('timeslots');
        toast.success('Slots are saved successfully!', {
          position: 'top-center',
          autoClose: 2000, // Set the duration in milliseconds (e.g., 2000ms = 2 seconds)
          hideProgressBar: true, // Hide the progress bar
          closeOnClick: true, // Close the notification when clicked
          pauseOnHover: false, // Disable pausing on hover
          className: 'toast-success', // Add a custom class for styling
          style: {
            whiteSpace: 'nowrap' // Add this style to prevent line breaks
          }
        });
      } else {
        // Show an info notification with customized appearance
        toast.info('No slots to save!', {
          position: 'top-center',
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: false,
          className: 'toast-info'
        });
      }
      window.location.reload();
    } catch (error) {
      console.error('Error posting data:', error);
      alert('There is no available slots for selected date is alredy exist for insert slots.');
    }
  };

  return (
    <>
      <Modal open={isOpen} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description" style={{height:'80%'}}>
        <Box className="modal-container">
          <Button className="modal-close-button shadow2" onClick={handleClose}>
            <CloseIcon />
          </Button>
          <Grid container spacing={2} className="modal-grid-container">
  <Grid item xs={12} sm={8} className="modal-grid-item">
    <Typography id="modal-modal-title" variant="h6" component="h2" className="modal-title">
      <h1>Update Doctor OP Timings</h1>
      <h3>(Doctor ID: {doctor_id})</h3>
      <h3>(Doctor Name: {doctor_name})</h3>
      <h5>(OP StartTime: {OP_start_time})</h5>
      <h5>(OP EndTime: {OP_end_time})</h5>
    </Typography>
  </Grid>
  <Grid item xs={12} sm={4} className="modal-grid-item">
    <div>
      <Link style={{ marginLeft: 'auto', display: 'flex', textDecoration: 'none' }} href={`/Admin/Helps?doctor_id=${doctor_id}`}>
        <h2 className="shadow" style={{ boxShadow: '0 0 3px black', color: '#836FFF' }}>
          <FaCalendarAlt />
          Calender
        </h2>
      </Link>
    </div>
  </Grid>
</Grid>

          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            <div className="switch-container">
              <Switch
                checked={selectedInterval === '15'}
                onChange={handleGapChange}
                color="primary"
                inputProps={{ 'aria-label': 'toggle gap switch' }}
              />
              <span>15 min Slots</span>
              <Switch
                checked={selectedInterval === '30'}
                onChange={handleGapChange}
                color="primary"
                inputProps={{ 'aria-label': 'toggle gap switch' }}
              />
              <span>30 min Slots</span>
            </div>
            <div className="container">
            <div className="time-table-container">
              <span>
                  <FormLabel> Date : </FormLabel>
                  </span>
                  <span>
                  <TextField type="date" min={new Date().toISOString().split('T')[0]} onChange={handleDateChange} />
              </span>
              <div >
                  <h4>Select Date To Get Time Slots</h4>
              </div>
              <div style={{ width: '100%', maxWidth: '800px', margin: '0 auto' }}>
                {daysOfWeek.map((day, index) => (
                  <div key={index}>
                    <div>{showTimeSlots[day] && <Reports day={day} />}</div>
                  </div>
                ))}
              </div>
            </div>
            </div>
          </Typography>
          <div className='butdiv'>
            <Button className="modal-button shadow1" onClick={handleSubmitA}>
              Save
            </Button>
            <Button className="modal-button shadow1" onClick={handleClose}>
              Close
            </Button>
          </div>
        </Box>
      </Modal>
    </>
  );
};


const DoctorForm = () => {
  const [searchInput, setSearchInput] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [refdata, setData] = useState([]);
  const [originaldata] = useState([]);
  const [shift_start_time, setStartTime] = useState('');
  const [OP_start_time, setOPStartTime] = useState('');
  const [OP_end_time, setOPEndTime] = useState('');
  const [setSelectedDoctor] = useState(null);
  const [shift_end_time, setEndTime] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedDoctor, setEditedDoctor] = useState(null);
  const [selectedPatientDetails, setSelectedPatientDetails] = useState(null);
 
  const [isDetailsModalOpen, setDetailsModalOpen] = useState(false);
 
  const [formData, setFormData] = useState({
    registration_id: '',
    doctor_name: '',
    age: '',
    mobile: '',
    birth_date: '',
    address: '',
    city: '',
    email: '',
    remarks: '',
    filename: '',
    specialization: '',
    experience: '',
    gender: '',
    blood_group: '',
    shift_start_time: '',
    shift_end_time: '',
    OP_start_time: '',
    OP_end_time: '',
    managing_admin: ''
  });
  const [specializationOptions] = useState([
    'Cardiologist',
    'Dermatologist',
    'Endocrinologist',
    'Gastroenterologist'
    // Add more specialization options as needed
  ]);
  const [bloodGroupOptions] = useState([
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-'
  ]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/doctors/${username}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };
 
  const editPatientdetails = (patientdetails) => {
    setFormData({ ...patientdetails });
    setSelectedPatientDetails(patientdetails);
    setShowForm(true);
  };
 
  const openDetailsModal = (doctordetails) => {
    editPatientdetails();
    setSelectedPatientDetails(doctordetails);
    setDetailsModalOpen(true);
  };
 
  const closeDetailsModal = () => {
    setDetailsModalOpen(false);
  };
  const initialFormData = {
    registration_id: '',
    doctor_name: '',
    sex: '',
    age: '',
    mobile: '',
    blood_group: '',
    birth_date: '',
    address: '',
    city: '',
    email: '',
    shift_start_time: '',
    shift_end_time: '',
    OP_start_time: '',
    OP_end_time: '',
    remarks: '',
    filename: '',
    managing_admin: '',
    consultation_fee: '',
    qualification: '',
    Language: ''
  };
  const handleEdit = (doctor) => {
    setEditedDoctor(doctor);
    const formattedBirthDate = new Date(doctor.birth_date).toISOString().split('T')[0];
    setFormData({
      registration_id: doctor.registration_id,
      doctor_name: doctor.doctor_name,
      sex: doctor.sex,
      age: doctor.age,
      mobile: doctor.mobile,
      blood_group: doctor.blood_group,
      birth_date: formattedBirthDate,
      address: doctor.address,
      city: doctor.city,
      email: doctor.email,
      shift_start_time: doctor.shift_start_time,
      shift_end_time: doctor.shift_end_time,
      OP_start_time: doctor.OP_start_time,
      OP_end_time: doctor.OP_end_time,
      remarks: doctor.remarks,
      specialization: doctor.specialization,
      experience: doctor.experience,
      gender: doctor.gender,
      managing_admin: doctor.managing_admin,
      consultation_fee: doctor.consultation_fee,
      qualification: doctor.qualification,
      Language:doctor.Language

    });
    setIsEditing(true);
    setShowForm(true);
  };

  
  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });
 
  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    // Validation logic
    let error = '';
    if (name === 'mobile') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'email') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the date_of_birth is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age,
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error,
    });
  };


 
  const handleStartTimeChange = (event) => {
    setStartTime(event.target.value);
    setFormData({
      ...formData,
      shift_start_time: event.target.value
    });
  };
 
  const handleEndTimeChange = (event) => {
    setEndTime(event.target.value);
    setFormData({
      ...formData,
      shift_end_time: event.target.value
    });
  };
  const handleOPStartTimeChange = (event) => {
    setOPStartTime(event.target.value);
    setFormData({
      ...formData,
      OP_start_time: event.target.value
    });
  };
 
  const handleOPEndTimeChange = (event) => {
    setOPEndTime(event.target.value);
    setFormData({
      ...formData,
      OP_end_time: event.target.value
    });
  };
 
  const handleUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const fileData = new FormData();
      fileData.append('filename', file);
 
      try {
        const response = axios.post('http://localhost:5000/upload-image', fileData);
        if (response.status === 201) {
          console.log('Image uploaded successfully');
          fetchImages();
          alert('Image uploaded successfully');
          window.location.reload();
        } else {
          console.error('Unexpected response:', response);
        }
      } catch (error) {
        console.error('Error uploading image:', error);
      }
    } else {
      console.error('No file selected for upload.');
    }
  };
 
  const handleRemovePhoto = () => {
    const newInput = document.createElement('input');
    newInput.type = 'file';
    newInput.name = 'filename';
    newInput.accept = 'image/*';
     const currentInput = document.querySelector('input[name="filename"]');
    currentInput.parentNode.replaceChild(newInput, currentInput);
     setFormData({
      ...formData,
      filename: null
    });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    const reqbody = { ...formData, filename: formData.filename ? formData.filename.name : '' };
 
    try {
      if (isEditing) {
        await axios.put(`http://localhost:5000/api/update/${editedDoctor.doctor_id}`, reqbody);
        console.log('Doctor data updated:', reqbody);
      } else {
        await axios.post('http://localhost:5000/api/post', reqbody);
        console.log('Doctor data submitted:', reqbody);
      }
 
      setIsEditing(false);
      setEditedDoctor(null);
      setFormData(initialFormData); // Reset form data
      loadData();
      handleCloseForm();
    } catch (error) {
      console.error('Error updating/submitting doctor data:', error);
    }
  };
 
  const deleteContact = (doctor_id) => {
    if (window.confirm('Are you sure that you wanted to delete that contact?')) {
      axios.delete(`http://localhost:5000/api/remove/${doctor_id}`); // Updated to /api/remove
      toast.success('Contact Deleted Successfully');
    }
    setTimeout(() => {
      loadData();
    }, 500);
  };
 
  const handleCloseForm = () => {
    setShowForm(false);
    setSelectedDoctor(null);
    setFormData({
      registration_id: '',
      doctor_name: '',
      sex: '',
      age: '',
      mobile: '',
      blood_group: '',
      birth_date: '',
      address: '',
      city: '',
      email: '',
      shift_start_time,
      shift_end_time,
      OP_start_time,
      OP_end_time,
      remarks: '',
      managing_admin: '',
      consultation_fee: '',
      qualification: '',
      Language:''
    });
  };
 
  useEffect(() => {
    const timer = setTimeout(() => {
    }, 300); 
 
    return () => {
      clearTimeout(timer);
    };
  }, [searchInput]);
 
  const handleSearch = () => {
    if (searchInput.trim() == '' || searchInput == null) {
      setData(originaldata);
      return false;
    }
    setData(
      refdata.filter((item) => {
        const lowerCaseSearchInput = searchInput.toLowerCase();
        const lowerCaseFullName = item.doctor_name.toLowerCase();
        const lowerCaseRegistrationId = item.registration_id.toLowerCase();
        const lowerCaseSpecialization = item.specialization.toLowerCase();
 
        return (
          lowerCaseFullName.includes(lowerCaseSearchInput) ||
          lowerCaseRegistrationId.includes(lowerCaseSearchInput) ||
          lowerCaseSpecialization.includes(lowerCaseSearchInput)
        );
      })
    );
  };
 
  return (
    <>
         {refdata.length === 0 ? (
        <Typography variant="h6" align="center" mt={4}>
          No data available
        </Typography>
      ) : (
      <>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={1} mb={8} style={{ backgroundColor: '#4edcd8' }}>
        <Breadcrumbs aria-label="breadcrumb">
          <Link color="inherit" underline="hover" href="/free">
            {<HomeIcon />}
          </Link>
          <Link color="inherit" underline="hover" href="/free">
            Home
          </Link>
          <Link color="inherit" underline="hover" href="/utils">
            Utilities
          </Link>
          <Typography color="textPrimary">Add Doctor</Typography>
        </Breadcrumbs>
      </Stack>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={1} mb={1}>
        <Button
          variant="contained"
          justifyContent="flex-end"
          startIcon={<PersonAddAlt1Icon />}
          sx={{ ml: 'auto' }}
          onClick={() => setShowForm(true)}
        >
          Add Doctor
        </Button>
      </Stack>
      {showForm && (
        <Stack direction="column" spacing={2} position="relative" mb={2}>
          <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white', width: '80%', maxWidth: '800px', margin: '0 auto' }} onSubmit={handleSubmit}>
            <IconButton color="primary" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
              <CloseIcon />
            </IconButton>
            <h1 style={{ justifyContent: 'center', textAlign: 'center' }}>{isEditing ? 'Update Doctor Details' : 'Add Doctor'}</h1>
            <Box display="flex" flexDirection="column" mt={2} ml={2} mr={2}>
              <h2>Basic Details</h2>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <input
                    label="RegistrationID"
                    name="registration_id"
                    value={formData.registration_id}
                    onChange={handleChange}
                    placeholder='RegistrationID'
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Full Name" placeholder='Full Name' name="doctor_name" value={formData.doctor_name} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Mobile" placeholder='Mobile' name="mobile" value={formData.mobile} onChange={handleChange} />
                  {errors.mobile && <span style={{ color: 'red' }}>{errors.mobile}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                    <select
                      id="specialization"
                      name="specialization"
                      value={formData.specialization}
                      onChange={handleChange}
                      label="Specialization"
                      style={{width:'100%', height:'39px', marginTop:'2px'}}

                    >
                      <option value="">specialization</option>
                      {specializationOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Experience" placeholder='Experience' name="experience" value={formData.experience} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Email" placeholder='Email' name="email" value={formData.email} onChange={handleChange}  />
                  {errors.email && <span style={{ color: 'red' }}>{errors.email}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="consultation fee"placeholder='Consultation Fee' name="consultation_fee" value={formData.consultation_fee} onChange={handleChange}  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Qualification" placeholder='Qualification' name="qualification" value={formData.qualification} onChange={handleChange}  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Language" placeholder='Language' name="Language" value={formData.Language} onChange={handleChange}  />
                </Grid>
              </Grid>
              <h2>Personal Details</h2>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                    <select id="gender" name="gender" value={formData.gender} onChange={handleChange} label="Gender" style={{width:'100%', height:'39px', marginTop:'2px'}}>
                    <option value="">Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                </Grid>
                <Grid item xs={12} sm={4}>
                    <select
                      id="blood-group"
                      name="blood_group"
                      value={formData.blood_group}
                      onChange={handleChange}
                      label="Blood Group"
                      style={{width:'100%', height:'39px', marginTop:'2px'}}
                    >
                      <option value= " " >Blood Group</option>
                      {bloodGroupOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="City" placeholder='City' name="city" value={formData.city} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Address" placeholder='Address' name="address" value={formData.address} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Hospital name" placeholder='Hospital name' name="managing_admin" value={formData.managing_admin} onChange={handleChange} />
                </Grid>
              </Grid>
              <h2>Additional Details</h2>
              <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <label className='lcolor'>
                  DOB
                  <input
                    label="DOB"
                    type="date"
                    name="birth_date"
                    value={formData.birth_date}
                    onChange={handleChange}
                    placeholder='birth date'
                  />
                  </label>
                </Grid>
                <Grid item xs={12} sm={4}>
                <label className='lcolor'>
                  OP Starting Time
                  <input
                    label="Shift Starting Time"
                    type="time"
                    placeholder="Shift Starting Time"
                    name="shift_start_time"
                    value={formData.shift_start_time}
                    onChange={handleStartTimeChange}
                  />
                 </label>
                </Grid>
                <Grid item xs={12} sm={4}>
                <label className ='lcolor'>
                Shift Ending Time
                    <input
                    label="Shift Ending Time"
                    type="time"
                    name="shift_end_time"
                    value={formData.shift_end_time}
                    onChange={handleEndTimeChange}
                    placeholder='Shift Ending Time'
                  />
                  </label>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <label className='lcolor'>
                    Age
                  <input label="Age" placeholder='Age' name="age" value={formData.age} onChange={handleChange}  />
                  </label>
                </Grid>
                <Grid item xs={12} sm={4}>
                <label className='lcolor'>
                OP Starting Time 
                <input
                    label="OP Starting Time"
                    type="time"
                    placeholder="OP Starting Time"
                    name="OP_start_time"
                    value={formData.OP_start_time}
                    onChange={handleOPStartTimeChange}
                  />
                  </label>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <label className='lcolor'>
                  OP Ending Time
                  <input
                    label="OP Ending Time"
                    type="time"
                    name="OP_end_time"
                    value={formData.OP_end_time}
                    onChange={handleOPEndTimeChange}
                    placeholder='OP Ending Time'
                  />
                  </label>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <label className='lcolor'>
                   Remarks
                  <input label="Remarks" placeholder='Remarks' name="remarks" value={formData.remarks} onChange={handleChange} />
                  </label>
                </Grid>
              </Grid>
              <h2>Upload Photo</h2>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={6} sm={4}>
                  <input
                    type="file"
                    name="filename"
                    onChange={(e) => {
                      handleUpload(e), handleChange(e);
                    }}
                    accept="uploads/*"
                  />
                </Grid>
                <Grid item xs={6} sm={4}>
                  {formData.filename && (
                    <Box display="flex" alignItems="center">
                      <img
                        src={URL.createObjectURL(formData.filename)}
                        alt="Doctor"
                        style={{ width: '50px', height: '50px', borderRadius: '10%', marginRight: '8px' }}
                      />
                      <Button variant="outlined" color="error" onClick={handleRemovePhoto}>
                        Remove
                      </Button>
                    </Box>
                  )}
                </Grid>
              </Grid>
 
              <Box display="flex" justifyContent="space-between">
                <Button variant="contained" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto', height: '32px', mt: '8px' }} type="submit">
                  {isEditing ? 'Update Doctor' : 'Add Doctor'}
                </Button>
              </Box>
            </Box>
          </form>
        </Stack>
      )}
 
      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center' }} mt={1} mb={1}>
        <Grid item xs={4}>
          <TextField
            label="Search Doctors"
            placeholder="Search by Name, Mobile, etc."
            variant="outlined"
            fullWidth
            margin="normal"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            InputProps={{
              endAdornment: (
                <IconButton
                  onClick={() => {
                    handleSearch();
                  }}
                  edge="end"
                >
                  <SearchIcon />
                </IconButton>
              )
            }}
          />
        </Grid>
      </Grid>
      <table className="adminstyled-table">
        <thead>
          <tr>
            <th>Id.</th>
            <th>Profile</th>
            <th>Registration-Id</th>
            <th>doctor_name</th>
            <th>Mobile</th>
            <th>Specialization</th>
            <th>Experience</th>
            <th>Email</th>
            {/* <th>Sex</th> */}
            <th>OpTime</th>
            <th>Gender</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {refdata.map((item, index) => {
            return (
              <tr key={item.doctor_id}>
                <th scope="row">{index + 1}</th>
                <td>
                  <img
                    src={`http://localhost:5000/api/get-image/${item.doctor_id}`}
                    alt={`Profile of ${item.doctor_name}`}
                    style={{ width: '50px', height: '50px', borderRadius: '50%' }}
                    className="image-zoom"
                  />
                </td>
                <td>{item.registration_id}</td>
                <td>{item.doctor_name}</td>
                <td>{item.mobile}</td>
                {/* <td>{item.experience_years}</td> */}
                <td>{item.specialization}</td>
                <td>{item.experience}</td>
                <td style={{ wordBreak: 'break-all' }}>{item.email}</td>
                <td>
                  {item.OP_start_time} - {item.OP_end_time}
                </td>
                <td>{item.gender}</td>
                <td>
                  <button className="adminbtn btn-edit" onClick={() => handleEdit(item)}>
                    <EditIcon /> {/* Use the DeleteIcon component here */}
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => deleteContact(item.doctor_id)}>
                    <DeleteIcon /> {/* Use the DeleteIcon component here */}
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => openDetailsModal(item)}>
                    <MoreHorizIcon />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {selectedPatientDetails && (
        <AppointmentDetails
          isOpen={isDetailsModalOpen}
          handleClose={closeDetailsModal}
          doctordetails={selectedPatientDetails}
          onPatientDetailsChange={setSelectedPatientDetails}
        />
      )}
    </>
      )}
      </>
  );
};

export default DoctorForm;