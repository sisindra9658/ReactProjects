
import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
import './Home.css';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import Typography from '@mui/material/Typography';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';
import { FormControl } from '@mui/material';
 
const ReceptionistForm = () => {
  const [data, setData] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedReceptionist, setSelectedReceptionist] = useState(null);
  const [searchInput, setSearchInput] = useState('');
  const [formData, setFormData] = useState({
    fullname: '',
    shift: '',
    languagesspoken: '',
    email: '',
    address: '',
    contact: '',
    bloodgroup: '',
    activestatus: '',
    managing_admin: ''
  });
 

  const [bloodGroupOptions] = useState([
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
    // Add more blood group options as needed
  ]);
  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    // Validation logic
    let error = '';
    if (name === 'contact') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'email') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the birth_date is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error
    });
  };
 
  const editreceptionist = (receptionist) => {
    // Set the form data to the selected pharmacist for editing
    setFormData({ ...receptionist });
    // Set the selected pharmacist
    setSelectedReceptionist(receptionist);
    // Show the form for editing
    setShowForm(true);
  };



  // const handleRemovePhoto = () => {
  //   // Create a new input element
  //   const newInput = document.createElement('input');
  //   newInput.type = 'file';
  //   newInput.name = 'photo';
  //   newInput.accept = 'image/*';
 
  //   // Replace the existing input element with the new one
  //   const currentInput = document.querySelector('input[name="photo"]');
  //   currentInput.parentNode.replaceChild(newInput, currentInput);
 
  //   // Reset the form data, including photo and its URL
  //   setFormData({
  //     ...formData,
  //     photo: null,
  //     photoName: '' // Assuming there's a state for storing the photo name or URL
  //   });
  // };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    try {
      if (selectedReceptionist) {
        // If a patient is selected, update the patient
        await axios.put(`http://localhost:5000/api/updatereceptionist/${selectedReceptionist.employeeid}`, formData);
        toast.success('receptionist updated successfully');
      } else {
        // If no patient is selected, add a new patient
        await axios.post('http://localhost:5000/api/postreceptionist', formData);
        toast.success('receptionist added successfully');
      }
      // Reset the form after submission
      setFormData({
        fullname: '',
        shift: '',
        languagesspoken: '',
        email: '',
        address: '',
        contact: '',
        bloodgroup: '',
        activestatus: '',
        managing_admin: ''
      });
 
      setSelectedReceptionist(null);

    // Reload data from the server to update the table
    loadData();
    setShowForm(false);
  } catch (error) {
    console.error('Error submitting receptionist data:', error);
  }
};

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/receptionist/${username}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };
 
  const deleteContact = (employeeid) => {
    if (window.confirm('Are you sure that you want to delete that contact?')) {
      axios.delete(`http://localhost:5000/api/remove3/${employeeid}`)
        .then(() => {
          toast.success('Contact Deleted Successfully');
        })
        .catch((error) => {
          console.error('Error deleting contact:', error);
        });
    }
 
    setTimeout(() => {
      loadData();
    }, 500);
  };
 
  const handleSearch = () => {
    setData(
      data.filter((item) => {
        const lowerCaseSearchInput = searchInput.toLowerCase();
        const lowerCaseFullName = item.fullname.toLowerCase();
        const lowerCaseMobile = item.contact.toLowerCase();
        const lowerCaseShift = item.shift.toLowerCase();
 
        return (
          lowerCaseFullName.includes(lowerCaseSearchInput) ||
          lowerCaseMobile.includes(lowerCaseSearchInput) ||
          lowerCaseShift.includes(lowerCaseSearchInput)
        );
      })
    );
  };

 
  return (
    <>
        {data.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8} style={{ backgroundColor: '#4edcd8' }}>
        <Breadcrumbs aria-label="breadcrumb">
          <Link color="inherit" underline="hover" href="/free">{<HomeIcon />}</Link>
          <Link color="inherit" underline="hover" href="/free">
            Home
          </Link>
          <Link color="inherit" underline="hover" href="/utils">
            Utilities
          </Link>
          <Typography color="textPrimary">Add Receptionist</Typography>
        </Breadcrumbs>
      </Stack>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8}>
        <Button variant="contained" justifyContent="flex-end" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto' }} onClick={() => setShowForm(true)}>
          Add Receptionist
        </Button>
      </Stack>
 
      {showForm && (
        <Stack direction="column" spacing={2} position="relative" mb={2}>
        <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white', width: '80%', maxWidth: '800px', margin: '0 auto' }} onSubmit={handleSubmit}>            <IconButton color="primary" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
              <CloseIcon />
            </IconButton>
            <h1 style={{ justifyContent: 'center', textAlign: 'center' }}>{selectedReceptionist ? 'Update Receptionist Details' : 'Add Receptionist'}</h1>
            <Box display="flex" flexDirection="column" mt={2} ml={2} mr={2}>
              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                  <input label="Full Name" placeholder="Full Name" name="fullname" value={formData.fullname} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
        <select
          id="shift"
          name="shift"
          value={formData.shift}
          onChange={handleChange}
          label="shift"
          style={{width:'100%', height:'39px', marginTop:'2px'}}
        >
          <option value="">Shift</option>
          <option value="Day Shift">Day shift</option>
          <option value="Evening Shift">Morning shift</option>
          <option value="Night Shift">Night shift</option>
        </select>
      </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Languages Spoken" placeholder="Languages Spoken" name="languagesspoken" value={formData.languagesspoken} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} />
                  {errors.email && <span style={{ color: 'red' }}>{errors.email}</span>} 
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Address" name="address" placeholder="Address" value={formData.address} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Contact" name="contact" placeholder="Contact" value={formData.contact} onChange={handleChange} />
                  {errors.contact && <span style={{ color: 'red' }}>{errors.contact}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
                  <select
                    id="bloodgroup"
                    name="bloodgroup"
                    value={formData.bloodgroup}
                    onChange={handleChange}
                    label="Blood Group"
                    style={{width:'100%', height:'39px', marginTop:'2px'}}
                  >
                    <option value="">Blood Group</option>
                    {bloodGroupOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
        <select
          id="activestatus"
          name="activestatus"
          value={formData.activestatus}
          onChange={handleChange}
          label="Status"
          style={{width:'100%', height:'39px', marginTop:'2px'}}
        >
          <option value="">Status</option>
          <option value="Active">Active</option>
          <option value="InActive">InActive</option>
        
        </select>
      </FormControl>
                </Grid>
        <Grid item xs={12} sm={4}>
       <input label="Hospital Name" name="managing_admin" placeholder="Hospital Name" value={formData.managing_admin} onChange={handleChange} />
       </Grid>
              </Grid>
 
              {/* <h2>Upload Photo</h2>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={6} sm={3}>
                  <input type="file" name="photo" onChange={handleChange} accept="image/*" />
                </Grid>
                <Grid item xs={6} sm={3}>
                  {formData.photo && (
                    <Box display="flex" alignItems="center">
                      <img
                        src={URL.createObjectURL(formData.photo)}
                        alt="Receptionist"
                        style={{ width: '50px', height: '50px', borderRadius: '10%', marginRight: '8px' }}
                      />
                      <Button variant="outlined" color="error" onClick={handleRemovePhoto}>
                        Remove
                      </Button>
                    </Box>
                  )}
                </Grid>
              </Grid> */}
 
              <Box display="flex" justifyContent="space-between">
                <Button variant="contained" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto', height: '32px', mt: '8px', mb: '20px' }} type="submit">
                {selectedReceptionist ? 'Update Receptionist' : 'Add Receptionist'}
                </Button>
              </Box>
            </Box>
          </form>
        </Stack>
      )}
 
      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center' }} mt={1} mb={1}>
        <Grid item xs={4}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input
            label="Search receptionist"
            placeholder="Search by Name, Mobile, etc."
            style={{ width: '50%', height: '39px', marginTop: '2px' }}
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            />
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
           
          </div>
        </Grid>
      </Grid>
      <table className="adminstyled-table">
        <thead>
          <tr>
            <th>Id.</th>
            <th>Full Name</th>
            <th>Shift</th>
            <th>Languages Spoken</th>
            <th>Email</th>
            <th>Address</th>
            <th>Contact</th>
            <th>Blood Group</th>
            <th>Active Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => {
            return (
              <tr key={item.employeeid}>
                <th scope="row">{index + 1}</th>
                <td>{item.fullname}</td>
                <td>{item.shift}</td>
                <td>{item.languagesspoken}</td>
                <td  style={{ wordBreak: 'break-all' }}>{item.email}</td>
                <td  style={{ wordBreak: 'break-all' }}>{item.address}</td>
                <td>{item.contact}</td>
                <td>{item.bloodgroup}</td>
                <td>{item.activestatus}</td>
                <td>
                  <button className="adminbtn btn-edit" onClick={() => editreceptionist(item)}>
                    <EditIcon />
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => deleteContact(item.employeeid)}>
                    <DeleteIcon />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
    )}
    </>
  );
};
 
export default ReceptionistForm;
 