import * as React from 'react';
import dayjs from 'dayjs';
// eslint-disable-next-line no-restricted-imports
import { DemoContainer, DemoItem } from '@mui/x-date-pickers/internals/demo';
 
// import { DemoContainer, DemoItem } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import axios from 'axios';
// import { useParams } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import queryString from 'query-string';
 
export default function DoctorTimingsCalendar() {
  // const { doctor_id } = useParams();
  const location = useLocation();
  const { doctor_id } = queryString.parse(location.search);
 
  //  const { doctor_name} = queryString.parse(location.search);
 
  const [value, setValue] = React.useState(dayjs());
 
  const [doctorTimings, setDoctorTimings] = React.useState([]);
 
  const fetchDoctorTimings = async () => {
    try {
      const dayName = value.format('dddd');
      const date = value.format('YYYY-MM-DD');
      const response = await axios.get(`http://localhost:5000/api/get/doctortimings/${doctor_id}/${dayName}/${date}`);
      console.log(response);
 
      setDoctorTimings(response.data);
    } catch (error) {
      console.error('Error fetching doctor timings:', error);
    }
  };
  React.useEffect(() => {
    fetchDoctorTimings();
  }, [doctor_id]);
 
  const deleteTiming = async (id) => {
    const confirmed = window.confirm('Are you sure you want to delete this timing?');
    if (!confirmed) {
      return;
    }
    try {
      const date = value.format('YYYY-MM-DD');
      await axios.delete(`http://localhost:5000/api/delete/doctortiming/${id}/${date}`);
      setDoctorTimings((prevTimings) => prevTimings.filter((timing) => timing.id !== id));
 
      alert('Timing slot successfully deleted.');
    } catch (error) {
      console.error('Error deleting doctor timing:', error);
    }
  };
 
  // const deleteAllTimings = async () => {
  //   const dayName = value.format('dddd');
  //   const confirmed = window.confirm(`Are you sure you want to delete all timings for ${dayName}?`);
  //   if (!confirmed) {
  //     return;
  //   }
  //   try {
  //     await axios.delete(`http://localhost:5000/api/delete/doctortiming/day/${dayName}/${doctor_id}`);
  //     setDoctorTimings((prevTimings) => prevTimings.filter((timing) => timing.days !== dayName));
  //     alert("All timings for the day have been successfully deleted.");
  //   } catch (error) {
  //     console.error('Error deleting doctor timings for the day:', error);
  //   }
  // };
 
  const deleteWeekdayTimings = async () => {
    const date = value.format('YYYY-MM-DD');
    const confirmed = window.confirm(`Are you sure you want to delete all timings for ${date}?`);
    if (!confirmed) {
      return;
    }
    try {
      const updatedTimings = doctorTimings.filter(() => {
       
        return ;
      });
      const date = value.format('YYYY-MM-DD');
      await axios.delete(`http://localhost:5000/api/deleteall/doctortiming/${doctor_id}/${date}`);
      setDoctorTimings(updatedTimings);
      alert(`All timings for ${date} have been successfully deleted.`);
    } catch (error) {
      console.error('Error deleting doctor timings for the day:', error);
    }
  };
 
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', width: '1000px' }}>
      <div style={{ paddingTop: '50px' }}>
        <div style={{ flex: '1', border: '1px dashed black', paddingTop: '20px', marginLeft: '10px' }}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={['DateCalendar', 'DateCalendar']}>
              <DemoItem label="Doctor Timings">
                <DateCalendar
                  value={value}
                  onChange={(newValue) => {
                    setValue(newValue);
                    fetchDoctorTimings();
                  }}
                />
              </DemoItem>
            </DemoContainer>
          </LocalizationProvider>
        </div>
      </div>
 
      <div style={{ flex: '1', marginLeft: '20px' }}>
        <h3>Doctor Timings</h3>
        <button style={{ marginLeft: '530px', marginBottom: '30px' }} onClick={() => deleteWeekdayTimings()}>
          Delete All
        </button>
        {doctorTimings.length === 0 ? (
          <p>No slots available for {value.format('dddd')}</p>
        ) : (
          <table style={{ borderCollapse: 'collapse', border: '1px solid black', width: '100%' }}>
            <thead>
              <tr>
                <th style={{ border: '1px solid black', padding: '8px' }}>Date</th>
                <th style={{ border: '1px solid black', padding: '8px' }}>Day</th>
                <th style={{ border: '1px solid black', padding: '8px' }}>From Time</th>
                <th style={{ border: '1px solid black', padding: '8px' }}>To Time</th>
                <th style={{ border: '1px solid black', padding: '8px' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {doctorTimings
                .sort((a, b) => {
                  const timeA = dayjs(a.from_time, 'h:mm A').toDate();
                  const timeB = dayjs(b.from_time, 'h:mm A').toDate();
                  return timeA - timeB;
                })
                .map((timing) => (
                  <tr key={timing.id}>
                    {/* <td style={{ border: '1px solid black', padding: '8px', textAlign: 'center' }}>{timing.date}</td> */}
                    <td style={{ border: '1px solid black', padding: '8px', textAlign: 'center' }}>
                      {dayjs(timing.date).add(0, 'day').format('YYYY-MM-DD')}
                    </td>
                    <td style={{ border: '1px solid black', padding: '8px', textAlign: 'center' }}>{timing.days}</td>
                    <td style={{ border: '1px solid black', padding: '8px', textAlign: 'center' }}>
                      {dayjs(timing.from_time, 'h:mm A').format('h:mm A')}
                    </td>
                    <td style={{ border: '1px solid black', padding: '8px', textAlign: 'center' }}>
                      {dayjs(timing.to_time, 'h:mm A').format('h:mm A')}
                    </td>
                    <td style={{ border: '1px solid black', padding: '8px', textAlign: 'center' }}>
                      <button onClick={() => deleteTiming(timing.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
 