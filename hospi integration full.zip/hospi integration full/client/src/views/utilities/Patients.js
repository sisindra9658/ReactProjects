import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
import './Home.css';

import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import Typography from '@mui/material/Typography';
// import CircularProgress from '@mui/material/CircularProgress';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';
import { format } from 'date-fns';

const DoctorForm = () => {
  const [data, setData] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    mobile: '',
    email: '',
    gender: '',
    date_of_birth: '',
    age: '',
    city: '',
    address: '',
    blood_group: '',
    remarks: '',
    managing_admin: ''
  });
  const [selectedPatient, setSelectedPatient] = useState(null);

  // const handleChange = (e) => {
  //   const { name, value, type, files } = e.target;
   
  //   // Update age if the birth_date is changed
  //   if (name === 'date_of_birth') {
  //     const currentDate = new Date();
  //     const birthDate = new Date(value);
  //     const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
  //     setFormData({
  //       ...formData,
  //       [name]: value,
  //       age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
  //     });
  //   } else {
  //     // For other fields, update as usual
  //     setFormData({
  //       ...formData,
  //       [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
  //     });
  //   }
  // };

  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    // Validation logic
    let error = '';
    if (name === 'mobile') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'email') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the birth_date is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error
    });
  };



  const handleSearch = () => {
    setData(
      data.filter((item) => {
        const lowerCaseSearchInput = searchInput.toLowerCase();

        const lowerCaseFullName = item.full_name.toLowerCase();

        const lowerCaseMobile = item.mobile.toLowerCase();

        const lowerCaseCity = item.city.toLowerCase();

        return (
          lowerCaseFullName.includes(lowerCaseSearchInput) ||
          lowerCaseMobile.includes(lowerCaseSearchInput) ||
          lowerCaseCity.includes(lowerCaseSearchInput)
        );
      })
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (selectedPatient) {
        // If a patient is selected, update the patient
        await axios.put(`http://localhost:5000/api/updatepatient/${selectedPatient.patient_id}`, formData);
        toast.success('Patient updated successfully');
      } else {
        // If no patient is selected, add a new patient
        await axios.post('http://localhost:5000/api/postpatient', formData);
        toast.success('Patient added successfully');
      }

      // Reset the form and clear the selected patient
      setFormData({
        full_name: '',
        mobile: '',
        email: '',
        gender: '',
        date_of_birth: '',
        age: '',
        city: '',
        address: '',
        blood_group: '',
        remarks: '',
        managing_admin: ''
      });
      setSelectedPatient(null);

      // Reload data from the server to update the table
      loadData();
      setShowForm(false);
    } catch (error) {
      console.error('Error submitting patient data:', error);
    }
  };

  // const loadData = async () => {
  //   try {
  //     const response = await axios.get('http://localhost:5000/api/get1');
  //     const formattedData = response.data.map((item) => ({
  //       ...item,
  //       date_of_birth: new Date(item.date_of_birth).toISOString().split('T')[0]
  //     }));
  //     setData(formattedData);
  //   } catch (error) {
  //     console.error('Error loading data:', error);
  //   }
  // };

  // useEffect(() => {
  //   loadData();
  // }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/patient/${username}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };

  const deleteContact1 = async (patient_id) => {
    if (window.confirm('Are you sure that you wanted to delete that contact?')) {
      try {
        await axios.delete(`http://localhost:5000/api/remove1/${patient_id}`);
        toast.success('Contact Deleted Successfully');
      } catch (error) {
        console.error('Error deleting contact:', error);
      }
    }

    // Regardless of the delete operation result, load data after the delete attempt
    loadData();
  };

  const editPatient = (patient) => {
    // Set the form data to the selected patient for editing
    setFormData({ ...patient });
    // Set the selected patient
    setSelectedPatient(patient);
    // Show the form for editing
    setShowForm(true);
  };

  return (
    <>
        {data.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={1} mb={5} style={{ backgroundColor: '#4edcd8' }}>
        <Breadcrumbs aria-label="breadcrumb">
          <Link color="inherit" underline="hover" href="/free">
            {<HomeIcon />}
          </Link>
          <Link color="inherit" underline="hover" href="/free">
            Home
          </Link>
          <Link color="inherit" underline="hover" href="/utils">
            Utilities
          </Link>
          <Typography color="textPrimary">Add Patient</Typography>
        </Breadcrumbs>
      </Stack>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={4} mb={4}>
        <Button
          variant="contained"
          justifyContent="flex-end"
          startIcon={<PersonAddAlt1Icon />}
          sx={{ ml: 'auto' }}
          onClick={() => setShowForm(true)}
        >
          Add Patient
        </Button>
      </Stack>

      {showForm && (
        <Stack direction="column" spacing={2} position="relative" mb={2}>
        <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white', width: '80%', maxWidth: '800px', margin: '0 auto' }} onSubmit={handleSubmit}>
            <IconButton color="primary" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
              <CloseIcon />
            </IconButton>
            <h1 style={{ justifyContent: 'center', textAlign: 'center' }}>{selectedPatient ? 'Update Patient Details' : 'Add Patient'}</h1>
            <Box display="flex" flexDirection="column" mt={2} ml={2} mr={2}>
              <Grid container spacing={2} mb={3}>
                {/* <Grid item xs={12} sm={4}>
                  <TextField label="PatientID" name="patientid" value={formData.patientid} onChange={handleChange} fullWidth />
                </Grid> */}
                <Grid item xs={12} sm={4}>
                  <input label="Full Name" name="full_name" placeholder="Full Name" value={formData.full_name} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                    <input
                      type="text"
                      name="mobile"
                      placeholder="Mobile"
                      value={formData.mobile}
                      onChange={handleChange}
                    />
                  {errors.mobile && <span style={{ color: 'red' }}>{errors.mobile}</span>}
                </Grid>

                {/* <Grid item xs={12} sm={4}>
                  <input label="Mobile" name="mobile" placeholder="Mobile" value={formData.mobile} onChange={handleChange} />
                </Grid> */}
                {/* <Grid item xs={12} sm={4}>
                  <input label="Email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} />
                </Grid> */}
                      <Grid item xs={12} sm={4}>
                        <input
                          type="email"
                          name="email"
                          placeholder="Email"
                          value={formData.email}
                          onChange={handleChange}
                        />
                      {errors.email && <span style={{ color: 'red' }}>{errors.email}</span>}
                    </Grid>

                <Grid item xs={12} sm={4}>
                  <input label="Gender" name="gender" placeholder="Gender" value={formData.gender} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Age" name="age" placeholder="Age" value={formData.age} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input
                    label="date_of_birth"
                    type="date"
                    name="date_of_birth"
                    value={formData.date_of_birth}
                    onChange={handleChange}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2} mb={3}>
                <Grid item xs={12} sm={4}>
                  <input label="City" name="city" placeholder="City" value={formData.city} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Address" name="address" placeholder="Address" value={formData.address} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Blood group" name="blood_group" placeholder="Blood Group" value={formData.blood_group} onChange={handleChange} />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <input label="Remarks" name="remarks" placeholder="Remarks" value={formData.remarks} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Hospital Name" name="managing_admin" placeholder="Hospital Name" value={formData.managing_admin} onChange={handleChange} />
                </Grid>
              </Grid>

              <Box display="flex" justifyContent="space-between">
                <Button variant="contained" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto', height: '32px', mt: '8px', mb:"20px" }} type="submit">
                  {selectedPatient ? 'Update Patient' : 'Add Patient'}
                </Button>
              </Box>
            </Box>
          </form>
        </Stack>
      )}
      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center' }} mt={1} mb={1}>
        <Grid item xs={4}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input
            label="Search patient"
            placeholder="Search by Name, Mobile, etc."
            style={{ width: '50%', height: '39px', marginTop: '2px' }}
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
           />
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
         </div>
        </Grid>
      </Grid>
      <table className="adminstyled-table">
        <thead>
          <tr>
            <th>Id.</th>

            <th>FullName</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Date Of Birth</th>
            <th>Age</th>
            <th>City</th>
            <th>Address</th>
            <th>BloodGroup</th>
            <th>Remarks</th>
            {/* <th>Age</th>
                <th>Age</th> */}
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => {
            return (
              <tr key={item.patient_id}>
                <th scope="row">{index + 1}</th>
                <td>{item.full_name}</td>
                <td>{item.mobile}</td>
                <td  style={{ wordBreak: 'break-all' }}>{item.email}</td>
                <td>{item.gender}</td>
                <td>{format(new Date(item.date_of_birth), 'dd-MM-yyyy')}</td>
                <td>{item.age}</td>
                <td>{item.city}</td>
                <td>{item.address}</td>
                <td>{item.blood_group}</td>
                <td>{item.remarks}</td>
                <td>
                  <button className="adminbtn btn-edit" onClick={() => editPatient(item)}>
                    <EditIcon />
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => deleteContact1(item.patient_id)}>
                    <DeleteIcon />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
    )}
    </>
  );
};

export default DoctorForm;
