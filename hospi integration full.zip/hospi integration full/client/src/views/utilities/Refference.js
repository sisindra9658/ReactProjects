import React from 'react'

function Refference() {
  return (
    <center style={{alignItems: 'center',marginTop: '25%'}}>
        <h1>Refference</h1>
      </center>
  )
}

export default Refference