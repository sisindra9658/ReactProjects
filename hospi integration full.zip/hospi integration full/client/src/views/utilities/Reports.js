import React, { useState, useEffect } from 'react';
import './Reports.css'; // Import the CSS file
import SearchIcon from '@mui/icons-material/Search';
import IconButton from '@mui/material/IconButton';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

function Reports() {
    const [pdfList, setPdfList] = useState([]);
    const [selectedPdf, setSelectedPdf] = useState(null);
    const [pdfDetails, setPdfDetails] = useState(null);
    const [open, setOpen] = useState(false);
    const [pdfError, setPdfError] = useState(null); // State to handle PDF loading errors
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredPdfList, setFilteredPdfList] = useState([]);

    useEffect(() => {
        fetchPdfList();
    }, []);

    useEffect(() => {
        filterPdfList();
    }, [pdfList, searchQuery]);

    const fetchPdfList = async () => {
        try {
            const response = await fetch('http://localhost:5000/pdfs');
            if (!response.ok) {
                throw new Error('Failed to fetch PDF list');
            }
            const data = await response.json();
            setPdfList(data);
        } catch (error) {
            console.error('Error fetching PDF list:', error);
        }
    };

    const fetchPdfDetails = async (pdfUrl) => {
        try {
            const response = await fetch(`http://localhost:5000/pdf-details?url=${encodeURIComponent(pdfUrl)}`);
            if (!response.ok) {
                throw new Error('Failed to fetch PDF details');
            }
            const data = await response.json();
            setPdfDetails(data);
            setPdfError(null); // Reset pdfError state on successful fetch
        } catch (error) {
            console.error('Error fetching PDF details:', error);
            setPdfError('Failed to load PDF. Please try again later.');
        }
    };

    const extractPdfName = (url) => {
        const parts = url.split('/');
        return parts[parts.length - 1];
    };

    const handlePdfClick = (pdf) => {
        setSelectedPdf(pdf);
        setOpen(true);
        fetchPdfDetails(pdf.url);
    };

    const handleClose = () => {
        setOpen(false);
        setPdfDetails(null); // Reset pdfDetails when modal is closed
    };

    const handleSearch = (event) => {
        const query = event.target.value.toLowerCase();
        setSearchQuery(query); // Update the search query state
    };

    const filterPdfList = () => {
        if (!searchQuery) {
            setFilteredPdfList(pdfList);
            return;
        }
        const filteredPdf = pdfList.filter((pdf) =>
            extractPdfName(pdf.url).toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredPdfList(filteredPdf);
    };

    return (
        <>
        {filteredPdfList.length === 0 ? (
            <Typography variant="h6" align="center" mt={4}>
              No data available
            </Typography>
          ) : (
        
        <div>
            <h1>Reports</h1>
            <div>
                <input 
                    type="text" 
                    placeholder="Search PDFs" 
                    value={searchQuery} 
                    onChange={handleSearch} 
                    style={{maxWidth:"300px", width:'60%'}}
                />
                <IconButton onClick={handleSearch} edge="end">
                    <SearchIcon />
                </IconButton>
            </div>
            <table className="adminpdf-table">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>PDF</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredPdfList.map((pdf, index) => (
                        <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{extractPdfName(pdf.url)}</td>
                            <td>
                                <button onClick={() => handlePdfClick(pdf)}>View PDF</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 500, height: 600, bgcolor: 'background.paper', border: '3px solid #000', p: 4, }}>
                    <div className='admina1'>
                        <Typography id="modal-modal-title" variant="h6" component="h2">
                            {/* PDF Viewer */}
                        </Typography>
                        {pdfError && <p>{pdfError}</p>} {/* Display PDF loading error */}
                        {pdfDetails && (
                            <div>
                                <div style={{ textAlign: 'center' }}>
                                    <p style={{ fontWeight: 'bold', textDecoration: 'underline' }}>PDF Details:</p>
                                </div>
                                <table style={{ width: '100%' }}>
                                    <tbody className='admina2'>
                                        {Object.entries(pdfDetails).map(([key, value]) => (
                                            <tr key={key}>
                                                <td style={{ paddingRight: '40px', fontWeight: 'bold' }}>{key.trim()}:</td>
                                                <td style={{ textAlign: 'left' }}>{value.trim()}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}

                        <div src={selectedPdf} type="application/pdf"/>
                    </div>
                    <Button onClick={handleClose} style={{ backgroundColor: 'blue', color: 'white', borderRadius: '4px', padding: '8px 16px', border: 'none', cursor: 'pointer', marginLeft: '80%', marginTop: '20px' }}>Close</Button>

                </Box>

            </Modal>

        </div>
          )}
          </>
    );

}

export default Reports;
