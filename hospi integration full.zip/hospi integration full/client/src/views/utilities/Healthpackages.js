import React from 'react'

function Healthpackages() {
  return (
    <div>
      Healthpackages
    </div>
  )
}

export default Healthpackages
