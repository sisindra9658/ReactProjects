import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
import './Home.css';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import Typography from '@mui/material/Typography';
// import CircularProgress from '@mui/material/CircularProgress';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';
import { FormControl } from '@mui/material';
import { useState, useEffect } from 'react';


const DoctorForm = () => {
  const [searchInput, setSearchInput] = useState('');
  const [data, setData] = useState([]);
  const [selectedNurse, setSelectedNurse] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    fullname: '',
    shift: '',
    contactnumber: '',
    emailaddress: '',
    experience: '',
    address: '',
    qualification: '',
    bloodgroup: '',
    activestatus: '',
    managing_admin :''
  });

  const [bloodGroupOptions] = useState([
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
    // Add more blood group options as needed
  ]);

  const editnurse = (nurse) => {
    // Set the form data to the selected patient for editing
    setFormData({ ...nurse });
    // Set the selected patient
    setSelectedNurse(nurse);
    // Show the form for editing
    setShowForm(true);
  };

  const [errors, setErrors] = useState({
    mobile: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    // Validation logic
    let error = '';
    if (name === 'contactnumber') {
      const mobilePattern = /^[0-9]{10}$/; // Assuming 10 digits for the mobile number
      if (!mobilePattern.test(value)) {
        error = 'Please enter a valid 10-digit mobile number.';
      }
    } else if (name === 'emailaddress') {
      const emailPattern = /^[^\s@]+@gmail\.com$/; // Enforce gmail.com domain
      if (!emailPattern.test(value)) {
        error = 'Please enter a valid email address.';
      }
    }

    // Update age if the birth_date is changed
    if (name === 'date_of_birth') {
      const currentDate = new Date();
      const birthDate = new Date(value);
      const age = Math.floor((currentDate - birthDate) / (365.25 * 24 * 60 * 60 * 1000));
      setFormData({
        ...formData,
        [name]: value,
        age: isNaN(age) ? '' : age, // Set age or an empty string if it's NaN
      });
    } else {
      // For other fields, update as usual
      setFormData({
        ...formData,
        [name]: type === 'file' ? (files.length > 0 ? files[0] : null) : value,
      });
    }

    // Update validation errors state
    setErrors({
      ...errors,
      [name]: error
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (selectedNurse) {
        // If a patient is selected, update the patient
        await axios.put(`http://localhost:5000/api/updatenurse/${selectedNurse.employeeid}`, formData);
        toast.success('nurse updated successfully');
      } else {
        // If no patient is selected, add a new patient
        await axios.post('http://localhost:5000/api/postnurse', formData);
        toast.success('nurse added successfully');
      }

      // Reset the form and clear the selected patient
      setFormData({
        
        fullname: '',
        shift: '',
        contactnumber: '',
        emailaddress:'',
        experience: '',
        address: '',
        qualification: '',
        bloodgroup: '',
        activestatus: '',
        managing_admin: ''
      });
      setSelectedNurse(null);

      // Reload data from the server to update the table
      loadData();
      setShowForm(false);
    } catch (error) {
      console.error('Error submitting nurse data:', error);
    }
  };
  // const loadData = async () => {
  //   const response = await axios.get('http://localhost:5000/api/get/nurse');
  //   setData(response.data);
  // };

  // useEffect(() => {
  //   loadData();
  // }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const username = localStorage.getItem('username'); 
      const response = await axios.get(`http://localhost:5000/api/hospital-details/nurse/${username}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching managing admin details:', error);
    }
  };


  const deleteContact2 = (employeeid) => {
    if (window.confirm('Are you sure that you wanted to delete that contact?')) {
      axios
        .delete(`http://localhost:5000/api/remove2/${employeeid}`)
        .then(() => {
          toast.success('Contact Deleted Successfully');
        })
        .catch((error) => {
          console.error('Error deleting contact:', error);
        });
    }

    setTimeout(() => {
      loadData();
    }, 500);
  };
  const handleSearch = () => {
    setData(
      data.filter((item) => {
        const lowerCaseSearchInput = searchInput.toLowerCase();
        const lowerCasefullname = item.fullname.toLowerCase();
        const lowerCaseMobile = item.contactnumber.toLowerCase();
        const lowerCaseCity = item.address.toLowerCase();
        const lowerCaseEmail = item.emailaddress.toLowerCase();
        const lowerCaseBloodGroup = item.bloodgroup.toLowerCase();
        // const lowerCaseExperience = item.experience.toLowerCase();
        const lowerCaseQualification = item.qualification.toLowerCase();
        const lowerCaseActiveStatus = item.activestatus.toLowerCase();

        return (
          lowerCasefullname.includes(lowerCaseSearchInput) ||
          lowerCaseMobile.includes(lowerCaseSearchInput) ||
          lowerCaseCity.includes(lowerCaseSearchInput) ||
          lowerCaseEmail.includes(lowerCaseSearchInput) ||
          lowerCaseBloodGroup.includes(lowerCaseSearchInput) ||
          // lowerCaseExperience.includes(lowerCaseSearchInput) ||
          lowerCaseQualification.includes(lowerCaseSearchInput) ||
          lowerCaseActiveStatus.includes(lowerCaseSearchInput)
        );
      })
    );
  };

  return (
    <>
    {data.length === 0 ? (
      <Typography variant="h6" align="center" mt={4}>
        No data available
      </Typography>
    ) : (
    <>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8} style={{ backgroundColor: '#4edcd8' }}>
        <Breadcrumbs aria-label="breadcrumb">
          <Link color="inherit" underline="hover" href="/free">
            {<HomeIcon />}
          </Link>
          <Link color="inherit" underline="hover" href="/free">
            Home
          </Link>
          <Link color="inherit" underline="hover" href="/utils">
            Utilities
          </Link>
          <Typography color="textPrimary">Add Patient</Typography>
        </Breadcrumbs>
      </Stack>
      <Stack direction="row" spacing={2} justifyContent="flex-start" mt={2} mb={8}>
        <Button
          variant="contained"
          justifyContent="flex-end"
          startIcon={<PersonAddAlt1Icon />}
          sx={{ ml: 'auto' }}
          onClick={() => setShowForm(true)}
        >
          Add Nurse
        </Button>
      </Stack>

      {showForm && (
        <Stack direction="column" spacing={2} position="relative" mb={2}>
        <form style={{ border: '1px solid #ccc', borderRadius: '8px', backgroundColor: 'white', width: '80%', maxWidth: '800px', margin: '0 auto' }} onSubmit={handleSubmit}>
            <IconButton color="primary" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
              <CloseIcon />
            </IconButton>
            <h1 style={{ justifyContent: 'center', textAlign: 'center' }}>{selectedNurse ? 'Update Nurse Details' : 'Add Nurse'}</h1>
            <Box display="flex" flexDirection="column" mt={2} ml={2} mr={2}>
              <Grid container spacing={2} mb={3}>
                {/* <Grid item xs={12} sm={4}>
                  <TextField label="PatientID" name="patientid" value={formData.patientid} onChange={handleChange} fullWidth />
                </Grid> */}
                <Grid item xs={12} sm={4}>
                  <input label="Full Name" name="fullname" placeholder="Full Name" value={formData.fullname} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                 <FormControl fullWidth>
        <select
          id="shift"
          name="shift"
          value={formData.shift}
          onChange={handleChange}
          label="shift"
          style={{width:'100%', height:'37px', marginTop:'2px'}}
          >
          <option value="">Shift</option>
          <option value="Day Shift">Day shift</option>
          <option value="Evening Shift">Morning shift</option>
          <option value="Night Shift">Night shift</option>
        </select>
      </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Mobile" name="contactnumber" placeholder="Mobile" value={formData.contactnumber} onChange={handleChange} />
                  {errors.contactnumber && <span style={{ color: 'red' }}>{errors.contactnumber}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Email" name="emailaddress" placeholder="Email" value={formData.emailaddress} onChange={handleChange} />
                  {errors.emailaddress && <span style={{ color: 'red' }}>{errors.emailaddress}</span>}
                </Grid>
                <Grid item xs={12} sm={4}>
                   <FormControl fullWidth>
                  <select
                    id="bloodgroup"
                    name="bloodgroup"
                    value={formData.bloodgroup}
                    onChange={handleChange}
                    label="Blood Group"
                    style={{width:'100%', height:'37px', marginTop:'2px'}}
                    >
                    <option value="">Blood Group</option>
                    {bloodGroupOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Experience" placeholder="Experience" name="experience" value={formData.experience} onChange={handleChange} />
                </Grid>
               
              </Grid>

              <Grid container spacing={2} mb={3}>
                
                <Grid item xs={12} sm={4}>
                  <input label="Address" placeholder="Address" name="address" value={formData.address} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <input label="Qualification" placeholder="Qualification" name="qualification" value={formData.qualification} onChange={handleChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                <FormControl fullWidth>
        <select
          id="activestatus"
          name="activestatus"
          style={{width:'100%', height:'37px', marginTop:'2px'}}
          value={formData.activestatus}
          onChange={handleChange}
          label="Status"
          >
          <option value="">Status</option>
          <option value="Active">Active</option>
          <option value="InActive">InActive</option>
        
        </select>
      </FormControl>
                </Grid>
                
                <Grid item xs={12} sm={4}>
                  <input label="Hospital Name" placeholder="Hospital Name" name="managing_admin" value={formData.managing_admin} onChange={handleChange} />
                </Grid>
                </Grid>


              <Box display="flex" justifyContent="space-between">
                <Button variant="contained" startIcon={<PersonAddAlt1Icon />} sx={{ ml: 'auto', height: '32px', mt: '8px', mb: '20px' }} type="submit">
                {selectedNurse ? 'Update Nurse' : 'Add Nurse'}
                </Button>
              </Box>
            </Box>
          </form>
        </Stack>
      )}
      <Grid container spacing={2} style={{ display: 'flex', alignItems: 'center' }} mt={1} mb={1}>
        <Grid item xs={4}>
        <div style={{ display: 'flex', alignItems: 'center' }}>  
          <input
            label="Search nurse"
            placeholder="Search by Name, Mobile, etc."
            style={{ width: '50%', height: '39px', marginTop: '2px' }}
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
                <IconButton onClick={handleSearch} edge="end">
                  <SearchIcon />
                </IconButton>
        </div>
        </Grid>
      </Grid>
      <table className="adminstyled-table">
        <thead>
          <tr>
            <th>Id.</th>

            <th>fullname</th>
            <th>shift</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>BloodGroup</th>
            <th>experience</th>
            <th>Address</th>
            <th>qualification</th>
            <th>activestatus</th>
            <th>Action</th>
            {/* <th>Sex</th> */}
            {/* <th>City</th> */}
            {/* <th>Age</th>
                <th>Age</th> */}
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => {
            return (
              <tr key={item.nurse_id}>
                <th scope="row">{index + 1}</th>

                <td>{item.fullname}</td>
                <td>{item.shift}</td>
                <td>{item.contactnumber}</td>
                <td  style={{ wordBreak: 'break-all' }}>{item.emailaddress}</td>
                <td>{item.bloodgroup}</td>
                <td>{item.experience}</td>
                <td>{item.address}</td>
                <td>{item.qualification}</td>
                <td>{item.activestatus}</td>
                {/* <td>{item.gender}</td> */}
                {/* <td>{item.date_of_birth}</td> */}
                {/* <td>{item.age}</td> */}
                {/* <td>{item.city}</td> */}

                <td>
                  <button className="adminbtn btn-edit"  onClick={() => editnurse(item)}>
                    <EditIcon /> {/* Use the DeleteIcon component here */}
                  </button>
                  <button className="adminbtn btn-edit" onClick={() => deleteContact2(item.employeeid)}>
                    <DeleteIcon /> {/* Use the DeleteIcon component here */}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      </>
      )}
    </>
  );
};

export default DoctorForm;
