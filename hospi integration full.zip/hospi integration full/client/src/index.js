import { createRoot } from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import { UserProvider } from './views/context/Usercontext'; // Import UserProvider from your UserContext file
import { store } from 'store';
import * as serviceWorker from 'serviceWorker';
import App from 'App';
import 'assets/scss/style.scss';

const container = document.getElementById('root');
const root = createRoot(container);
root.render(
  <Provider store={store}>
    <UserProvider>
      <Router>
        <App />
      </Router>
    </UserProvider>
  </Provider>
);

serviceWorker.unregister();
