// // import { lazy } from 'react';
 
// // // project imports
// // // import MainLayout from 'layout/MainLayout';
// // import Loadable from 'ui-component/Loadable';
// // // import Profile from 'Profile';
// // import MainLayout from 'layout/MainLayout';
// // // import Profile from 'Profile';
 
// // // dashboard routing
// // const DashboardDefault = Loadable(lazy(() => import('views/dashboard/Default')));
 
// // // utilities routing
// // const Admindoctor = Loadable(lazy(() => import('views/utilities/Doctors')));
// // const UtilsPatients = Loadable(lazy(() => import('views/utilities/Patients')));
// // const UtilsNurses = Loadable(lazy(() => import('views/utilities/Nurses')));
// // const UtilsReceptionist = Loadable(lazy(() => import('views/utilities/Receptionist')));
// // const UtilsReports = Loadable(lazy(() => import('views/utilities/Reports')));
// // const UtilsLaboratorist = Loadable(lazy(() => import('views/utilities/Laboratorist')));
// // const UtilsFAQ = Loadable(lazy(() => import('views/utilities/FAQ')));
// // const UtilsRefference = Loadable(lazy(() => import('views/utilities/Refference')));
// // const UtilsHelp = Loadable(lazy(() => import('views/utilities/Help')));
// // const UtilsAppointmentbooking = Loadable(lazy(() => import('views/utilities/Appointmentbooking')));
// // const UtilsHealthpackages = Loadable(lazy(() => import('views/utilities/Healthpackages')));
// // // sample page routing
// // const UtilsPharmacist = Loadable(lazy(() => import('views/utilities/Pharmacist')));
 
// // // ==============================|| MAIN ROUTING ||============================== //
// // const EditProfile = Loadable(lazy(() => import('layout/MainLayout/Header/ProfileSection/editprofile')));
// // const MainRoutes = {
// //   path: '/Admin',
// //   element: <MainLayout />,
// //   children: [
// //     {
// //       path: '/Admin',
// //       element: <DashboardDefault />
// //     },
 
   
// //     // {
// //     //   path: 'utils1',
// //     //   children: [
// //     //     {
// //     //       path: 'util-admin',
// //     //       element: <Utils1admin />
// //     //     }
// //     //   ]
// //     // },
// //         {
// //           path: 'util-Patients',
// //           element: <UtilsPatients />
// //         },
   
     
// //         {
// //           path: 'util-Nurses',
// //           element: <UtilsNurses />
// //         },
   
   
// //     {
   
     
// //           path: 'util-Receptionist',
// //           element: <UtilsReceptionist />
// //         },
     
// //     {
     
// //           path: 'util-Laboratorist',
// //           element: <UtilsLaboratorist />
       
// //     },
// //     {
   
// //           path: 'util-Pharmacist',
// //           element: <UtilsPharmacist />
     
// //     },
// //     {
// //       path: 'editprofile',
// //       element: <EditProfile />
// //     },
// //     {
// //       path: 'util-Doctors',
// //       element: <Admindoctor />
// //     },
// //     {
     
// //           path: 'util-Appointmentbooking',
// //           element: <UtilsAppointmentbooking />
     
// //     },
// //     {
     
// //           path: 'util-Reports',
// //           element: <UtilsReports />
// //     },
// //     {
     
// //           path: 'util-Healthpackages',
// //           element: <UtilsHealthpackages />
     
// //     },
// //     {
     
// //           path: 'util-FAQ',
// //           element: <UtilsFAQ />
       
// //     },
// //     {
   
// //           path: 'util-Refference',
// //           element: <UtilsRefference />
     
// //     },
// //     {
     
// //           path: 'util-Help',
// //           element: <UtilsHelp />
     
// //     },
   
// //   ],
// // };
 
// // export default MainRoutes;
 
 
 
import { lazy } from 'react';
import MainLayout from 'layout/MainLayout';
import MainLayout1 from 'layout1/MainLayout';
import MainLayout2 from 'layout2/MainLayout';
import Loadable from 'ui-component/Loadable';
import NavScrollExample1 from 'views/User/Navbar';
import Navbar1 from 'views/User/Navbar1';
import Footer from 'views/User/Footer';
import {  Routes, Route } from 'react-router-dom';
import Hospital from 'views/User/Hospital';
import CheckUps from 'views/User/Checkups';
import HospitalEdit from 'views/User/HospitalEdit';
import PaymentOptions from 'views/User/Payment';
import EditProfilePage from 'views/User/EditProfilePage';
import EditForm from 'views/User/EditForm';
import Vehicles from 'views/User/vehicles';
// import { Payment } from '@mui/icons-material';
import Booking from 'views/User/Bookings';
import  Payment  from 'views/User/payment1';
// import Profile from 'Profile';
import Login from 'views/hospi-login/Loginm';
import SignupForm from 'views/hospi-login/SignupForm';
import ForgotPassword from 'views/hospi-login/forgotpassword';
 
import AdminDashboard from 'views/hospi-login/AdminDashboard';
import SuperAdminDashboard from 'views/hospi-login/SuperAdminDashboard';
import UserDashboard from 'views/hospi-login/UserDashboard';
// Dashboard Routing
const DashboardDefault = Loadable(lazy(() => import('views/dashboard/Default')));
const DashboardDefault1 = Loadable(lazy(() => import('views/dashboard1/Default')));
const DashboardDefault2 = Loadable(lazy(() => import('views/dashboard2/Default')));
const UtilsAppointmentbooking = Loadable(lazy(() => import('views/utilities/Appointmentbooking')));
const UtilsHealthpackages = Loadable(lazy(() => import('views/utilities/Healthpackages')));
const UtilsPharmacist = Loadable(lazy(() => import('views/utilities/Pharmacist')));
 
// Utilities Routing for Admin
const UtilsAdmin = Loadable(lazy(() => import('views/utilities1/Manageadmin')));
const UtilsNurses = Loadable(lazy(() => import('views/utilities/Nurses')));
const UtilsReceptionist = Loadable(lazy(() => import('views/utilities/Receptionist')));
const UtilsReports = Loadable(lazy(() => import('views/utilities/Reports')));
const UtilsLaboratorist = Loadable(lazy(() => import('views/utilities/Laboratorist')));
const UtilsFAQ = Loadable(lazy(() => import('views/utilities/FAQ')));
const UtilsFAQ1 = Loadable(lazy(() => import('views/utilities1/FAQ1')));
const UtilsRefference = Loadable(lazy(() => import('views/utilities/Refference')));
const UtilsRefference1 = Loadable(lazy(() => import('views/utilities1/Refferance1')));
 
const UtilsClinics = Loadable(lazy(() => import('views/utilities1/Clinics')));
const UtilsHospitals = Loadable(lazy(() => import('views/utilities1/Hospitals')));
const UtilsAmbulance = Loadable(lazy(() => import('views/utilities1/Ambulance')));
const UtilsDoctors = Loadable(lazy(() => import('views/utilities/Doctors')));
const UtilsDoctors1 = Loadable(lazy(() => import('views/utilities1/SuperDoctors')));
const UtilsAddadmin = Loadable(lazy(() => import('views/utilities1/Addadmin')));
const UtilsManageadmin = Loadable(lazy(() => import('views/utilities1/Manageadmin')));
const UtilsHelp = Loadable(lazy(() => import('views/utilities/Help')));
const UtilsHelp1 = Loadable(lazy(() => import('views/utilities1/Help1')));
const UtilsDiagnosticlabs = Loadable(lazy(() => import('views/utilities1/Diagnosticlabs')));
const UtilsPatients = Loadable(lazy(() => import('views/utilities/Patients')));
const UtilsPatients1 = Loadable(lazy(() => import('views/utilities1/superPatients')));
const User = Loadable(lazy(() => import('views/User/Hospital')));
// const Hospital = Loadable(lazy(() => import('views/User/Hospital')));
const Clinic = Loadable(lazy(() => import('views/User/Home1')));
const Ambulance = Loadable(lazy(() => import('views/User/home')));
const Diagnosticlabs = Loadable(lazy(() => import('views/User/Diagnostic')));
// const Vechiles = Loadable(lazy(() => import('views/User/vehicles')));
// const Healthpackages = Loadable(lazy(() => import('views/User/Checkups')));
const Helps1 = Loadable(lazy(() => import('views/utilities/Helps')));
const DoctorAppointment = Loadable(lazy(() => import('views/utilities3/Appointment')));
const DoctorPatient = Loadable(lazy(() => import('views/utilities3/DoctorPatient')));
const DoctorMyWorkSpace = Loadable(lazy(() => import('views/utilities3/MyWorkSpace')));
const DoctorShiftTiming = Loadable(lazy(() => import('views/utilities3/ShiftTiming')));
const DoctorFaq = Loadable(lazy(() => import('views/utilities3/FAQ')));
const EditProfile = Loadable(lazy(() => import('layout/MainLayout/Header/ProfileSection/editprofile')));
 
const getMainRoutes = (type) => {
  switch (type) {
    case 'SuperAdmin':
      return {
        path: '/SuperAdmin',
        element: <MainLayout1 />,
        children: [
          { path: '/SuperAdmin', element: <DashboardDefault1 /> },
          { path: 'util-Admin', element: <UtilsAdmin /> },
          { path: 'util-Hospitals', element: <UtilsHospitals /> },
          { path: 'util-Clinics', element: <UtilsClinics /> },
          { path: 'util-Ambulance', element: <UtilsAmbulance /> },
          { path: 'util-Doctors', element: <UtilsDoctors1 /> },
          { path: 'util-Diagnosticlabs', element: <UtilsDiagnosticlabs /> },
          { path: 'util-Patients', element: <UtilsPatients1 /> },
          { path: 'util-Addadmin', element: <UtilsAddadmin /> },
          { path: 'util-Manageadmin', element: <UtilsManageadmin /> },
          { path: 'util-FAQ', element: <UtilsFAQ1 /> },
          { path: 'util-refer', element: <UtilsRefference1 /> },
          { path: 'util-Help', element: <UtilsHelp1 /> },
          { path: 'editprofile', element: <EditProfile /> }
        ]
      };
    case 'Admin':
      return {
        path: '/Admin',
        element: <MainLayout />,
        children: [
          { path: '/Admin', element: <DashboardDefault /> },
          { path: 'util-Patients', element: <UtilsPatients /> },
          { path: 'util-Nurses', element: <UtilsNurses /> },
          { path: 'util-Receptionist', element: <UtilsReceptionist /> },
          { path: 'util-Laboratorist', element: <UtilsLaboratorist /> },
          { path: 'util-Pharmacist', element: <UtilsPharmacist /> },
          { path: 'editprofile', element: <EditProfile /> },
          { path: 'util-Doctors', element: <UtilsDoctors /> },
          { path: 'util-Appointmentbooking', element: <UtilsAppointmentbooking /> },
          { path: 'util-Reports', element: <UtilsReports /> },
          { path: 'util-Healthpackages', element: <UtilsHealthpackages /> },
          { path: 'util-FAQ', element: <UtilsFAQ /> },
          { path: 'util-Refference', element: <UtilsRefference /> },
          { path: 'Helps', element: <Helps1 /> },
          { path: 'util-Help', element: <UtilsHelp /> }
        ]
      };
      case 'User':
        return {
          path: '/User',
          element: (
            <>
      <NavScrollExample1 />
      <Navbar1 />
      {/* Use Routes for nested routing */}
      <Routes>
        <Route path="/" element={<User />} />
        <Route path="/Hospital" element={<Hospital />} />
        <Route path="/Clinic" element={<Clinic />} />
        <Route path="/Ambulance" element={<Ambulance />} />
        <Route path="/CheckUp" element={<CheckUps />} />
        <Route path="/Labs" element={<Diagnosticlabs />} />
        <Route path="/edit" element={<EditForm />} />
        <Route path="/edit1" element={<HospitalEdit />} />
        <Route  path="/Payment" element={<Payment/>} />
        <Route path="/my-account" element={<EditProfilePage />} />
        <Route path="/vehicles" element={<Vehicles />} />
        <Route path='/Bookings' element={<Booking />}/>
        <Route path='/payment1' element={<PaymentOptions />}/>
      </Routes>
      <Footer />
    </>
          ), // <- Add comma here
          children: [
            { path: '/User', element: <User /> },
            { path: 'Hospital', element: <Hospital /> },
            { path: 'Clinic', element: <Clinic /> },
            { path: 'Ambulance', element: <Ambulance /> },
            { path: 'Labs', element: <Diagnosticlabs /> },
            { path: 'Checkups', element: <CheckUps /> },
            { path: 'Bookings', element: <Booking /> },
            { path: 'payment1', element: <PaymentOptions /> },
            { path: 'Payment', element: <Payment /> },
            { path: 'edit', element: <EditForm  /> },
            { path: 'edit1', element: <HospitalEdit /> },
            { path: 'vehicles', element: <Vehicles /> },
            { path: 'my-account', element: <EditProfilePage /> }
       
          ]
        };
        case 'Root':
          return {
            path: '/',
            element: (
              <>
               
               
               <Routes>
               <Route path="/" element={<Login />} />
      <Route path="/SignupFrom" element={<SignupForm />} />
      <Route path="/ForgotPassword" element={<ForgotPassword />} />
        <Route path="/api/adminuserdetails/:userId" element={<AdminDashboard />} />
        <Route path="/api/superadminuserdetails/:userId" element={<SuperAdminDashboard />} />
        <Route path="/api/userdetails/:userId" element={<UserDashboard />} />
      </Routes>
              </>
            ),
            children: [
              { path: '/', element: <Login /> },
              { path: '/SignupFrom', element: <SignupForm /> },
              { path: '/ForgotPassword', element: <ForgotPassword /> },
 
            ]
          };
          case 'Doctor':
            return {
              path: '/Doctor',
              element: <MainLayout2 />,
              children: [
                { path: '/Doctor', element: <DashboardDefault2 /> },
                { path: 'DoctorAppointment', element: <DoctorAppointment /> },
                { path: 'Doctorpatient', element: <DoctorPatient /> },
                { path: 'DoctorShifttiming', element: <DoctorShiftTiming /> },
                { path: 'DoctorMyWorkSpace', element: <DoctorMyWorkSpace /> },
                { path: 'DoctorFaq', element: <DoctorFaq /> }
             
              ]
            };  
  //  case 'User':
  // return {
  //   path: '/User',
  //   element: (
  //     <>
  //       <NavScrollExample1 />
  //       <Navbar1 />
  //       {/* Nested routes for User */}
  //       <Routes>
  //         <Route path="/" element={<User />} /> {/* Render User component at '/User' */}
  //         <Route path="Hospital" element={<Hospital />} /> {/* Render Hospital component at '/User/Hospital' */}
  //         <Route path="Clinic" element={<Clinic />} /> {/* Render Clinic component at '/User/Clinic' */}
  //         <Route path="Ambulance" element={<Ambulance />} /> {/* Render Ambulance component at '/User/Ambulance' */}
  //         <Route path="Labs" element={<Diagnosticlabs />} /> {/* Render Diagnosticlabs component at '/User/Labs' */}
  //         <Route path="Checkups" element={<Healthpackages />} /> {/* Render Healthpackages component at '/User/Checkups' */}
  //       </Routes>
  //       <Footer />
  //     </>
  //   )
  // };
 
        default:
      return {};
  }
};
 
// const mainRoutesType = location.pathname.startsWith('/SuperAdmin') ? 'SuperAdmin' : (location.pathname.startsWith('/User') ? 'User' : 'Admin');
// const mainRoutesType = location.pathname === '/' ? 'Root' : (location.pathname.startsWith('/SuperAdmin') ? 'SuperAdmin' : (location.pathname.startsWith('/User') ? 'User' : 'Admin'));
const mainRoutesType = location.pathname === '/' ? 'Root' : (location.pathname.startsWith('/SuperAdmin') ? 'SuperAdmin' : (location.pathname.startsWith('/User') ? 'User' : (location.pathname.startsWith('/Doctor') ? 'Doctor' : 'Admin')));
 
const MainRoutes = getMainRoutes(mainRoutesType);
 
export default MainRoutes;
 