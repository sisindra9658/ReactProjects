import { lazy } from 'react';
import MainLayout from 'layout/MainLayout/Header/ProfileSection/editprofile';
import Loadable from 'ui-component/Loadable';
 
const EditProfile = Loadable(lazy(() => import('layout/MainLayout/Header/ProfileSection/editprofile')))
const MainRoute = {
    path: 'editprofile',
    element: <MainLayout />,
    children: [
        {
            path: 'ProfileSection',
            element: <EditProfile />
          }
 
    ],
  };
 
  export default MainRoute;
 